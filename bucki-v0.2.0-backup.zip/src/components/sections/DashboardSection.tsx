'use client';

import { useState, useMemo, useCallback, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle 
} from '@/components/ui/dialog';
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from '@/components/ui/select';
import { useStore } from '@/lib/store';
import { useI18n } from '@/contexts/I18nContext';
import type { DashboardWidget, DashboardWidgetType, Financing, Property, Unit, Task, DepreciationItem, HouseMoney, BankAccount } from '@/lib/types';
import { WIDGET_METADATA, DEFAULT_DASHBOARD_WIDGETS } from '@/lib/types';
import { COLORS } from './constants';
import { 
  Plus, UserPlus, ClipboardList, PlusCircle, TrendingUp, TrendingDown, 
  ArrowUpRight, ArrowDownRight, Minus, PiggyBank, Percent, Shield, 
  Settings2, X, Info, Lightbulb, AlertCircle, AlertTriangle, CheckCircle,
  RotateCcw, Gauge, Scale, Home, Building2, DoorOpen, Users, DollarSign,
  CreditCard, Receipt, FileText, Wrench, Zap, BarChart2, PieChart as PieChartIcon,
  LineChart as LineChartIcon, Calendar, Euro, Target, Award, Landmark,
  ThumbsUp, ThumbsDown, AlertOctagon, Briefcase, Banknote
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Legend, AreaChart, Area, ComposedChart, RadialBarChart, RadialBar
} from 'recharts';
import { format, subMonths, subYears, differenceInMonths, parseISO } from 'date-fns';
import { de } from 'date-fns/locale';

// ============================================
// HILFSKOMPONENTEN
// ============================================

// LTV Gauge Component
function LTVGauge({ ltv, size = 'small' }: { ltv: number; size?: 'small' | 'large' }) {
  const getLTVColor = (ltv: number) => {
    if (ltv <= 60) return '#10b981';
    if (ltv <= 75) return '#f59e0b';
    if (ltv <= 85) return '#f97316';
    return '#ef4444';
  };
  
  const dimensions = size === 'large' ? { width: 200, height: 100, fontSize: 'text-2xl' } : { width: 128, height: 64, fontSize: 'text-lg' };
  
  return (
    <div className="relative mx-auto" style={{ width: dimensions.width, height: dimensions.height }}>
      <svg viewBox="0 0 100 50" className="w-full h-full">
        <path
          d="M 10 50 A 40 40 0 0 1 90 50"
          fill="none"
          stroke="currentColor"
          strokeWidth="8"
          strokeLinecap="round"
          className="text-gray-200 dark:text-gray-700"
        />
        <path
          d="M 10 50 A 40 40 0 0 1 90 50"
          fill="none"
          stroke={getLTVColor(ltv)}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={`${Math.min(ltv, 100) * 1.26} 126`}
        />
      </svg>
      <div className="absolute inset-0 flex items-end justify-center pb-1">
        <span className={`font-bold ${dimensions.fontSize}`} style={{ color: getLTVColor(ltv) }}>
          {ltv.toFixed(1)}%
        </span>
      </div>
    </div>
  );
}

// ROE Gauge Component (Radial)
function ROEGauge({ roe }: { roe: number }) {
  const getROEColor = (roe: number) => {
    if (roe >= 10) return '#10b981';
    if (roe >= 5) return '#f59e0b';
    return '#ef4444';
  };

  const data = [{ name: 'ROE', value: Math.min(roe, 25), fill: getROEColor(roe) }];

  return (
    <div className="relative w-32 h-32 mx-auto">
      <ResponsiveContainer width="100%" height="100%">
        <RadialBarChart cx="50%" cy="50%" innerRadius="60%" outerRadius="100%" barSize={12} data={data} startAngle={180} endAngle={0}>
          <RadialBar background={{ fill: '#e5e7eb' }} dataKey="value" cornerRadius={10} />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <span className="text-2xl font-bold" style={{ color: getROEColor(roe) }}>
            {roe.toFixed(1)}%
          </span>
          <p className="text-xs text-muted-foreground">ROE</p>
        </div>
      </div>
    </div>
  );
}

// Widget Wrapper Component
function WidgetWrapper({ 
  widgetId, 
  editMode, 
  onToggle, 
  children, 
  title, 
  icon: Icon,
  className = ''
}: { 
  widgetId: DashboardWidgetType; 
  editMode: boolean; 
  onToggle: (id: DashboardWidgetType) => void;
  children: React.ReactNode;
  title: string;
  icon: React.ElementType;
  className?: string;
}) {
  return (
    <div className={`relative ${editMode ? 'ring-2 ring-dashed ring-blue-300 dark:ring-blue-700 rounded-lg' : ''} ${className}`}>
      {editMode && (
        <div className="absolute -top-2 -right-2 z-10">
          <Button 
            variant="destructive" 
            size="icon" 
            className="h-6 w-6" 
            onClick={() => onToggle(widgetId)}
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      )}
      {children}
    </div>
  );
}

// ============================================
// NEUE WIDGET-TYPEN
// ============================================
const NEW_WIDGET_TYPES: DashboardWidgetType[] = [
  'renditeKennzahl',
  'zinsVsTilgung',
  'schuldenDiagram',
  'portfolioVerteilung',
  'besteRenditen',
  'wertsteigerung',
  'groessteWertsteigerung',
  'cashflowDiagram',
  'ausgabenChart',
  'eigenkapitalrendite',
  'abschreibungen',
  'steuern',
  'kaltmieteVsVergleich',
  'hausgelder',
  'sonderumlagen',
  'nebenkosten',
  'investitionen',
  'kautionen',
  'ruecklagen',
  'grundstueckswerte',
  'banken',
  'kredite',
];

// ============================================
// DASHBOARD SECTION
// ============================================

interface DashboardSectionProps {
  stats: any;
  isMobile?: boolean;
  setActiveTab: (tab: string) => void;
}

function DashboardSection({ stats, isMobile, setActiveTab }: DashboardSectionProps) {
  const store = useStore();
  const { t, formatCurrency } = useI18n();
  const [timeFilterType, setTimeFilterType] = useState<'month' | 'quarter' | 'year' | 'all'>('month');
  
  // Widget Configuration State
  const [widgetConfig, setWidgetConfig] = useState<DashboardWidget[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('bucki-dashboard-config-v3');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          return DEFAULT_DASHBOARD_WIDGETS;
        }
      }
    }
    return DEFAULT_DASHBOARD_WIDGETS;
  });
  const [editMode, setEditMode] = useState(false);
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  
  // Save widget config to localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('bucki-dashboard-config-v3', JSON.stringify(widgetConfig));
    }
  }, [widgetConfig]);
  
  // Widget visibility helper
  const isWidgetVisible = useCallback((widgetId: DashboardWidgetType) => {
    const widget = widgetConfig.find(w => w.id === widgetId);
    return widget?.visible ?? true;
  }, [widgetConfig]);
  
  // Toggle widget visibility
  const toggleWidget = useCallback((widgetId: DashboardWidgetType) => {
    setWidgetConfig(prev => prev.map(w => 
      w.id === widgetId ? { ...w, visible: !w.visible } : w
    ));
  }, []);
  
  // Reset to default
  const resetToDefault = useCallback(() => {
    setWidgetConfig(DEFAULT_DASHBOARD_WIDGETS);
    setConfigDialogOpen(false);
  }, []);

  // ============================================
  // KPI BERECHNUNGEN
  // ============================================
  
  const enhancedKPIs = useMemo(() => {
    const totalMarketValue = stats.totalEstimatedValue || stats.totalMarketValue || 0;
    const totalDebt = stats.totalRemainingDebt || 0;
    const equity = totalMarketValue - totalDebt;
    const coldRentIncome = stats.coldRentIncome || 0;
    const cashflow = stats.cashflow || 0;
    
    // ROE (Eigenkapitalrendite) - annualized
    const roe = equity > 0 ? ((cashflow * 12) / equity) * 100 : 0;
    
    // LTV (Loan-to-Value)
    const ltv = totalMarketValue > 0 ? (totalDebt / totalMarketValue) * 100 : 0;
    
    // Tilgung vs. Zins
    const monthlyMortgagePayment = store.financings.reduce((sum: number, f: Financing) => {
      const interestAmount = f.remainingDebt * (f.interestRate / 100) / 12;
      const repayment = f.monthlyRate - interestAmount;
      return sum + Math.max(0, repayment);
    }, 0);
    
    const monthlyInterest = store.financings.reduce((sum: number, f: Financing) => {
      const interestAmount = f.remainingDebt * (f.interestRate / 100) / 12;
      return sum + interestAmount;
    }, 0);
    
    const totalMortgagePayment = monthlyMortgagePayment + monthlyInterest;
    const tilgungsAnteil = totalMortgagePayment > 0 ? (monthlyMortgagePayment / totalMortgagePayment) * 100 : 0;
    const zinsAnteil = totalMortgagePayment > 0 ? (monthlyInterest / totalMortgagePayment) * 100 : 0;
    
    // Mietrendite Brutto
    const totalPurchasePrice = store.properties.reduce((sum: number, p: Property) => sum + p.purchasePrice, 0);
    const bruttoMietrendite = totalPurchasePrice > 0 ? ((coldRentIncome * 12) / totalPurchasePrice) * 100 : 0;
    
    // Leerstandsquote
    const totalUnits = store.units.length;
    const vacantUnits = store.units.filter((u: Unit) => u.status === 'vacant').length;
    const leerstandsquote = totalUnits > 0 ? (vacantUnits / totalUnits) * 100 : 0;
    
    // Kostenquote
    const totalIncome = stats.totalRentIncome || 0;
    const monthlyExpenses = stats.totalExpenses || 0;
    const kostenquote = totalIncome > 0 ? (monthlyExpenses / totalIncome) * 100 : 0;
    
    // Cash-on-Cash Return
    const cashOnCashReturn = equity > 0 ? ((cashflow * 12) / equity) * 100 : 0;
    
    // Break-even in Monaten
    const breakEvenMonate = cashflow > 0 ? Math.ceil(totalPurchasePrice / (cashflow * 12)) : 0;
    
    // Durchschnittlicher Energiewert
    const energyClasses: Record<string, number> = { 'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8, 'unknown': 0 };
    const avgEnergy = store.properties.length > 0 
      ? store.properties.reduce((sum: number, p: Property) => sum + (energyClasses[p.energyClass] || 0), 0) / store.properties.length
      : 0;
    const avgEnergyClass = avgEnergy > 0 ? ['-', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'][Math.round(avgEnergy)] : '-';
    
    return {
      roe,
      ltv,
      netWorth: equity,
      tilgungsAnteil,
      zinsAnteil,
      monthlyMortgagePayment,
      monthlyInterest,
      bruttoMietrendite,
      leerstandsquote,
      kostenquote,
      cashOnCashReturn,
      breakEvenMonate,
      vacantUnits,
      totalUnits,
      cashflow,
      avgEnergyClass,
      avgEnergyValue: avgEnergy,
    };
  }, [stats, store.properties, store.units, store.financings]);

  // ============================================
  // CHART DATA
  // ============================================

  // Chart Data: Cashflow over time
  const cashflowChartData = useMemo(() => {
    const data = [];
    for (let i = 11; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const monthKey = format(date, 'yyyy-MM');
      
      const monthIncome = store.transactions
        .filter(t => t.type === 'income' && t.date.startsWith(monthKey))
        .reduce((sum, t) => sum + t.amount, 0);
      
      const monthExpenses = store.transactions
        .filter(t => t.type === 'expense' && t.date.startsWith(monthKey))
        .reduce((sum, t) => sum + t.amount, 0);
      
      data.push({
        month: format(date, 'MMM', { locale: de }),
        einnahmen: monthIncome,
        ausgaben: monthExpenses,
        cashflow: monthIncome - monthExpenses,
      });
    }
    return data;
  }, [store.transactions]);

  // Chart Data: City Distribution
  const cityDistributionData = useMemo(() => {
    const cities: Record<string, { count: number; value: number }> = {};
    store.properties.forEach(p => {
      if (!cities[p.city]) cities[p.city] = { count: 0, value: 0 };
      cities[p.city].count++;
      cities[p.city].value += p.marketValue;
    });
    return Object.entries(cities).map(([city, data]) => ({
      name: city,
      count: data.count,
      value: data.value,
    })).sort((a, b) => b.value - a.value);
  }, [store.properties]);

  // Chart Data: Zins vs Tilgung
  const zinsVsTilgungData = [
    { name: 'Zins', value: enhancedKPIs.monthlyInterest, color: '#f59e0b' },
    { name: 'Tilgung', value: enhancedKPIs.monthlyMortgagePayment, color: '#10b981' },
  ];

  // Chart Data: Ausgaben nach Kategorien
  const expenseCategoryData = useMemo(() => {
    const categories: Record<string, number> = {};
    store.transactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        const cat = t.category || 'other';
        categories[cat] = (categories[cat] || 0) + t.amount;
      });
    return Object.entries(categories).map(([category, amount]) => ({
      name: category,
      value: amount,
    })).sort((a, b) => b.value - a.value);
  }, [store.transactions]);

  // Ausgaben Chart Data (Umlagebare NK, nicht umlagebare NK, Zins, Tilgung)
  const ausgabenDetailedData = useMemo(() => {
    const umlagebareNK = store.houseMoney.reduce((sum, h) => sum + h.utilities + h.water + h.heating + h.garbage, 0);
    const nichtUmlagebareNK = store.houseMoney.reduce((sum, h) => sum + h.administrativeFee + h.other, 0);
    
    return [
      { name: 'Umlagebare NK', value: umlagebareNK, color: '#3b82f6' },
      { name: 'Nicht umlagebare NK', value: nichtUmlagebareNK, color: '#8b5cf6' },
      { name: 'Zins', value: enhancedKPIs.monthlyInterest * 12, color: '#f59e0b' },
      { name: 'Tilgung', value: enhancedKPIs.monthlyMortgagePayment * 12, color: '#10b981' },
    ];
  }, [store.houseMoney, enhancedKPIs]);

  // Top 5 Renditen
  const topYieldUnits = useMemo(() => {
    return store.units
      .map(u => {
        const property = store.properties.find(p => p.id === u.propertyId);
        const yieldPercentage = property && property.purchasePrice > 0 
          ? ((u.totalRent * 12) / property.purchasePrice) * 100 
          : 0;
        return { ...u, property, yieldPercentage };
      })
      .sort((a, b) => b.yieldPercentage - a.yieldPercentage)
      .slice(0, 5);
  }, [store.units, store.properties]);

  // Top 5 Wertsteigerung
  const topAppreciation = useMemo(() => {
    return store.properties
      .map(p => {
        const appreciation = p.estimatedValue - p.purchasePrice;
        const appreciationPercentage = p.purchasePrice > 0 
          ? (appreciation / p.purchasePrice) * 100 
          : 0;
        return { ...p, appreciation, appreciationPercentage };
      })
      .sort((a, b) => b.appreciationPercentage - a.appreciationPercentage)
      .slice(0, 5);
  }, [store.properties]);

  // Wertsteigerung Bar Chart Data
  const wertsteigerungChartData = useMemo(() => {
    return store.properties
      .map(p => ({
        name: p.name,
        kaufpreis: p.purchasePrice,
        schaetzwert: p.estimatedValue,
        steigerung: p.estimatedValue - p.purchasePrice,
      }))
      .sort((a, b) => b.steigerung - a.steigerung)
      .slice(0, 10);
  }, [store.properties]);

  // Schuldenverlauf
  const debtHistoryData = useMemo(() => {
    const data = [];
    let currentDebt = stats.totalRemainingDebt || 0;
    for (let i = 0; i <= 12; i++) {
      const date = subMonths(new Date(), 12 - i);
      const monthlyRepayment = enhancedKPIs.monthlyMortgagePayment;
      currentDebt = i === 0 ? currentDebt : currentDebt - monthlyRepayment;
      data.push({
        month: format(date, 'MMM', { locale: de }),
        schulden: Math.max(0, currentDebt),
      });
    }
    return data;
  }, [stats.totalRemainingDebt, enhancedKPIs.monthlyMortgagePayment]);

  // Total Kautionen
  const totalDeposits = store.tenants.reduce((sum, t) => sum + t.deposit, 0);
  
  // Total Rücklagen
  const totalReserves = store.properties.reduce((sum, p) => sum + (p.reserves || 0), 0);

  // Abschreibungen
  const depreciationData = useMemo(() => {
    const byCategory: Record<string, number> = {};
    store.depreciationItems.forEach(d => {
      byCategory[d.category] = (byCategory[d.category] || 0) + d.annualDepreciation;
    });
    return Object.entries(byCategory).map(([category, amount]) => ({
      name: category,
      value: amount,
    }));
  }, [store.depreciationItems]);

  const totalAnnualDepreciation = store.depreciationItems.reduce((sum: number, d: DepreciationItem) => sum + d.annualDepreciation, 0);

  // Durchschnittsmiete pro m²
  const avgRentPerSqm = useMemo(() => {
    const rentedUnits = store.units.filter((u: Unit) => u.status === 'rented' && u.area > 0);
    if (rentedUnits.length === 0) return 0;
    const totalRent = rentedUnits.reduce((sum: number, u: Unit) => sum + u.totalRent, 0);
    const totalArea = rentedUnits.reduce((sum: number, u: Unit) => sum + u.area, 0);
    return totalArea > 0 ? totalRent / totalArea : 0;
  }, [store.units]);

  // Kaltmiete vs Vergleichsmiete
  const kaltmieteVsVergleichData = useMemo(() => {
    return store.units.map(u => {
      const property = store.properties.find(p => p.id === u.propertyId);
      const vergleichsmiete = property ? property.pricePerSqm * u.area : 0;
      return {
        name: u.unitNumber,
        kaltmiete: u.baseRent,
        vergleichsmiete: vergleichsmiete,
      };
    }).slice(0, 10);
  }, [store.units, store.properties]);

  // Hausgelder nach Immobilien
  const hausgeldData = useMemo(() => {
    const byProperty: Record<string, { name: string; total: number; paid: number; pending: number }> = {};
    store.houseMoney.forEach(h => {
      const property = store.properties.find(p => p.id === h.propertyId);
      const propName = property?.name || 'Unbekannt';
      if (!byProperty[h.propertyId]) {
        byProperty[h.propertyId] = { name: propName, total: 0, paid: 0, pending: 0 };
      }
      byProperty[h.propertyId].total += h.totalAmount;
      if (h.paymentStatus === 'paid') {
        byProperty[h.propertyId].paid += h.totalAmount;
      } else {
        byProperty[h.propertyId].pending += h.totalAmount;
      }
    });
    return Object.values(byProperty);
  }, [store.houseMoney, store.properties]);

  // Banken Übersicht
  const bankenData = useMemo(() => {
    const byBank: Record<string, { name: string; count: number; totalDebt: number; totalRate: number }> = {};
    store.financings.forEach(f => {
      if (!byBank[f.bankName]) {
        byBank[f.bankName] = { name: f.bankName, count: 0, totalDebt: 0, totalRate: 0 };
      }
      byBank[f.bankName].count++;
      byBank[f.bankName].totalDebt += f.remainingDebt;
      byBank[f.bankName].totalRate += f.monthlyRate;
    });
    return Object.values(byBank);
  }, [store.financings]);

  // Kredit Übersicht
  const kreditData = useMemo(() => {
    return store.financings.map(f => {
      const property = store.properties.find(p => p.id === f.propertyId);
      return {
        ...f,
        propertyName: property?.name || 'Unbekannt',
      };
    }).sort((a, b) => a.fixedInterestUntil?.localeCompare(b.fixedInterestUntil || '') || 0);
  }, [store.financings, store.properties]);

  // ============================================
  // RENDER
  // ============================================

  return (
    <div className="space-y-6">
      {/* Header with Time Filter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Willkommen bei Bucki Immobilienverwaltung</p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant={editMode ? "default" : "outline"} 
            size="sm" 
            onClick={() => setEditMode(!editMode)}
            className={editMode ? "bg-emerald-600 hover:bg-emerald-700" : ""}
          >
            <Settings2 className="h-4 w-4 mr-1" />
            {editMode ? 'Fertig' : 'Anpassen'}
          </Button>
          <Select value={timeFilterType} onValueChange={(v: any) => setTimeFilterType(v)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">{t.dashboard.timeFilter.month}</SelectItem>
              <SelectItem value="quarter">{t.dashboard.timeFilter.quarter}</SelectItem>
              <SelectItem value="year">{t.dashboard.timeFilter.year}</SelectItem>
              <SelectItem value="all">Alle Zeit</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Edit Mode Banner */}
      {editMode && (
        <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
          <CardContent className="py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Info className="h-4 w-4 text-blue-600" />
                <span className="text-sm text-blue-700 dark:text-blue-300">
                  Bearbeitungsmodus: Klicken Sie auf das X-Symbol, um Widgets auszublenden.
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setConfigDialogOpen(true)}>
                  <Settings2 className="h-4 w-4 mr-1" />
                  Alle Widgets
                </Button>
                <Button variant="outline" size="sm" onClick={resetToDefault}>
                  <RotateCcw className="h-4 w-4 mr-1" />
                  Zurücksetzen
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ========== 4 SPALTEN x 3 ZEILEN KPIs ========== */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Spalte 1: Wohneinheiten, Kaltmiete, Rendite */}
        <div className="space-y-4">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <DoorOpen className="h-4 w-4" />
                Wohneinheiten
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{store.units.length}</div>
              <p className="text-xs text-muted-foreground">
                {store.units.filter(u => u.status === 'rented').length} vermietet, {enhancedKPIs.vacantUnits} leerstehend
              </p>
              <Progress 
                value={store.units.length > 0 ? (store.units.filter(u => u.status === 'rented').length / store.units.length) * 100 : 0} 
                className="mt-2 h-2" 
              />
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Euro className="h-4 w-4" />
                Kaltmiete
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600">{formatCurrency(stats.coldRentIncome || 0)}</div>
              <p className="text-xs text-muted-foreground">pro Monat</p>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-xs text-muted-foreground">Ø {formatCurrency(avgRentPerSqm)}/m²</span>
              </div>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Percent className="h-4 w-4" />
                Ø Rendite
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{enhancedKPIs.bruttoMietrendite.toFixed(2)}%</div>
              <p className="text-xs text-muted-foreground">Bruttomietrendite p.a.</p>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-xs">
                  Netto: {((enhancedKPIs.bruttoMietrendite * (1 - enhancedKPIs.kostenquote / 100)) || 0).toFixed(2)}%
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Spalte 2: Schätzwert, Restschuld, LTV */}
        <div className="space-y-4">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Aktueller Schätzwert
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{formatCurrency(stats.totalEstimatedValue || stats.totalMarketValue || 0)}</div>
              <p className="text-xs text-muted-foreground">Gesamtportfolio</p>
              <div className="flex items-center gap-1 mt-1">
                {(() => {
                  const diff = (stats.totalEstimatedValue || 0) - store.properties.reduce((sum, p) => sum + p.purchasePrice, 0);
                  return (
                    <Badge variant={diff >= 0 ? "default" : "destructive"} className="text-xs">
                      {diff >= 0 ? '+' : ''}{formatCurrency(diff)}
                    </Badge>
                  );
                })()}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950 dark:to-red-900 hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-red-700 dark:text-red-300 flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Restschuld
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-700 dark:text-red-300">{formatCurrency(stats.totalRemainingDebt || 0)}</div>
              <p className="text-xs text-red-600 dark:text-red-400">ausstehend</p>
              <Progress 
                value={(() => {
                  const totalPrincipal = store.financings.reduce((sum, f) => sum + f.principalAmount, 0);
                  const remaining = stats.totalRemainingDebt || 0;
                  return totalPrincipal > 0 ? ((totalPrincipal - remaining) / totalPrincipal) * 100 : 0;
                })()} 
                className="mt-2 h-2" 
              />
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Gauge className="h-4 w-4" />
                LTV
              </CardTitle>
            </CardHeader>
            <CardContent>
              <LTVGauge ltv={enhancedKPIs.ltv} />
              <p className="text-xs text-muted-foreground text-center mt-2">Loan-to-Value Ratio</p>
            </CardContent>
          </Card>
        </div>

        {/* Spalte 3: Einnahmen, Ausgaben, Cashflow */}
        <div className="space-y-4">
          <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950 dark:to-emerald-900 hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
                <ArrowUpRight className="h-4 w-4" />
                Einnahmen
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-700 dark:text-emerald-300">{formatCurrency(stats.totalRentIncome || 0)}</div>
              <p className="text-xs text-emerald-600 dark:text-emerald-400">diesen Monat</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900 hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-orange-700 dark:text-orange-300 flex items-center gap-2">
                <ArrowDownRight className="h-4 w-4" />
                Ausgaben
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-700 dark:text-orange-300">{formatCurrency(stats.totalExpenses || 0)}</div>
              <p className="text-xs text-orange-600 dark:text-orange-400">diesen Monat</p>
            </CardContent>
          </Card>
          
          <Card className={`hover:shadow-md transition-shadow ${stats.cashflow >= 0 ? 'bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900' : 'bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950 dark:to-red-900'}`}>
            <CardHeader className="pb-2">
              <CardTitle className={`text-sm font-medium flex items-center gap-2 ${stats.cashflow >= 0 ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                <DollarSign className="h-4 w-4" />
                Cashflow
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${stats.cashflow >= 0 ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                {formatCurrency(stats.cashflow || 0)}
              </div>
              <p className={`text-xs ${stats.cashflow >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                Einnahmen - Ausgaben
              </p>
              <div className="flex items-center gap-1 mt-1">
                {stats.cashflow >= 0 ? (
                  <TrendingUp className="h-3 w-3 text-green-600" />
                ) : (
                  <TrendingDown className="h-3 w-3 text-red-600" />
                )}
                <span className="text-xs text-muted-foreground">p.a. ~{formatCurrency(Math.abs(stats.cashflow || 0) * 12)}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Spalte 4: Energiewert, Immobilien, Mieter */}
        <div className="space-y-4">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Ø Energiewert
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-amber-600">{enhancedKPIs.avgEnergyClass}</div>
              <p className="text-xs text-muted-foreground">Durchschnittliche Energieklasse</p>
              <div className="mt-2 flex gap-1">
                {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map(cls => (
                  <div 
                    key={cls}
                    className={`w-6 h-6 rounded text-xs flex items-center justify-center ${
                      cls === enhancedKPIs.avgEnergyClass 
                        ? 'bg-amber-500 text-white font-bold' 
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                    }`}
                  >
                    {cls}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Home className="h-4 w-4" />
                Immobilien
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{store.properties.length}</div>
              <p className="text-xs text-muted-foreground">im Portfolio</p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Users className="h-4 w-4" />
                Mieter
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{store.tenants.length}</div>
              <p className="text-xs text-muted-foreground">aktive Mietverträge</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ========== WIDGET-BASIERTE DIAGRAMME ========== */}
      
      {/* Row 1: Rendite Dashboard, Zins vs Tilgung, Schuldenverlauf */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Rendite/Kennzahl Dashboard */}
        {isWidgetVisible('renditeKennzahl') && (
          <WidgetWrapper widgetId="renditeKennzahl" editMode={editMode} onToggle={toggleWidget} title="Rendite-Kennzahlen" icon={Target}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Rendite-Kennzahlen
                </CardTitle>
                <CardDescription>Wichtigste Performance-Indikatoren</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Bruttomietrendite</span>
                  <span className="font-bold text-emerald-600">{enhancedKPIs.bruttoMietrendite.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between items-center p-2 rounded-lg bg-blue-50 dark:bg-blue-950">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Eigenkapitalrendite (ROE)</span>
                  <span className="font-bold text-blue-600">{enhancedKPIs.roe.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between items-center p-2 rounded-lg bg-purple-50 dark:bg-purple-950">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Cash-on-Cash Return</span>
                  <span className="font-bold text-purple-600">{enhancedKPIs.cashOnCashReturn.toFixed(2)}%</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Ø Miete/m²</span>
                  <span className="font-bold">{formatCurrency(avgRentPerSqm)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Leerstandsquote</span>
                  <span className="font-bold text-red-600">{enhancedKPIs.leerstandsquote.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Kostenquote</span>
                  <span className="font-bold text-orange-600">{enhancedKPIs.kostenquote.toFixed(1)}%</span>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Zins vs. Tilgung */}
        {isWidgetVisible('zinsVsTilgung') && (
          <WidgetWrapper widgetId="zinsVsTilgung" editMode={editMode} onToggle={toggleWidget} title="Zins vs. Tilgung" icon={Scale}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Scale className="h-5 w-5" />
                  Zins vs. Tilgung
                </CardTitle>
                <CardDescription>Aufteilung der monatlichen Rate</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={zinsVsTilgungData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {zinsVsTilgungData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-6 mt-4">
                  <div className="text-center">
                    <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">Zins</Badge>
                    <div className="text-sm font-bold mt-1">{formatCurrency(enhancedKPIs.monthlyInterest)}</div>
                    <div className="text-xs text-muted-foreground">{enhancedKPIs.zinsAnteil.toFixed(1)}%</div>
                  </div>
                  <div className="text-center">
                    <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">Tilgung</Badge>
                    <div className="text-sm font-bold mt-1">{formatCurrency(enhancedKPIs.monthlyMortgagePayment)}</div>
                    <div className="text-xs text-muted-foreground">{enhancedKPIs.tilgungsAnteil.toFixed(1)}%</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Schuldenverlauf */}
        {isWidgetVisible('schuldenDiagram') && (
          <WidgetWrapper widgetId="schuldenDiagram" editMode={editMode} onToggle={toggleWidget} title="Schuldenverlauf" icon={TrendingDown}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5" />
                  Schuldenverlauf
                </CardTitle>
                <CardDescription>Entwicklung der Restschuld</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={debtHistoryData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                      <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                      <YAxis tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} tick={{ fontSize: 10 }} />
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                      <Area type="monotone" dataKey="schulden" stroke="#ef4444" fill="#fee2e2" className="dark:fill-red-900/30" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}
      </div>

      {/* Row 2: Portfolio nach Städten, Beste Renditen, Wertsteigerung */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Portfolio nach Städten */}
        {isWidgetVisible('portfolioVerteilung') && (
          <WidgetWrapper widgetId="portfolioVerteilung" editMode={editMode} onToggle={toggleWidget} title="Portfolio-Verteilung" icon={PieChartIcon}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChartIcon className="h-5 w-5" />
                  Portfolio nach Städten
                </CardTitle>
                <CardDescription>Verteilung nach Standort</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={cityDistributionData}
                        cx="50%"
                        cy="50%"
                        outerRadius={70}
                        dataKey="value"
                        label={({ name }) => name}
                      >
                        {cityDistributionData.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Beste Renditen */}
        {isWidgetVisible('besteRenditen') && (
          <WidgetWrapper widgetId="besteRenditen" editMode={editMode} onToggle={toggleWidget} title="Beste Renditen" icon={Award}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Beste Renditen (Top 5)
                </CardTitle>
                <CardDescription>Einheiten mit höchster Rendite</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {topYieldUnits.map((unit, index) => (
                    <div key={unit.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors">
                      <div className="flex items-center gap-2">
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          index === 0 ? 'bg-amber-500 text-white' : 
                          index === 1 ? 'bg-gray-400 text-white' : 
                          index === 2 ? 'bg-amber-700 text-white' : 'bg-gray-200 dark:bg-gray-700'
                        }`}>
                          {index + 1}
                        </span>
                        <div>
                          <p className="text-sm font-medium">{unit.property?.name || 'Unbekannt'}</p>
                          <p className="text-xs text-muted-foreground">{unit.unitNumber} • {unit.area}m²</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-emerald-600">{unit.yieldPercentage.toFixed(2)}%</p>
                        <p className="text-xs text-muted-foreground">{formatCurrency(unit.totalRent)}/Mo.</p>
                      </div>
                    </div>
                  ))}
                  {topYieldUnits.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">Keine Daten vorhanden</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Größte Wertsteigerung */}
        {isWidgetVisible('groessteWertsteigerung') && (
          <WidgetWrapper widgetId="groessteWertsteigerung" editMode={editMode} onToggle={toggleWidget} title="Größte Wertsteigerung" icon={TrendingUp}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Größte Wertsteigerung (Top 5)
                </CardTitle>
                <CardDescription>Immobilien mit größter Wertentwicklung</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {topAppreciation.map((property, index) => (
                    <div key={property.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors">
                      <div className="flex items-center gap-2">
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          index === 0 ? 'bg-emerald-500 text-white' : 
                          index === 1 ? 'bg-gray-400 text-white' : 
                          index === 2 ? 'bg-amber-700 text-white' : 'bg-gray-200 dark:bg-gray-700'
                        }`}>
                          {index + 1}
                        </span>
                        <div>
                          <p className="text-sm font-medium">{property.name}</p>
                          <p className="text-xs text-muted-foreground">{property.city}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-emerald-600">+{property.appreciationPercentage.toFixed(1)}%</p>
                        <p className="text-xs text-muted-foreground">{formatCurrency(property.appreciation)}</p>
                      </div>
                    </div>
                  ))}
                  {topAppreciation.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">Keine Daten vorhanden</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}
      </div>

      {/* Row 3: Wertsteigerung Chart, Cashflow Diagram, Ausgaben Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Wertsteigerung Bar Chart */}
        {isWidgetVisible('wertsteigerung') && (
          <WidgetWrapper widgetId="wertsteigerung" editMode={editMode} onToggle={toggleWidget} title="Wertsteigerung" icon={BarChart2}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart2 className="h-5 w-5" />
                  Wertsteigerung seit Kauf
                </CardTitle>
                <CardDescription>Kaufpreis vs. Schätzwert</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={wertsteigerungChartData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                      <XAxis type="number" tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} tick={{ fontSize: 10 }} />
                      <YAxis dataKey="name" type="category" width={80} tick={{ fontSize: 10 }} />
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                      <Legend />
                      <Bar dataKey="kaufpreis" fill="#94a3b8" name="Kaufpreis" />
                      <Bar dataKey="schaetzwert" fill="#10b981" name="Schätzwert" />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Cashflow Diagram */}
        {isWidgetVisible('cashflowDiagram') && (
          <WidgetWrapper widgetId="cashflowDiagram" editMode={editMode} onToggle={toggleWidget} title="Cashflow-Verlauf" icon={LineChartIcon}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChartIcon className="h-5 w-5" />
                  Cashflow-Verlauf
                </CardTitle>
                <CardDescription>Monatliche Entwicklung</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={cashflowChartData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                      <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                      <YAxis tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} tick={{ fontSize: 10 }} />
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                      <Legend />
                      <Area type="monotone" dataKey="einnahmen" fill="#dcfce7" stroke="#10b981" name="Einnahmen" />
                      <Area type="monotone" dataKey="ausgaben" fill="#fee2e2" stroke="#ef4444" name="Ausgaben" />
                      <Line type="monotone" dataKey="cashflow" stroke="#3b82f6" strokeWidth={2} name="Cashflow" />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Ausgaben Chart */}
        {isWidgetVisible('ausgabenChart') && (
          <WidgetWrapper widgetId="ausgabenChart" editMode={editMode} onToggle={toggleWidget} title="Ausgaben-Verteilung" icon={Receipt}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  Ausgaben-Verteilung
                </CardTitle>
                <CardDescription>Nach Kategorien</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={ausgabenDetailedData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {ausgabenDetailedData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}
      </div>

      {/* Row 4: Eigenkapitalrendite, Abschreibungen, Steuern */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Eigenkapitalrendite Gauge */}
        {isWidgetVisible('eigenkapitalrendite') && (
          <WidgetWrapper widgetId="eigenkapitalrendite" editMode={editMode} onToggle={toggleWidget} title="Eigenkapitalrendite" icon={Gauge}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gauge className="h-5 w-5" />
                  Eigenkapitalrendite
                </CardTitle>
                <CardDescription>Return on Equity</CardDescription>
              </CardHeader>
              <CardContent>
                <ROEGauge roe={enhancedKPIs.roe} />
                <div className="mt-4 text-center">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 rounded bg-muted">
                      <p className="text-muted-foreground">Eigenkapital</p>
                      <p className="font-bold">{formatCurrency(enhancedKPIs.netWorth)}</p>
                    </div>
                    <div className="p-2 rounded bg-muted">
                      <p className="text-muted-foreground">Jährl. Cashflow</p>
                      <p className="font-bold">{formatCurrency((stats.cashflow || 0) * 12)}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Abschreibungen */}
        {isWidgetVisible('abschreibungen') && (
          <WidgetWrapper widgetId="abschreibungen" editMode={editMode} onToggle={toggleWidget} title="Abschreibungen" icon={TrendingDown}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5" />
                  Abschreibungen (AfA)
                </CardTitle>
                <CardDescription>Steuerliche Abschreibung</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <p className="text-3xl font-bold text-blue-600">{formatCurrency(totalAnnualDepreciation)}</p>
                  <p className="text-sm text-muted-foreground">Jährliche AfA gesamt</p>
                </div>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={depreciationData}
                        cx="50%"
                        cy="50%"
                        outerRadius={50}
                        dataKey="value"
                        label={({ name }) => name}
                      >
                        {depreciationData.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <Separator className="my-3" />
                <div className="space-y-1 text-sm">
                  {depreciationData.slice(0, 3).map(d => (
                    <div key={d.name} className="flex justify-between">
                      <span className="text-muted-foreground">{d.name}</span>
                      <span className="font-medium">{formatCurrency(d.value)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Steuern */}
        {isWidgetVisible('steuern') && (
          <WidgetWrapper widgetId="steuern" editMode={editMode} onToggle={toggleWidget} title="Steuern" icon={Receipt}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  Steuer-Übersicht
                </CardTitle>
                <CardDescription>Steuerliche Kennzahlen</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center p-2 rounded bg-muted">
                  <span className="text-sm text-muted-foreground">Jahreseinnahmen</span>
                  <span className="font-bold text-emerald-600">{formatCurrency((stats.totalRentIncome || 0) * 12)}</span>
                </div>
                <div className="flex justify-between items-center p-2 rounded bg-muted">
                  <span className="text-sm text-muted-foreground">Jahresausgaben</span>
                  <span className="font-bold text-red-600">{formatCurrency((stats.totalExpenses || 0) * 12)}</span>
                </div>
                <div className="flex justify-between items-center p-2 rounded bg-muted">
                  <span className="text-sm text-muted-foreground">AfA (p.a.)</span>
                  <span className="font-bold text-blue-600">{formatCurrency(totalAnnualDepreciation)}</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center p-2 rounded bg-blue-50 dark:bg-blue-950">
                  <span className="text-sm font-medium">Zu versteuern (geschätzt)</span>
                  <span className="font-bold text-blue-600">
                    {formatCurrency(Math.max(0, ((stats.totalRentIncome || 0) - (stats.totalExpenses || 0)) * 12 - totalAnnualDepreciation))}
                  </span>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}
      </div>

      {/* Row 5: Kaltmiete vs Vergleich, Hausgelder, Sonderumlagen */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Kaltmiete vs Vergleichsmiete */}
        {isWidgetVisible('kaltmieteVsVergleich') && (
          <WidgetWrapper widgetId="kaltmieteVsVergleich" editMode={editMode} onToggle={toggleWidget} title="Kaltmiete vs. Vergleich" icon={BarChart2}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart2 className="h-5 w-5" />
                  Kaltmiete vs. Vergleichsmiete
                </CardTitle>
                <CardDescription>Marktvergleich</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={kaltmieteVsVergleichData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                      <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                      <YAxis tickFormatter={(value) => `${value}`} tick={{ fontSize: 10 }} />
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                      <Legend />
                      <Bar dataKey="kaltmiete" fill="#10b981" name="Kaltmiete" />
                      <Bar dataKey="vergleichsmiete" fill="#94a3b8" name="Vergleichsmiete" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Hausgelder */}
        {isWidgetVisible('hausgelder') && (
          <WidgetWrapper widgetId="hausgelder" editMode={editMode} onToggle={toggleWidget} title="Hausgelder" icon={FileText}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Hausgelder
                </CardTitle>
                <CardDescription>Übersicht nach Immobilien</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {hausgeldData.map(h => (
                    <div key={h.name} className="p-2 rounded-lg bg-muted/50">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{h.name}</span>
                        <span className="font-bold">{formatCurrency(h.total)}</span>
                      </div>
                      <div className="flex gap-2 mt-1">
                        <Badge variant="outline" className="text-xs text-emerald-600">
                          {formatCurrency(h.paid)} bezahlt
                        </Badge>
                        {h.pending > 0 && (
                          <Badge variant="outline" className="text-xs text-orange-600">
                            {formatCurrency(h.pending)} offen
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                  {hausgeldData.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">Keine Daten vorhanden</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Sonderumlagen */}
        {isWidgetVisible('sonderumlagen') && (
          <WidgetWrapper widgetId="sonderumlagen" editMode={editMode} onToggle={toggleWidget} title="Sonderumlagen" icon={AlertOctagon}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertOctagon className="h-5 w-5" />
                  Sonderumlagen
                </CardTitle>
                <CardDescription>Geplante Umlagen</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <AlertOctagon className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Keine Sonderumlagen vorhanden</p>
                  <p className="text-xs">Sonderumlagen werden hier angezeigt</p>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}
      </div>

      {/* Row 6: Nebenkosten, Investitionen, Kautionen */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Nebenkosten */}
        {isWidgetVisible('nebenkosten') && (
          <WidgetWrapper widgetId="nebenkosten" editMode={editMode} onToggle={toggleWidget} title="Nebenkosten" icon={Receipt}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  Nebenkosten
                </CardTitle>
                <CardDescription>Betriebskosten-Übersicht</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Heizung</span>
                    <span className="font-medium">{formatCurrency(store.houseMoney.reduce((sum, h) => sum + h.heating, 0))}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Wasser</span>
                    <span className="font-medium">{formatCurrency(store.houseMoney.reduce((sum, h) => sum + h.water, 0))}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Müll</span>
                    <span className="font-medium">{formatCurrency(store.houseMoney.reduce((sum, h) => sum + h.garbage, 0))}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Versicherung</span>
                    <span className="font-medium">{formatCurrency(store.houseMoney.reduce((sum, h) => sum + h.insurance, 0))}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between items-center font-bold">
                    <span>Gesamt</span>
                    <span>{formatCurrency(store.houseMoney.reduce((sum, h) => sum + h.utilities, 0))}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Investitionen */}
        {isWidgetVisible('investitionen') && (
          <WidgetWrapper widgetId="investitionen" editMode={editMode} onToggle={toggleWidget} title="Investitionen" icon={Wrench}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wrench className="h-5 w-5" />
                  Investitionen
                </CardTitle>
                <CardDescription>Instandhaltungskosten</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <Wrench className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Keine Investitionen erfasst</p>
                  <p className="text-xs">Instandhaltungskosten werden hier angezeigt</p>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Kautionen */}
        {isWidgetVisible('kautionen') && (
          <WidgetWrapper widgetId="kautionen" editMode={editMode} onToggle={toggleWidget} title="Kautionen" icon={PiggyBank}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PiggyBank className="h-5 w-5" />
                  Mieterkautionen
                </CardTitle>
                <CardDescription>Übersicht aller Kautionen</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <p className="text-3xl font-bold text-purple-600">{formatCurrency(totalDeposits)}</p>
                  <p className="text-sm text-muted-foreground">Gesamt Kautionen</p>
                </div>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {store.tenants.slice(0, 5).map(tenant => {
                    const unit = store.units.find(u => u.id === tenant.unitId);
                    return (
                      <div key={tenant.id} className="flex justify-between items-center text-sm">
                        <span className="text-muted-foreground">
                          {tenant.firstName} {tenant.lastName} ({unit?.unitNumber || 'N/A'})
                        </span>
                        <span className="font-medium">{formatCurrency(tenant.deposit)}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}
      </div>

      {/* Row 7: Rücklagen, Grundstückswerte, Banken */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Rücklagen */}
        {isWidgetVisible('ruecklagen') && (
          <WidgetWrapper widgetId="ruecklagen" editMode={editMode} onToggle={toggleWidget} title="Rücklagen" icon={PiggyBank}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PiggyBank className="h-5 w-5" />
                  Erhaltungsrücklagen
                </CardTitle>
                <CardDescription> nach Immobilien</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <p className="text-3xl font-bold text-emerald-600">{formatCurrency(totalReserves)}</p>
                  <p className="text-sm text-muted-foreground">Gesamt Rücklagen</p>
                </div>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {store.properties.filter(p => (p.reserves || 0) > 0).map(property => (
                    <div key={property.id} className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">{property.name}</span>
                      <span className="font-medium">{formatCurrency(property.reserves || 0)}</span>
                    </div>
                  ))}
                  {store.properties.every(p => !p.reserves) && (
                    <p className="text-center text-muted-foreground text-sm">Keine Rücklagen erfasst</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Grundstückswerte */}
        {isWidgetVisible('grundstueckswerte') && (
          <WidgetWrapper widgetId="grundstueckswerte" editMode={editMode} onToggle={toggleWidget} title="Grundstückswerte" icon={Home}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Home className="h-5 w-5" />
                  Grundstückswerte
                </CardTitle>
                <CardDescription>Bodenwerte</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <Home className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Keine Bodenwerte erfasst</p>
                  <p className="text-xs">Grundstückswerte werden hier angezeigt</p>
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}

        {/* Banken */}
        {isWidgetVisible('banken') && (
          <WidgetWrapper widgetId="banken" editMode={editMode} onToggle={toggleWidget} title="Banken" icon={Landmark}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Landmark className="h-5 w-5" />
                  Banken
                </CardTitle>
                <CardDescription>Bankverbindungen</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {bankenData.map(bank => (
                    <div key={bank.name} className="p-2 rounded-lg bg-muted/50">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{bank.name}</span>
                        <Badge variant="outline">{bank.count} Kredit{bank.count > 1 ? 'e' : ''}</Badge>
                      </div>
                      <div className="flex justify-between items-center mt-1 text-xs text-muted-foreground">
                        <span>Restschuld: {formatCurrency(bank.totalDebt)}</span>
                        <span>Rate: {formatCurrency(bank.totalRate)}/Mo.</span>
                      </div>
                    </div>
                  ))}
                  {bankenData.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">Keine Bankverbindungen</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </WidgetWrapper>
        )}
      </div>

      {/* Row 8: Kredite (Full Width) */}
      {isWidgetVisible('kredite') && (
        <WidgetWrapper widgetId="kredite" editMode={editMode} onToggle={toggleWidget} title="Kredite" icon={CreditCard} className="col-span-full">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Kredit-Übersicht
              </CardTitle>
              <CardDescription>Alle Darlehen mit Details</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Immobilie</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead className="text-right">Restschuld</TableHead>
                      <TableHead className="text-right">Zins</TableHead>
                      <TableHead className="text-right">Rate/Mo.</TableHead>
                      <TableHead>Zinsbindung bis</TableHead>
                      <TableHead className="text-right">Fortschritt</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {kreditData.map(loan => {
                      const progress = loan.principalAmount > 0 
                        ? ((loan.principalAmount - loan.remainingDebt) / loan.principalAmount) * 100 
                        : 0;
                      const isExpiringSoon = loan.fixedInterestUntil && 
                        differenceInMonths(parseISO(loan.fixedInterestUntil), new Date()) < 24;
                      
                      return (
                        <TableRow key={loan.id}>
                          <TableCell className="font-medium">{loan.propertyName}</TableCell>
                          <TableCell>{loan.bankName}</TableCell>
                          <TableCell className="text-right">{formatCurrency(loan.remainingDebt)}</TableCell>
                          <TableCell className="text-right">{loan.interestRate.toFixed(2)}%</TableCell>
                          <TableCell className="text-right">{formatCurrency(loan.monthlyRate)}</TableCell>
                          <TableCell>
                            {loan.fixedInterestUntil ? (
                              <div className="flex items-center gap-1">
                                <span>{format(parseISO(loan.fixedInterestUntil), 'dd.MM.yyyy')}</span>
                                {isExpiringSoon && (
                                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                                )}
                              </div>
                            ) : '-'}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center gap-2">
                              <Progress value={progress} className="h-2 w-16" />
                              <span className="text-xs text-muted-foreground">{progress.toFixed(0)}%</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {kreditData.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                          Keine Kredite vorhanden
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </WidgetWrapper>
      )}

      {/* Widget Configuration Dialog */}
      <Dialog open={configDialogOpen} onOpenChange={setConfigDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Dashboard anpassen</DialogTitle>
            <DialogDescription>
              Wählen Sie aus, welche Widgets auf dem Dashboard angezeigt werden sollen.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 py-4">
            {widgetConfig
              .sort((a, b) => a.order - b.order)
              .map(widget => {
                const meta = WIDGET_METADATA[widget.id];
                return (
                  <div 
                    key={widget.id}
                    className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors ${
                      widget.visible 
                        ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-800' 
                        : 'bg-gray-50 dark:bg-gray-900 border-gray-200 dark:border-gray-800'
                    }`}
                    onClick={() => toggleWidget(widget.id)}
                  >
                    <Switch checked={widget.visible} onCheckedChange={() => {}} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{meta?.name || widget.id}</p>
                      <p className="text-xs text-muted-foreground truncate">{meta?.description || ''}</p>
                    </div>
                  </div>
                );
              })}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfigDialogOpen(false)}>
              Schließen
            </Button>
            <Button onClick={resetToDefault}>
              <RotateCcw className="h-4 w-4 mr-1" />
              Standard wiederherstellen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default DashboardSection;
