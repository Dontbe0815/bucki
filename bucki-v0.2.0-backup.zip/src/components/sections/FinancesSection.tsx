'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { 
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle 
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, 
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from '@/components/ui/select';
import { toast } from 'sonner';
import { useStore } from '@/lib/store';
import { useI18n } from '@/contexts/I18nContext';
import type { Transaction, TransactionType, TransactionCategory } from '@/lib/types';
import { categoryLabels } from './constants';
import { 
  Plus, Edit2, Trash2, DollarSign, FileSpreadsheet, Receipt, 
  PiggyBank, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

function FinancesSection() {
  const store = useStore();
  const { t, formatCurrency, formatDate } = useI18n();
  const [activeSubTab, setActiveSubTab] = useState('transactions');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterProperty, setFilterProperty] = useState<string>('all');
  const [formData, setFormData] = useState({
    propertyId: '',
    unitId: '',
    type: 'income' as TransactionType,
    category: 'rent' as TransactionCategory,
    amount: 0,
    date: '',
    description: '',
    isRecurring: false,
    recurringInterval: 'monthly' as 'monthly' | 'quarterly' | 'yearly',
  });

  const filteredTransactions = store.transactions.filter(t => {
    if (filterType !== 'all' && t.type !== filterType) return false;
    if (filterProperty !== 'all' && t.propertyId !== filterProperty) return false;
    return true;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const totalIncome = filteredTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = filteredTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  // Hausgeld-Berechnungen
  const totalHouseMoneyIncome = store.houseMoney.reduce((sum, h) => sum + h.totalAmount, 0);
  const totalHouseMoneyExpenses = store.houseMoney.reduce((sum, h) => 
    sum + h.utilities + h.water + h.heating + h.garbage + h.insurance + h.other + h.administrativeFee + h.maintenanceReserve, 0);

  // Nebenkosten-Berechnungen
  const totalUtilityCosts = store.utilitySettlements.reduce((sum, s) => sum + s.totalCosts, 0);
  const totalUtilityBalance = store.utilitySettlements.reduce((sum, s) => sum + s.balance, 0);

  // Rücklagen-Berechnungen
  const totalReserves = store.properties.reduce((sum, p) => sum + (p.reserves || 0), 0);
  const monthlyReserveContributions = store.properties.reduce((sum, p) => sum + (p.monthlyReserve || 0), 0);
  const recommendedReserves = store.properties.reduce((sum, p) => sum + (p.purchasePrice || 0) * 0.02, 0);

  // Ausgaben-Chart-Daten für Nebenkosten
  const expenseCategoryData = [
    { name: 'Umlagebare NK', value: 2500, color: '#10b981' },
    { name: 'Nicht umlagebare NK', value: 800, color: '#f59e0b' },
    { name: 'Verwaltung', value: 400, color: '#3b82f6' },
    { name: 'Instandhaltung', value: 1200, color: '#ef4444' },
  ];

  const openNewDialog = () => {
    setEditingTransaction(null);
    setFormData({
      propertyId: store.properties[0]?.id || '',
      unitId: '',
      type: 'income',
      category: 'rent',
      amount: 0,
      date: new Date().toISOString().split('T')[0],
      description: '',
      isRecurring: false,
      recurringInterval: 'monthly',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setFormData({
      propertyId: transaction.propertyId || '',
      unitId: transaction.unitId || '',
      type: transaction.type,
      category: transaction.category,
      amount: transaction.amount,
      date: transaction.date,
      description: transaction.description,
      isRecurring: transaction.isRecurring,
      recurringInterval: transaction.recurringInterval || 'monthly',
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.amount || !formData.date) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    if (editingTransaction) {
      store.updateTransaction(editingTransaction.id, formData);
      toast.success('Transaktion aktualisiert');
    } else {
      store.addTransaction(formData);
      toast.success('Transaktion hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      store.deleteTransaction(deletingId);
      toast.success('Transaktion gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const getPropertyName = (propertyId?: string) => {
    if (!propertyId) return '-';
    const property = store.properties.find(p => p.id === propertyId);
    return property?.name || 'Unbekannt';
  };

  const unitsForProperty = formData.propertyId 
    ? store.units.filter(u => u.propertyId === formData.propertyId)
    : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Finanzen</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neue Transaktion
        </Button>
      </div>

      {/* Tabs für Unterpunkte */}
      <Tabs value={activeSubTab} onValueChange={setActiveSubTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="transactions" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            Transaktionen
          </TabsTrigger>
          <TabsTrigger value="housemoney" className="flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4" />
            Hausgelder
          </TabsTrigger>
          <TabsTrigger value="utilitycosts" className="flex items-center gap-2">
            <Receipt className="h-4 w-4" />
            Nebenkosten
          </TabsTrigger>
          <TabsTrigger value="reserves" className="flex items-center gap-2">
            <PiggyBank className="h-4 w-4" />
            Rücklagen
          </TabsTrigger>
        </TabsList>

        {/* Transaktionen Tab */}
        <TabsContent value="transactions" className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Einnahmen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-emerald-600">{formatCurrency(totalIncome)}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Ausgaben</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{formatCurrency(totalExpenses)}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Saldo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${totalIncome - totalExpenses >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {formatCurrency(totalIncome - totalExpenses)}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex gap-4">
            <Select value={filterType} onValueChange={(value: 'all' | 'income' | 'expense') => setFilterType(value)}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle</SelectItem>
                <SelectItem value="income">Einnahmen</SelectItem>
                <SelectItem value="expense">Ausgaben</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterProperty} onValueChange={setFilterProperty}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Immobilie filtern" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Immobilien</SelectItem>
                {store.properties.map(p => (
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Transactions Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-left p-4 font-medium text-gray-600">Datum</th>
                      <th className="text-left p-4 font-medium text-gray-600">Typ</th>
                      <th className="text-left p-4 font-medium text-gray-600">Kategorie</th>
                      <th className="text-left p-4 font-medium text-gray-600">Beschreibung</th>
                      <th className="text-left p-4 font-medium text-gray-600">Immobilie</th>
                      <th className="text-right p-4 font-medium text-gray-600">Betrag</th>
                      <th className="text-right p-4 font-medium text-gray-600">Aktionen</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTransactions.map((transaction) => (
                      <tr key={transaction.id} className="border-b hover:bg-gray-50">
                        <td className="p-4">{formatDate(transaction.date)}</td>
                        <td className="p-4">
                          <Badge variant={transaction.type === 'income' ? 'default' : 'destructive'}>
                            {transaction.type === 'income' ? 'Einnahme' : 'Ausgabe'}
                          </Badge>
                        </td>
                        <td className="p-4">{categoryLabels[transaction.category]}</td>
                        <td className="p-4">
                          {transaction.description}
                          {transaction.isRecurring && (
                            <Badge variant="outline" className="ml-2">Wiederkehrend</Badge>
                          )}
                        </td>
                        <td className="p-4">{getPropertyName(transaction.propertyId)}</td>
                        <td className={`p-4 text-right font-medium ${transaction.type === 'income' ? 'text-emerald-600' : 'text-red-600'}`}>
                          {transaction.type === 'income' ? '+' : '-'}{formatCurrency(transaction.amount)}
                        </td>
                        <td className="p-4">
                          <div className="flex gap-2 justify-end">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => openEditDialog(transaction)}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-red-600"
                              onClick={() => {
                                setDeletingId(transaction.id);
                                setDeleteDialogOpen(true);
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filteredTransactions.length === 0 && (
                <div className="py-12 text-center text-gray-500">
                  Keine Transaktionen gefunden
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hausgelder Tab */}
        <TabsContent value="housemoney" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950 dark:to-emerald-900">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-emerald-700 dark:text-emerald-300">
                  <div className="flex items-center gap-2">
                    <ArrowUpRight className="h-4 w-4" />
                    Gesamteinnahmen
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-emerald-600">{formatCurrency(totalHouseMoneyIncome)}</div>
                <p className="text-xs text-muted-foreground mt-1">Hausgeldzahlungen</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950 dark:to-red-900">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-red-700 dark:text-red-300">
                  <div className="flex items-center gap-2">
                    <ArrowDownRight className="h-4 w-4" />
                    Gesamtausgaben
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{formatCurrency(totalHouseMoneyExpenses)}</div>
                <p className="text-xs text-muted-foreground mt-1">Betriebskosten & Rücklagen</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Saldo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(totalHouseMoneyIncome - totalHouseMoneyExpenses)}</div>
                <p className="text-xs text-muted-foreground mt-1">Aktuelle Bilanz</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5" />
                Hausgeld-Verwaltung
              </CardTitle>
              <CardDescription>
                Verwalten Sie Hausgelder für Eigentumswohnungen
              </CardDescription>
            </CardHeader>
            <CardContent className="py-12 text-center">
              <FileSpreadsheet className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Hausgeld-Verwaltung</h3>
              <p className="text-gray-500">Verwalten Sie Hausgelder für Eigentumswohnungen</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Nebenkosten Tab */}
        <TabsContent value="utilitycosts" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Gesamtkosten</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{formatCurrency(totalUtilityCosts)}</div>
                <p className="text-xs text-muted-foreground mt-1">Alle Nebenkosten</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Saldo (Abrechnungen)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${totalUtilityBalance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {formatCurrency(totalUtilityBalance)}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {totalUtilityBalance >= 0 ? 'Nachzahlungen' : 'Guthaben'}
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Abrechnungen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{store.utilitySettlements.length}</div>
                <p className="text-xs text-muted-foreground mt-1">Erstellte Abrechnungen</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Ausgaben-Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Nebenkosten-Verteilung</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={expenseCategoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {expenseCategoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Nebenkosten-Tabelle */}
            <Card>
              <CardHeader>
                <CardTitle>Abrechnungen</CardTitle>
                <CardDescription>Übersicht der Nebenkostenabrechnungen</CardDescription>
              </CardHeader>
              <CardContent>
                {store.utilitySettlements.length === 0 ? (
                  <div className="py-8 text-center text-muted-foreground">
                    <Receipt className="h-10 w-10 mx-auto mb-3 opacity-50" />
                    <p>Noch keine Abrechnungen vorhanden</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {store.utilitySettlements.slice(0, 5).map(settlement => (
                      <div key={settlement.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">Jahr {settlement.year}</p>
                          <p className="text-sm text-muted-foreground">{formatDate(settlement.startDate)} - {formatDate(settlement.endDate)}</p>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold ${settlement.balance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                            {formatCurrency(settlement.balance)}
                          </p>
                          <Badge variant={settlement.status === 'accepted' ? 'default' : 'secondary'}>
                            {settlement.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Rücklagen Tab */}
        <TabsContent value="reserves" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950 dark:to-emerald-900">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PiggyBank className="h-5 w-5" />
                  Gesamte Rücklagen
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-emerald-600">{formatCurrency(totalReserves)}</div>
                <p className="text-sm text-muted-foreground mt-1">Aktuell verfügbar</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Monatliche Einzahlungen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(monthlyReserveContributions)}</div>
                <p className="text-sm text-muted-foreground">in alle Rücklagen</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Empfohlene Rücklage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{formatCurrency(recommendedReserves)}</div>
                <p className="text-sm text-muted-foreground">2% des Kaufpreises p.a.</p>
              </CardContent>
            </Card>
          </div>

          {/* Rücklagen-Fortschritt */}
          <Card>
            <CardHeader>
              <CardTitle>Rücklagen-Status</CardTitle>
              <CardDescription>
                Ist-Soll-Vergleich der Rücklagen
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Rücklagen-Deckung</span>
                  <span className="text-sm text-muted-foreground">
                    {recommendedReserves > 0 ? ((totalReserves / recommendedReserves) * 100).toFixed(0) : 0}%
                  </span>
                </div>
                <Progress value={recommendedReserves > 0 ? (totalReserves / recommendedReserves) * 100 : 0} className="h-3" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Ist: {formatCurrency(totalReserves)}</span>
                  <span>Soll: {formatCurrency(recommendedReserves)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Rücklagen nach Immobilien */}
          <Card>
            <CardHeader>
              <CardTitle>Rücklagen nach Immobilien</CardTitle>
            </CardHeader>
            <CardContent>
              {store.properties.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground">
                  <PiggyBank className="h-10 w-10 mx-auto mb-3 opacity-50" />
                  <p>Noch keine Immobilien vorhanden</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {store.properties.map(property => (
                    <div key={property.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">{property.name}</p>
                        <p className="text-sm text-muted-foreground">{property.address}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">{formatCurrency(property.reserves || 0)}</p>
                        <p className="text-xs text-muted-foreground">+ {formatCurrency(property.monthlyReserve || 0)}/Monat</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Transaction Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingTransaction ? 'Transaktion bearbeiten' : 'Neue Transaktion'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div>
              <Label>Typ</Label>
              <Select 
                value={formData.type} 
                onValueChange={(value: TransactionType) => setFormData({ ...formData, type: value, category: value === 'income' ? 'rent' : 'repairs' })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="income">Einnahme</SelectItem>
                  <SelectItem value="expense">Ausgabe</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Kategorie</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value: TransactionCategory) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(categoryLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Betrag (€)</Label>
              <Input 
                type="number"
                value={formData.amount} 
                onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Datum</Label>
              <Input 
                type="date"
                value={formData.date} 
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>
            <div>
              <Label>Immobilie</Label>
              <Select 
                value={formData.propertyId} 
                onValueChange={(value) => setFormData({ ...formData, propertyId: value, unitId: '' })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  {store.properties.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Einheit</Label>
              <Select 
                value={formData.unitId || 'none'} 
                onValueChange={(value) => setFormData({ ...formData, unitId: value === 'none' ? '' : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Keine</SelectItem>
                  {unitsForProperty.map(u => (
                    <SelectItem key={u.id} value={u.id}>{u.unitNumber}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label>Beschreibung</Label>
              <Input 
                value={formData.description} 
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div className="col-span-2 flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch 
                  checked={formData.isRecurring} 
                  onCheckedChange={(checked) => setFormData({ ...formData, isRecurring: checked })}
                />
                <Label>Wiederkehrend</Label>
              </div>
              {formData.isRecurring && (
                <Select 
                  value={formData.recurringInterval} 
                  onValueChange={(value: 'monthly' | 'quarterly' | 'yearly') => setFormData({ ...formData, recurringInterval: value })}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Monatlich</SelectItem>
                    <SelectItem value="quarterly">Quartalsweise</SelectItem>
                    <SelectItem value="yearly">Jährlich</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Transaktion löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie diese Transaktion wirklich löschen?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default FinancesSection;
