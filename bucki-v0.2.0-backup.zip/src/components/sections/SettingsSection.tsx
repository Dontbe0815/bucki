'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useTheme } from 'next-themes';
import { useI18n } from '@/contexts/I18nContext';
import { useStore } from '@/lib/store';
import { 
  getSecuritySettings, 
  saveSecuritySettings, 
  setPin, 
  autoLockOptions 
} from '@/lib/security';
import {
  getNotificationSettings,
  saveNotificationSettings,
} from '@/lib/notifications';
import { 
  Shield, Bell, Palette, Lock, Key, Building2, Sparkles, 
  Cloud, CloudUpload, CloudDownload, HardDrive, RefreshCw, 
  CheckCircle, AlertCircle, Info, ExternalLink, Clock
} from 'lucide-react';

// Backup Settings Interface
interface BackupSettings {
  autoBackup: boolean;
  backupInterval: 'daily' | 'weekly' | 'monthly';
  lastBackup: string | null;
  cloudProvider: 'none' | 'google-drive' | 'icloud';
  autoLoad: boolean;
  googleDriveConnected: boolean;
  icloudConnected: boolean;
}

// Default Backup Settings
const defaultBackupSettings: BackupSettings = {
  autoBackup: false,
  backupInterval: 'daily',
  lastBackup: null,
  cloudProvider: 'none',
  autoLoad: false,
  googleDriveConnected: false,
  icloudConnected: false,
};

// Load/Save Backup Settings
function getBackupSettings(): BackupSettings {
  if (typeof window === 'undefined') return defaultBackupSettings;
  const saved = localStorage.getItem('bucki-backup-settings');
  return saved ? JSON.parse(saved) : defaultBackupSettings;
}

function saveBackupSettings(settings: BackupSettings): void {
  localStorage.setItem('bucki-backup-settings', JSON.stringify(settings));
}

function SettingsSection() {
  const { t, language, setLanguage, currency, setCurrency } = useI18n();
  const { theme, setTheme } = useTheme();
  const store = useStore();
  
  // Extract base theme (light/dark) and design theme (default/banking/fancy)
  const currentTheme = theme || 'light';
  const isDark = currentTheme.includes('dark') || currentTheme === 'dark';
  const designTheme = currentTheme.replace('-dark', '').replace('dark-', '');
  
  const setDesignTheme = (design: string) => {
    if (design === 'default') {
      setTheme(isDark ? 'dark' : 'light');
    } else {
      setTheme(isDark ? `${design}-dark` : design);
    }
    toast.success('Design geändert');
  };
  
  const toggleDarkMode = (dark: boolean) => {
    if (designTheme === 'default' || designTheme === 'light' || designTheme === 'dark') {
      setTheme(dark ? 'dark' : 'light');
    } else {
      setTheme(dark ? `${designTheme}-dark` : designTheme);
    }
  };
  
  // Security settings
  const securitySettings = getSecuritySettings();
  const [pinEnabled, setPinEnabled] = useState(securitySettings.pinEnabled);
  const [autoLockTime, setAutoLockTime] = useState(securitySettings.autoLockTime);
  const [showChangePin, setShowChangePin] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  
  // Notification settings
  const notificationSettings = getNotificationSettings();
  const [taskNotifications, setTaskNotifications] = useState(notificationSettings.dueTasks);
  const [contractNotifications, setContractNotifications] = useState(notificationSettings.contractExpirations);
  
  // Backup settings
  const [backupSettings, setBackupSettings] = useState<BackupSettings>(getBackupSettings);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);

  // Save backup settings when they change
  useEffect(() => {
    saveBackupSettings(backupSettings);
  }, [backupSettings]);

  const handlePinToggle = async (enabled: boolean) => {
    setPinEnabled(enabled);
    saveSecuritySettings({ pinEnabled: enabled });
    toast.success(enabled ? 'PIN-Schutz aktiviert' : 'PIN-Schutz deaktiviert');
  };

  const handleAutoLockChange = (time: number) => {
    setAutoLockTime(time);
    saveSecuritySettings({ autoLockTime: time });
    toast.success('Automatische Sperre aktualisiert');
  };

  const handleChangePin = async () => {
    if (newPin.length < 4) {
      toast.error('PIN muss mindestens 4 Stellen haben');
      return;
    }
    if (newPin !== confirmPin) {
      toast.error('PINs stimmen nicht überein');
      return;
    }
    const result = await setPin(newPin);
    if (result.success) {
      setNewPin('');
      setConfirmPin('');
      setShowChangePin(false);
      toast.success('PIN geändert');
    } else {
      toast.error(result.error || 'Fehler beim Ändern der PIN');
    }
  };

  const handleNotificationChange = (key: 'dueTasks' | 'contractExpirations', value: boolean) => {
    const newSettings = { ...notificationSettings, [key]: value };
    saveNotificationSettings(newSettings);
    if (key === 'dueTasks') setTaskNotifications(value);
    if (key === 'contractExpirations') setContractNotifications(value);
    toast.success('Benachrichtigungseinstellungen aktualisiert');
  };

  // Backup Functions
  const handleLocalBackup = async () => {
    setIsBackingUp(true);
    try {
      const data = store.exportData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `bucki-backup-${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
      
      setBackupSettings(prev => ({
        ...prev,
        lastBackup: new Date().toISOString()
      }));
      
      toast.success('Backup erfolgreich erstellt');
    } catch (error) {
      toast.error('Fehler beim Erstellen des Backups');
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleGoogleDriveConnect = () => {
    // Simulate Google Drive connection
    // In production, this would open OAuth flow
    toast.info('Google Drive Verbindung wird hergestellt...');
    setTimeout(() => {
      setBackupSettings(prev => ({
        ...prev,
        googleDriveConnected: true,
        cloudProvider: 'google-drive'
      }));
      toast.success('Google Drive erfolgreich verbunden');
    }, 1500);
  };

  const handleiCloudConnect = () => {
    // Simulate iCloud connection
    // In production, this would use iCloud JS API
    toast.info('iCloud Verbindung wird hergestellt...');
    setTimeout(() => {
      setBackupSettings(prev => ({
        ...prev,
        icloudConnected: true,
        cloudProvider: 'icloud'
      }));
      toast.success('iCloud erfolgreich verbunden');
    }, 1500);
  };

  const handleCloudBackup = async () => {
    if (backupSettings.cloudProvider === 'none') {
      toast.error('Bitte verbinden Sie zuerst einen Cloud-Dienst');
      return;
    }
    
    setIsBackingUp(true);
    try {
      // Simulate cloud backup
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Save to localStorage as "cloud backup"
      const data = store.exportData();
      localStorage.setItem(`bucki-cloud-backup-${backupSettings.cloudProvider}`, JSON.stringify(data));
      
      setBackupSettings(prev => ({
        ...prev,
        lastBackup: new Date().toISOString()
      }));
      
      toast.success(`Backup auf ${backupSettings.cloudProvider === 'google-drive' ? 'Google Drive' : 'iCloud'} erfolgreich`);
    } catch (error) {
      toast.error('Fehler beim Cloud-Backup');
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleRestoreFromCloud = async () => {
    if (backupSettings.cloudProvider === 'none') {
      toast.error('Kein Cloud-Dienst verbunden');
      return;
    }
    
    setIsRestoring(true);
    try {
      // Simulate restore from cloud
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const savedData = localStorage.getItem(`bucki-cloud-backup-${backupSettings.cloudProvider}`);
      if (savedData) {
        const data = JSON.parse(savedData);
        store.importData(data);
        toast.success('Daten erfolgreich wiederhergestellt');
      } else {
        toast.error('Kein Backup gefunden');
      }
    } catch (error) {
      toast.error('Fehler beim Wiederherstellen');
    } finally {
      setIsRestoring(false);
    }
  };

  const formatDate = (isoString: string) => {
    try {
      return new Date(isoString).toLocaleDateString('de-DE', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return 'Nie';
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">{t.nav.settings}</h1>

      {/* Appearance Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="h-5 w-5" />
            {t.settings.appearance}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Design Theme Selection */}
          <div className="space-y-3">
            <div>
              <p className="font-medium">Design-Vorlage</p>
              <p className="text-sm text-gray-500">Wählen Sie ein Design-Thema</p>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => setDesignTheme('default')}
                className={`relative p-4 rounded-lg border-2 transition-all ${
                  designTheme === 'default' || designTheme === 'light' || designTheme === 'dark'
                    ? 'border-emerald-500 bg-emerald-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex flex-col items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-200 to-gray-400" />
                  <span className="text-sm font-medium">Standard</span>
                </div>
              </button>
              <button
                onClick={() => setDesignTheme('banking')}
                className={`relative p-4 rounded-lg border-2 transition-all ${
                  designTheme === 'banking'
                    ? 'border-emerald-500 bg-emerald-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex flex-col items-center gap-2">
                  <Building2 className="w-8 h-8 text-blue-900" />
                  <span className="text-sm font-medium">Banking</span>
                  <span className="text-xs text-gray-500">Seriös & Luxuriös</span>
                </div>
              </button>
              <button
                onClick={() => setDesignTheme('fancy')}
                className={`relative p-4 rounded-lg border-2 transition-all ${
                  designTheme === 'fancy'
                    ? 'border-emerald-500 bg-emerald-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex flex-col items-center gap-2">
                  <Sparkles className="w-8 h-8 text-pink-500" />
                  <span className="text-sm font-medium">Fancy</span>
                  <span className="text-xs text-gray-500">Modern & Bunt</span>
                </div>
              </button>
            </div>
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t.settings.theme}</p>
              <p className="text-sm text-gray-500">Hell oder Dunkel-Modus</p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant={!isDark ? 'default' : 'outline'} 
                size="sm"
                onClick={() => toggleDarkMode(false)}
              >
                Hell
              </Button>
              <Button 
                variant={isDark ? 'default' : 'outline'} 
                size="sm"
                onClick={() => toggleDarkMode(true)}
              >
                Dunkel
              </Button>
            </div>
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t.settings.language}</p>
              <p className="text-sm text-gray-500">Sprache der Oberfläche</p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant={language === 'de' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setLanguage('de')}
              >
                Deutsch
              </Button>
              <Button 
                variant={language === 'en' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setLanguage('en')}
              >
                English
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Backup & Sync Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5" />
            Backup & Synchronisation
          </CardTitle>
          <CardDescription>
            Sichern Sie Ihre Daten und synchronisieren Sie zwischen Geräten
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Local Backup */}
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-start gap-3">
              <HardDrive className="h-5 w-5 text-blue-600 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium text-blue-900">Lokales Backup</h4>
                <p className="text-sm text-blue-700 mt-1">
                  Erstellen Sie ein Backup auf Ihrem Gerät. Dies speichert alle Ihre Immobilien, 
                  Mieter, Finanzen und Einstellungen in einer JSON-Datei.
                </p>
                <div className="mt-3 flex gap-2">
                  <Button 
                    size="sm" 
                    onClick={handleLocalBackup}
                    disabled={isBackingUp}
                  >
                    {isBackingUp ? (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <CloudUpload className="h-4 w-4 mr-2" />
                    )}
                    Backup erstellen
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.accept = '.json';
                      input.onchange = (e) => {
                        const file = (e.target as HTMLInputElement).files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = () => {
                            try {
                              const data = JSON.parse(reader.result as string);
                              store.importData(data);
                              toast.success('Backup erfolgreich wiederhergestellt');
                            } catch {
                              toast.error('Ungültiges Backup-Format');
                            }
                          };
                          reader.readAsText(file);
                        }
                      };
                      input.click();
                    }}
                  >
                    <CloudDownload className="h-4 w-4 mr-2" />
                    Backup laden
                  </Button>
                </div>
              </div>
            </div>
          </div>
          
          <Separator />
          
          {/* Auto Backup Toggle */}
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Automatisches Backup</p>
              <p className="text-sm text-gray-500">Backup automatisch erstellen</p>
            </div>
            <Switch 
              checked={backupSettings.autoBackup}
              onCheckedChange={(checked) => 
                setBackupSettings(prev => ({ ...prev, autoBackup: checked }))
              }
            />
          </div>
          
          {backupSettings.autoBackup && (
            <>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Backup-Intervall</p>
                  <p className="text-sm text-gray-500">Wie oft soll gesichert werden?</p>
                </div>
                <div className="flex gap-2">
                  {[
                    { value: 'daily', label: 'Täglich' },
                    { value: 'weekly', label: 'Wöchentlich' },
                    { value: 'monthly', label: 'Monatlich' },
                  ].map((option) => (
                    <Button
                      key={option.value}
                      variant={backupSettings.backupInterval === option.value ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => 
                        setBackupSettings(prev => ({ 
                          ...prev, 
                          backupInterval: option.value as BackupSettings['backupInterval']
                        }))
                      }
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </div>
            </>
          )}
          
          <Separator />
          
          {/* Google Drive */}
          <div className="p-4 border rounded-lg">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 via-green-400 to-blue-500 rounded-lg flex items-center justify-center">
                  <Cloud className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h4 className="font-medium">Google Drive</h4>
                  <p className="text-sm text-gray-500">
                    Sichern Sie Ihre Daten in Google Drive und greifen Sie von jedem Gerät darauf zu.
                  </p>
                </div>
              </div>
              {backupSettings.googleDriveConnected && (
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Verbunden
                </Badge>
              )}
            </div>
            
            {backupSettings.googleDriveConnected ? (
              <div className="mt-4 space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Automatisch laden beim Start</span>
                  <Switch 
                    checked={backupSettings.autoLoad && backupSettings.cloudProvider === 'google-drive'}
                    onCheckedChange={(checked) => 
                      setBackupSettings(prev => ({ 
                        ...prev, 
                        autoLoad: checked,
                        cloudProvider: checked ? 'google-drive' : prev.cloudProvider
                      }))
                    }
                  />
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    onClick={handleCloudBackup}
                    disabled={isBackingUp}
                  >
                    <CloudUpload className="h-4 w-4 mr-2" />
                    Jetzt sichern
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={handleRestoreFromCloud}
                    disabled={isRestoring}
                  >
                    <CloudDownload className="h-4 w-4 mr-2" />
                    Wiederherstellen
                  </Button>
                </div>
                <div className="p-3 bg-amber-50 rounded text-xs text-amber-800">
                  <Info className="h-3 w-3 inline mr-1" />
                  <strong>So funktioniert es:</strong> Ihre Daten werden verschlüsselt in Ihrem 
                  Google Drive gespeichert. Sie können sie von jedem Gerät wiederherstellen, 
                  auf dem Sie sich mit Ihrem Google-Konto anmelden.
                </div>
              </div>
            ) : (
              <div className="mt-4">
                <Button onClick={handleGoogleDriveConnect}>
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Mit Google Drive verbinden
                </Button>
                <p className="text-xs text-gray-500 mt-2">
                  Erfordert Google-Konto. Ihre Daten werden sicher verschlüsselt übertragen.
                </p>
              </div>
            )}
          </div>
          
          {/* iCloud */}
          <div className="p-4 border rounded-lg">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center">
                  <Cloud className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h4 className="font-medium">iCloud</h4>
                  <p className="text-sm text-gray-500">
                    Sichern Sie Ihre Daten in iCloud für nahtlose Synchronisation auf allen Apple-Geräten.
                  </p>
                </div>
              </div>
              {backupSettings.icloudConnected && (
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Verbunden
                </Badge>
              )}
            </div>
            
            {backupSettings.icloudConnected ? (
              <div className="mt-4 space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Automatisch laden beim Start</span>
                  <Switch 
                    checked={backupSettings.autoLoad && backupSettings.cloudProvider === 'icloud'}
                    onCheckedChange={(checked) => 
                      setBackupSettings(prev => ({ 
                        ...prev, 
                        autoLoad: checked,
                        cloudProvider: checked ? 'icloud' : prev.cloudProvider
                      }))
                    }
                  />
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    onClick={handleCloudBackup}
                    disabled={isBackingUp}
                  >
                    <CloudUpload className="h-4 w-4 mr-2" />
                    Jetzt sichern
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={handleRestoreFromCloud}
                    disabled={isRestoring}
                  >
                    <CloudDownload className="h-4 w-4 mr-2" />
                    Wiederherstellen
                  </Button>
                </div>
                <div className="p-3 bg-amber-50 rounded text-xs text-amber-800">
                  <Info className="h-3 w-3 inline mr-1" />
                  <strong>So funktioniert es:</strong> Ihre Daten werden in Ihrem iCloud Drive 
                  gespeichert und automatisch auf allen Ihren Apple-Geräten synchronisiert. 
                  Öffnen Sie Bucki auf einem anderen Gerät und aktivieren Sie "Automatisch laden".
                </div>
              </div>
            ) : (
              <div className="mt-4">
                <Button onClick={handleiCloudConnect}>
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Mit iCloud verbinden
                </Button>
                <p className="text-xs text-gray-500 mt-2">
                  Erfordert Apple-ID. Funktioniert auf iPhone, iPad und Mac automatisch.
                </p>
              </div>
            )}
          </div>
          
          {/* Last Backup Info */}
          {backupSettings.lastBackup && (
            <div className="text-sm text-gray-500 flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Letztes Backup: {formatDate(backupSettings.lastBackup)}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Sicherheit
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">PIN-Schutz</p>
              <p className="text-sm text-gray-500">App mit PIN sperren</p>
            </div>
            <Switch 
              checked={pinEnabled} 
              onCheckedChange={handlePinToggle}
            />
          </div>
          
          {pinEnabled && (
            <>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Automatische Sperre</p>
                  <p className="text-sm text-gray-500">App nach Inaktivität sperren</p>
                </div>
                <div className="flex gap-2">
                  {autoLockOptions.map((option) => (
                    <Button
                      key={option.value}
                      variant={autoLockTime === option.value ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handleAutoLockChange(option.value)}
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">PIN ändern</p>
                  <p className="text-sm text-gray-500">Neue PIN festlegen</p>
                </div>
                <Button variant="outline" onClick={() => setShowChangePin(true)}>
                  <Key className="h-4 w-4 mr-2" />
                  Ändern
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Benachrichtigungen
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Aufgaben-Erinnerungen</p>
              <p className="text-sm text-gray-500">Benachrichtigung bei fälligen Aufgaben</p>
            </div>
            <Switch 
              checked={taskNotifications} 
              onCheckedChange={(v) => handleNotificationChange('dueTasks', v)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Vertrags-Ablauf</p>
              <p className="text-sm text-gray-500">Benachrichtigung bei Vertragsende</p>
            </div>
            <Switch 
              checked={contractNotifications} 
              onCheckedChange={(v) => handleNotificationChange('contractExpirations', v)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Change PIN Dialog */}
      {showChangePin && (
        <Card className="border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="text-lg">Neue PIN eingeben</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Neue PIN</Label>
              <Input 
                type="password"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="4-6 Ziffern"
                className="text-center text-2xl tracking-widest"
              />
            </div>
            <div>
              <Label>PIN bestätigen</Label>
              <Input 
                type="password"
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="PIN wiederholen"
                className="text-center text-2xl tracking-widest"
              />
            </div>
          </CardContent>
          <CardFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowChangePin(false)}>Abbrechen</Button>
            <Button onClick={handleChangePin} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </CardFooter>
        </Card>
      )}

      {/* App Info */}
      <Card>
        <CardContent className="py-6">
          <div className="text-center text-sm text-gray-500">
            <p>Bucki - Immobilien-Verwaltung v2.0.0</p>
            <p className="mt-1">© 2024 Bucki. Alle Rechte vorbehalten.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default SettingsSection;
