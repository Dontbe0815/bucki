'use client';

import { useState, useMemo, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle 
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, 
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from '@/components/ui/select';
import { toast } from 'sonner';
import { useStore } from '@/lib/store';
import { useI18n } from '@/contexts/I18nContext';
import type { Financing, Unit, Property, BankAccount, BankTransactionCategory } from '@/lib/types';
import { BANK_TRANSACTION_CATEGORY_LABELS, GERMAN_BANK_FORMATS } from '@/lib/types';
import { 
  Plus, Edit2, Trash2, CreditCard, TrendingDown, TrendingUp, Building2, 
  Landmark, Percent, Calendar, AlertTriangle, Upload, FileDown, Inbox,
  Loader2, Check, X, ChevronDown, ChevronUp, CheckCircle, FileSpreadsheet,
  ArrowUpDown
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line, ComposedChart, Area
} from 'recharts';
import { format, differenceInMonths, addYears, addMonths, subMonths } from 'date-fns';
import { de } from 'date-fns/locale';

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

// LTV Gauge Component (Large)
function LTVGauge({ ltv, size = 'large' }: { ltv: number; size?: 'small' | 'large' }) {
  const getLTVColor = (ltv: number) => {
    if (ltv <= 60) return '#10b981';
    if (ltv <= 75) return '#f59e0b';
    if (ltv <= 85) return '#f97316';
    return '#ef4444';
  };
  
  const getLTVStatus = (ltv: number) => {
    if (ltv <= 60) return 'Ausgezeichnet';
    if (ltv <= 75) return 'Gut';
    if (ltv <= 85) return 'Akzeptabel';
    return 'Kritisch';
  };
  
  const dimensions = size === 'large' 
    ? { width: 'w-48', height: 'h-24', textSize: 'text-3xl', strokeWidth: 10 } 
    : { width: 'w-24', height: 'h-12', textSize: 'text-lg', strokeWidth: 8 };
  
  const radius = size === 'large' ? 40 : 35;
  const strokeDasharray = Math.min(ltv, 100) * 1.26 * (size === 'large' ? 1 : 0.8);
  
  return (
    <div className="flex flex-col items-center">
      <div className={`relative ${dimensions.width} ${dimensions.height}`}>
        <svg viewBox="0 0 100 50" className="w-full h-full">
          {/* Background arc */}
          <path
            d="M 10 50 A 40 40 0 0 1 90 50"
            fill="none"
            stroke="currentColor"
            strokeWidth={dimensions.strokeWidth}
            strokeLinecap="round"
            className="text-muted"
          />
          {/* Value arc */}
          <path
            d="M 10 50 A 40 40 0 0 1 90 50"
            fill="none"
            stroke={getLTVColor(ltv)}
            strokeWidth={dimensions.strokeWidth}
            strokeLinecap="round"
            strokeDasharray={`${strokeDasharray} 126`}
          />
        </svg>
        <div className="absolute inset-0 flex items-end justify-center pb-1">
          <span className={`${dimensions.textSize} font-bold`} style={{ color: getLTVColor(ltv) }}>
            {ltv.toFixed(1)}%
          </span>
        </div>
      </div>
      {size === 'large' && (
        <div className="mt-2 text-center">
          <p className="text-sm font-medium" style={{ color: getLTVColor(ltv) }}>
            {getLTVStatus(ltv)}
          </p>
        </div>
      )}
    </div>
  );
}

function FinancingSection() {
  const store = useStore();
  const { t, formatCurrency, formatDate, language } = useI18n();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingFinancing, setEditingFinancing] = useState<Financing | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'import'>('overview');
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' }>({ key: 'remainingDebt', direction: 'desc' });
  const [formData, setFormData] = useState({
    propertyId: '',
    unitId: '',
    bankName: '',
    loanNumber: '',
    principalAmount: 0,
    interestRate: 0,
    repaymentRate: 0,
    monthlyRate: 0,
    remainingDebt: 0,
    startDate: '',
    endDate: '',
    fixedInterestUntil: '',
    notes: '',
  });

  // Bank Import State
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [parsedTransactions, setParsedTransactions] = useState<Array<{
    originalDate: string;
    valueDate: string;
    amount: number;
    currency: string;
    description: string;
    counterpartyName: string;
    counterpartyIban?: string;
    category?: BankTransactionCategory;
    confidence?: number;
    selected?: boolean;
  }>>([]);
  const [parseResult, setParseResult] = useState<{
    format: string;
    dateRange: { from: string; to: string };
  } | null>(null);
  const [importStep, setImportStep] = useState<'upload' | 'preview' | 'importing' | 'complete'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);

  // Calculate unique banks
  const uniqueBanks = useMemo(() => {
    const banks = new Set(store.financings.map(f => f.bankName));
    return Array.from(banks);
  }, [store.financings]);

  // Calculate total debt and monthly payment
  const totalDebt = store.financings.reduce((sum, f) => sum + f.remainingDebt, 0);
  const totalMonthlyPayment = store.financings.reduce((sum, f) => sum + f.monthlyRate, 0);
  const totalPrincipalAmount = store.financings.reduce((sum, f) => sum + f.principalAmount, 0);

  // Calculate LTV
  const totalMarketValue = store.properties.reduce((sum, p) => sum + p.marketValue, 0);
  const totalEstimatedValue = store.properties.reduce((sum, p) => sum + (p.estimatedValue || p.marketValue), 0);
  const ltv = totalEstimatedValue > 0 ? (totalDebt / totalEstimatedValue) * 100 : 0;

  // Calculate Zins vs Tilgung
  const monthlyInterest = store.financings.reduce((sum, f) => {
    return sum + (f.remainingDebt * (f.interestRate / 100) / 12);
  }, 0);
  const monthlyRepayment = totalMonthlyPayment - monthlyInterest;
  const repaymentPercentage = totalMonthlyPayment > 0 ? (monthlyRepayment / totalMonthlyPayment) * 100 : 0;
  const interestPercentage = totalMonthlyPayment > 0 ? (monthlyInterest / totalMonthlyPayment) * 100 : 0;

  // LTV pro Bank
  const ltvPerBank = useMemo(() => {
    const bankDebts: Record<string, number> = {};
    store.financings.forEach(f => {
      if (!bankDebts[f.bankName]) bankDebts[f.bankName] = 0;
      bankDebts[f.bankName] += f.remainingDebt;
    });
    return Object.entries(bankDebts).map(([bank, debt]) => ({
      bank,
      debt,
      ltv: totalEstimatedValue > 0 ? (debt / totalEstimatedValue) * 100 : 0,
    })).sort((a, b) => b.debt - a.debt);
  }, [store.financings, totalEstimatedValue]);

  // Ranking nach Zinsbindungsende
  const financingByFixedInterest = useMemo(() => {
    return store.financings
      .filter(f => f.fixedInterestUntil)
      .map(f => {
        const fixedUntil = new Date(f.fixedInterestUntil!);
        const monthsRemaining = differenceInMonths(fixedUntil, new Date());
        return {
          ...f,
          monthsRemaining,
          formattedDate: format(fixedUntil, 'MM.yyyy', { locale: de }),
        };
      })
      .sort((a, b) => a.monthsRemaining - b.monthsRemaining);
  }, [store.financings]);

  // Ranking nach höchster Verschuldung
  const financingByDebt = useMemo(() => {
    return [...store.financings]
      .sort((a, b) => b.remainingDebt - a.remainingDebt)
      .slice(0, 10);
  }, [store.financings]);

  // Schuldenentwicklung (Debt development over months)
  const debtDevelopmentData = useMemo(() => {
    const months: Array<{ month: string; debt: number; equity: number; label: string }> = [];
    const now = new Date();
    
    for (let i = 11; i >= 0; i--) {
      const monthDate = subMonths(now, i);
      const monthLabel = format(monthDate, 'MMM yyyy', { locale: de });
      const monthKey = format(monthDate, 'yyyy-MM');
      
      // Simulate debt reduction over time (simplified projection)
      const monthsAgo = i;
      const avgMonthlyRepayment = monthlyRepayment;
      const projectedDebt = Math.max(0, totalDebt + (monthsAgo * avgMonthlyRepayment * store.financings.length));
      
      months.push({
        month: monthKey,
        label: monthLabel,
        debt: projectedDebt,
        equity: totalEstimatedValue - projectedDebt,
      });
    }
    
    return months;
  }, [totalDebt, monthlyRepayment, totalEstimatedValue, store.financings.length]);

  // Units with their financings
  const unitsWithFinancings = useMemo(() => {
    return store.units.map(unit => {
      const property = store.properties.find(p => p.id === unit.propertyId);
      // Filter financings by unitId if available, otherwise by propertyId
      const unitFinancings = store.financings.filter(f => {
        if (f.unitId) return f.unitId === unit.id;
        return f.propertyId === unit.propertyId;
      });
      return {
        ...unit,
        property,
        financings: unitFinancings,
        totalDebt: unitFinancings.reduce((sum, f) => sum + f.remainingDebt, 0),
        monthlyRate: unitFinancings.reduce((sum, f) => sum + f.monthlyRate, 0),
      };
    });
  }, [store.units, store.properties, store.financings]);

  // Sorted financing list for table
  const sortedFinancings = useMemo(() => {
    const sortable = [...store.financings];
    sortable.sort((a, b) => {
      let aValue: number | string = 0;
      let bValue: number | string = 0;
      
      switch (sortConfig.key) {
        case 'propertyId':
          aValue = getPropertyName(a.propertyId);
          bValue = getPropertyName(b.propertyId);
          break;
        case 'bankName':
          aValue = a.bankName;
          bValue = b.bankName;
          break;
        case 'remainingDebt':
          aValue = a.remainingDebt;
          bValue = b.remainingDebt;
          break;
        case 'interestRate':
          aValue = a.interestRate;
          bValue = b.interestRate;
          break;
        case 'monthlyRate':
          aValue = a.monthlyRate;
          bValue = b.monthlyRate;
          break;
        case 'fixedInterestUntil':
          aValue = a.fixedInterestUntil ? new Date(a.fixedInterestUntil).getTime() : Infinity;
          bValue = b.fixedInterestUntil ? new Date(b.fixedInterestUntil).getTime() : Infinity;
          break;
        default:
          aValue = a.remainingDebt;
          bValue = b.remainingDebt;
      }
      
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortConfig.direction === 'asc' 
          ? aValue.localeCompare(bValue) 
          : bValue.localeCompare(aValue);
      }
      
      return sortConfig.direction === 'asc' 
        ? (aValue as number) - (bValue as number) 
        : (bValue as number) - (aValue as number);
    });
    return sortable;
  }, [store.financings, sortConfig]);

  // Chart data
  const zinsVsTilgungData = [
    { name: 'Zins', value: monthlyInterest, color: '#f59e0b' },
    { name: 'Tilgung', value: monthlyRepayment, color: '#10b981' },
  ];

  const ltvPerBankChartData = ltvPerBank.map(item => ({
    name: item.bank,
    ltv: item.ltv,
    debt: item.debt,
  }));

  const fixedInterestRankingData = financingByFixedInterest.slice(0, 10).map(f => ({
    name: f.bankName,
    months: f.monthsRemaining,
    remainingDebt: f.remainingDebt,
  }));

  const debtRankingData = financingByDebt.map(f => ({
    name: f.bankName,
    debt: f.remainingDebt,
    progress: f.principalAmount > 0 ? ((f.principalAmount - f.remainingDebt) / f.principalAmount) * 100 : 0,
  }));

  // Bank Import Handlers
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      processFile(files[0]);
    }
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  }, []);

  const simulateParseFile = (content: string, fileName: string) => {
    return new Promise<{
      transactions: Array<{
        originalDate: string;
        valueDate: string;
        amount: number;
        currency: string;
        description: string;
        counterpartyName: string;
        counterpartyIban?: string;
      }>;
      format: string;
      dateRange: { from: string; to: string };
    }>((resolve) => {
      setTimeout(() => {
        const demoTransactions = [];
        const now = new Date();
        const demoData = [
          { desc: 'Darlehensrate KD-12345', amount: -1250.00, counterparty: 'Sparkasse Köln' },
          { desc: 'Zinszahlung Darlehen', amount: -450.00, counterparty: 'Volksbank' },
          { desc: 'Darlehensrate KD-67890', amount: -980.00, counterparty: 'ING' },
        ];
        for (let i = 0; i < demoData.length; i++) {
          const date = new Date(now);
          date.setDate(date.getDate() - (i * 30));
          demoTransactions.push({
            originalDate: date.toISOString().split('T')[0],
            valueDate: date.toISOString().split('T')[0],
            amount: demoData[i].amount,
            currency: 'EUR',
            description: demoData[i].desc,
            counterpartyName: demoData[i].counterparty,
          });
        }
        const dates = demoTransactions.map(t => t.originalDate).sort();
        resolve({
          transactions: demoTransactions,
          format: fileName.endsWith('.csv') ? 'CSV' : 'MT940',
          dateRange: {
            from: dates[0] || now.toISOString().split('T')[0],
            to: dates[dates.length - 1] || now.toISOString().split('T')[0],
          },
        });
      }, 1500);
    });
  };

  const categorizeTransactionLocal = (amount: number, description: string, counterpartyName: string): {
    category: BankTransactionCategory;
    confidence: number;
  } => {
    const desc = description.toLowerCase();
    if (desc.includes('darlehen') || desc.includes('kredit') || desc.includes('zins')) {
      return { category: 'mortgage_payment', confidence: 90 };
    }
    return { category: 'other', confidence: 50 };
  };

  const processFile = async (file: File) => {
    if (!selectedAccountId) {
      toast.error(language === 'de' ? 'Bitte wählen Sie zuerst ein Bankkonto aus' : 'Please select a bank account first');
      return;
    }
    setIsProcessing(true);
    try {
      const content = await file.text();
      const result = await simulateParseFile(content, file.name);
      const categorized = result.transactions.map(t => {
        const { category, confidence } = categorizeTransactionLocal(t.amount, t.description, t.counterpartyName);
        return { ...t, category, confidence, selected: true };
      });
      setParsedTransactions(categorized);
      setParseResult({ format: result.format, dateRange: result.dateRange });
      setImportStep('preview');
    } catch (error) {
      toast.error(language === 'de' ? 'Fehler beim Verarbeiten der Datei' : 'Error processing file');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImport = async () => {
    if (!selectedAccountId || !parseResult) return;
    setImportStep('importing');
    const selectedTransactions = parsedTransactions.filter(t => t.selected);
    // Simulate import
    setTimeout(() => {
      setImportStep('complete');
      toast.success(language === 'de' 
        ? `${selectedTransactions.length} Transaktionen erfolgreich importiert` 
        : `${selectedTransactions.length} transactions imported successfully`);
    }, 1000);
  };

  const resetImport = () => {
    setImportStep('upload');
    setParsedTransactions([]);
    setParseResult(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const openNewDialog = () => {
    setEditingFinancing(null);
    setFormData({
      propertyId: store.properties[0]?.id || '',
      unitId: '',
      bankName: '',
      loanNumber: '',
      principalAmount: 0,
      interestRate: 3.5,
      repaymentRate: 2.0,
      monthlyRate: 0,
      remainingDebt: 0,
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      fixedInterestUntil: '',
      notes: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (financing: Financing) => {
    setEditingFinancing(financing);
    setFormData({
      propertyId: financing.propertyId,
      unitId: financing.unitId || '',
      bankName: financing.bankName,
      loanNumber: financing.loanNumber,
      principalAmount: financing.principalAmount,
      interestRate: financing.interestRate,
      repaymentRate: financing.repaymentRate,
      monthlyRate: financing.monthlyRate,
      remainingDebt: financing.remainingDebt,
      startDate: financing.startDate,
      endDate: financing.endDate,
      fixedInterestUntil: financing.fixedInterestUntil || '',
      notes: financing.notes,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.bankName || !formData.propertyId) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    if (editingFinancing) {
      store.updateFinancing(editingFinancing.id, formData);
      toast.success('Finanzierung aktualisiert');
    } else {
      store.addFinancing(formData);
      toast.success('Finanzierung hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      store.deleteFinancing(deletingId);
      toast.success('Finanzierung gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const getPropertyName = (propertyId: string) => {
    const property = store.properties.find(p => p.id === propertyId);
    return property?.name || 'Unbekannt';
  };

  const getUnitName = (unitId?: string) => {
    if (!unitId) return '-';
    const unit = store.units.find(u => u.id === unitId);
    return unit?.unitNumber || '-';
  };

  const calculateLTV = (financing: Financing) => {
    const property = store.properties.find(p => p.id === financing.propertyId);
    if (!property) return 0;
    const value = property.estimatedValue || property.marketValue;
    return value > 0 ? (financing.remainingDebt / value) * 100 : 0;
  };

  const handleSort = (key: string) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  };

  const unitsForProperty = formData.propertyId 
    ? store.units.filter(u => u.propertyId === formData.propertyId)
    : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Finanzierungen</h1>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => setActiveTab('import')}
            className="border-emerald-600 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950"
          >
            <Upload className="h-4 w-4 mr-2" /> Bank-Import
          </Button>
          <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="h-4 w-4 mr-2" /> Neue Finanzierung
          </Button>
        </div>
      </div>

      {/* Oben: Kennzahlen-Karten */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-300 flex items-center gap-2">
              <Landmark className="h-4 w-4" />
              Banken
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-700 dark:text-blue-300">{uniqueBanks.length}</div>
            <p className="text-xs text-blue-600 dark:text-blue-400">verschiedene Kreditgeber</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-950 dark:to-amber-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-700 dark:text-amber-300 flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Aktive Kredite
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-700 dark:text-amber-300">{store.financings.length}</div>
            <p className="text-xs text-amber-600 dark:text-amber-400">offene Darlehen</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950 dark:to-red-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-red-700 dark:text-red-300 flex items-center gap-2">
              <TrendingDown className="h-4 w-4" />
              Restschuld gesamt
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-700 dark:text-red-300">{formatCurrency(totalDebt)}</div>
            <p className="text-xs text-red-600 dark:text-red-400">von {formatCurrency(totalPrincipalAmount)} aufgenommen</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-700 dark:text-purple-300 flex items-center gap-2">
              <Percent className="h-4 w-4" />
              LTV gesamt
            </CardTitle>
          </CardHeader>
          <CardContent>
            <LTVGauge ltv={ltv} size="small" />
          </CardContent>
        </Card>
      </div>

      {/* Zweite Reihe: Monatliche Rate, Zins vs Tilgung */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Monatliche Gesamtrate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalMonthlyPayment)}</div>
            <div className="mt-2 flex gap-4 text-xs">
              <span className="text-amber-600">Zins: {formatCurrency(monthlyInterest)}</span>
              <span className="text-emerald-600">Tilgung: {formatCurrency(monthlyRepayment)}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Ø Zinssatz</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {store.financings.length > 0 
                ? (store.financings.reduce((sum, f) => sum + f.interestRate, 0) / store.financings.length).toFixed(2)
                : '0.00'}%
            </div>
            <p className="text-xs text-muted-foreground">durchschnittlicher Zinssatz</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Ø Tilgungssatz</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {store.financings.length > 0 
                ? (store.financings.reduce((sum, f) => sum + f.repaymentRate, 0) / store.financings.length).toFixed(2)
                : '0.00'}%
            </div>
            <p className="text-xs text-muted-foreground">durchschnittlicher Tilgungssatz</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs: Übersicht / Import */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'overview' | 'import')}>
        <TabsList>
          <TabsTrigger value="overview">Kredite & Einheiten</TabsTrigger>
          <TabsTrigger value="import">Bank-Import</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Mitte: Kredit-Übersichtstabelle */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Kredit-Übersicht
              </CardTitle>
              <CardDescription>
                Alle Kredite mit Details - klicken Sie auf Spaltenüberschriften zum Sortieren
              </CardDescription>
            </CardHeader>
            <CardContent>
              {store.financings.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">
                  <CreditCard className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Keine Finanzierungen vorhanden</p>
                  <Button onClick={openNewDialog} className="mt-4" variant="outline">
                    <Plus className="h-4 w-4 mr-2" /> Erste Finanzierung hinzufügen
                  </Button>
                </div>
              ) : (
                <ScrollArea className="max-h-96">
                  <table className="w-full">
                    <thead className="bg-muted/50 sticky top-0">
                      <tr>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer hover:bg-muted"
                          onClick={() => handleSort('propertyId')}
                        >
                          <div className="flex items-center gap-1">
                            Immobilie
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer hover:bg-muted"
                          onClick={() => handleSort('bankName')}
                        >
                          <div className="flex items-center gap-1">
                            Bank
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer hover:bg-muted"
                          onClick={() => handleSort('remainingDebt')}
                        >
                          <div className="flex items-center justify-end gap-1">
                            Restschuld
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer hover:bg-muted"
                          onClick={() => handleSort('interestRate')}
                        >
                          <div className="flex items-center justify-end gap-1">
                            Zins
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer hover:bg-muted"
                          onClick={() => handleSort('monthlyRate')}
                        >
                          <div className="flex items-center justify-end gap-1">
                            Rate
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                        <th 
                          className="text-center p-3 font-medium cursor-pointer hover:bg-muted"
                          onClick={() => handleSort('fixedInterestUntil')}
                        >
                          <div className="flex items-center justify-center gap-1">
                            Zinsbindung bis
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                        <th className="text-center p-3 font-medium">LTV</th>
                        <th className="text-right p-3 font-medium">Aktionen</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedFinancings.map((financing) => {
                        const ltvValue = calculateLTV(financing);
                        const fixedInterestDate = financing.fixedInterestUntil 
                          ? new Date(financing.fixedInterestUntil)
                          : null;
                        const monthsUntilFixedInterestEnd = fixedInterestDate 
                          ? differenceInMonths(fixedInterestDate, new Date())
                          : null;
                        
                        return (
                          <tr key={financing.id} className="border-b hover:bg-muted/30">
                            <td className="p-3">
                              <div>
                                <p className="font-medium">{getPropertyName(financing.propertyId)}</p>
                                {financing.unitId && (
                                  <p className="text-xs text-muted-foreground">
                                    Einheit: {getUnitName(financing.unitId)}
                                  </p>
                                )}
                              </div>
                            </td>
                            <td className="p-3">
                              <Badge variant="outline">{financing.bankName}</Badge>
                            </td>
                            <td className="p-3 text-right font-medium text-red-600 dark:text-red-400">
                              {formatCurrency(financing.remainingDebt)}
                            </td>
                            <td className="p-3 text-right">
                              <span className="text-amber-600 font-medium">{financing.interestRate.toFixed(2)}%</span>
                            </td>
                            <td className="p-3 text-right">
                              {formatCurrency(financing.monthlyRate)}/Mt.
                            </td>
                            <td className="p-3 text-center">
                              {financing.fixedInterestUntil ? (
                                <div>
                                  <p className="text-sm">{format(new Date(financing.fixedInterestUntil), 'MM.yyyy')}</p>
                                  {monthsUntilFixedInterestEnd !== null && (
                                    <Badge 
                                      variant={monthsUntilFixedInterestEnd < 24 ? 'destructive' : monthsUntilFixedInterestEnd < 60 ? 'secondary' : 'default'}
                                      className="text-xs mt-1"
                                    >
                                      {monthsUntilFixedInterestEnd < 0 
                                        ? 'Ablauf' 
                                        : `${monthsUntilFixedInterestEnd} Mo.`}
                                    </Badge>
                                  )}
                                </div>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </td>
                            <td className="p-3 text-center">
                              <Badge 
                                variant={ltvValue <= 60 ? 'default' : ltvValue <= 75 ? 'secondary' : 'destructive'}
                                className={ltvValue <= 60 ? 'bg-emerald-100 text-emerald-800' : ''}
                              >
                                {ltvValue.toFixed(1)}%
                              </Badge>
                            </td>
                            <td className="p-3">
                              <div className="flex gap-1 justify-end">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => openEditDialog(financing)}
                                >
                                  <Edit2 className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  className="text-red-600"
                                  onClick={() => {
                                    setDeletingId(financing.id);
                                    setDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </ScrollArea>
              )}
            </CardContent>
          </Card>

          {/* Unten: Diagramme (2 Spalten Layout) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 1. LTV insgesamt (Gauge Chart) */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Percent className="h-5 w-5" />
                  LTV insgesamt
                </CardTitle>
                <CardDescription>Loan-to-Value Verhältnis</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center py-8">
                <LTVGauge ltv={ltv} size="large" />
                <div className="mt-4 grid grid-cols-3 gap-4 w-full text-center">
                  <div>
                    <p className="text-sm text-muted-foreground">Immobilienwert</p>
                    <p className="font-bold">{formatCurrency(totalEstimatedValue)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Restschuld</p>
                    <p className="font-bold text-red-600">{formatCurrency(totalDebt)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Eigenkapital</p>
                    <p className="font-bold text-emerald-600">{formatCurrency(totalEstimatedValue - totalDebt)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 2. LTV pro Bank (Horizontal Bar Chart) */}
            <Card>
              <CardHeader>
                <CardTitle>LTV pro Bank</CardTitle>
                <CardDescription>Verteilung der Verschuldung nach Kreditgebern</CardDescription>
              </CardHeader>
              <CardContent>
                {ltvPerBank.length > 0 ? (
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={ltvPerBankChartData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis type="number" unit="%" className="text-xs" />
                        <YAxis type="category" dataKey="name" width={100} className="text-xs" />
                        <Tooltip 
                          formatter={(value: number, name: string) => [
                            name === 'ltv' ? `${value.toFixed(1)}%` : formatCurrency(value),
                            name === 'ltv' ? 'LTV' : 'Restschuld'
                          ]}
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                        />
                        <Bar dataKey="ltv" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-64 flex items-center justify-center text-muted-foreground">
                    Keine Finanzierungen vorhanden
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 3. Ranking kürzeste Zinsbindungen (Bar Chart) */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Kürzeste Zinsbindungen
                </CardTitle>
                <CardDescription>Kredite mit baldigem Zinsbindungsende</CardDescription>
              </CardHeader>
              <CardContent>
                {financingByFixedInterest.length > 0 ? (
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={fixedInterestRankingData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis type="number" label={{ value: 'Monate', position: 'bottom', className: 'text-xs' }} className="text-xs" />
                        <YAxis type="category" dataKey="name" width={100} className="text-xs" />
                        <Tooltip 
                          formatter={(value: number) => [`${value} Monate`, 'Verbleibend']}
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                        />
                        <Bar dataKey="months" fill="#f59e0b" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-64 flex items-center justify-center text-muted-foreground">
                    Keine Zinsbindungsdaten vorhanden
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 4. Ranking höchste Verschuldung (Bar Chart) */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5" />
                  Höchste Verschuldung
                </CardTitle>
                <CardDescription>Top 10 Kredite nach Restschuld</CardDescription>
              </CardHeader>
              <CardContent>
                {financingByDebt.length > 0 ? (
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {financingByDebt.map((f, index) => {
                      const progress = f.principalAmount > 0 
                        ? ((f.principalAmount - f.remainingDebt) / f.principalAmount) * 100 
                        : 0;
                      return (
                        <div key={f.id} className="flex items-center gap-3">
                          <span className="text-sm font-medium text-muted-foreground w-6">#{index + 1}</span>
                          <div className="flex-1">
                            <div className="flex justify-between mb-1">
                              <span className="text-sm font-medium">{f.bankName}</span>
                              <span className="text-sm text-red-600 font-bold">{formatCurrency(f.remainingDebt)}</span>
                            </div>
                            <Progress value={progress} className="h-2" />
                          </div>
                          <span className="text-xs text-muted-foreground w-12">{progress.toFixed(0)}% getilgt</span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="h-64 flex items-center justify-center text-muted-foreground">
                    Keine Finanzierungen vorhanden
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 5. Zins vs Tilgung (Pie Chart) */}
            <Card>
              <CardHeader>
                <CardTitle>Zins vs. Tilgung</CardTitle>
                <CardDescription>Aufteilung der monatlichen Gesamtrate</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={zinsVsTilgungData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {zinsVsTilgungData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-6 mt-4">
                  <div className="text-center">
                    <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">Zins</Badge>
                    <div className="text-sm font-bold mt-1">{formatCurrency(monthlyInterest)}</div>
                    <div className="text-xs text-muted-foreground">{interestPercentage.toFixed(1)}%</div>
                  </div>
                  <div className="text-center">
                    <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">Tilgung</Badge>
                    <div className="text-sm font-bold mt-1">{formatCurrency(monthlyRepayment)}</div>
                    <div className="text-xs text-muted-foreground">{repaymentPercentage.toFixed(1)}%</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 6. Schuldenentwicklung (Line Chart) */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Schuldenentwicklung
                </CardTitle>
                <CardDescription>Verlauf der letzten 12 Monate</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={debtDevelopmentData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="label" className="text-xs" tick={{ fontSize: 10 }} />
                      <YAxis className="text-xs" tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} />
                      <Tooltip 
                        formatter={(value: number, name: string) => [
                          formatCurrency(value),
                          name === 'debt' ? 'Restschuld' : 'Eigenkapital'
                        ]}
                        contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                        labelFormatter={(label) => `Monat: ${label}`}
                      />
                      <Legend />
                      <Area 
                        type="monotone" 
                        dataKey="equity" 
                        name="Eigenkapital"
                        fill="#10b981" 
                        fillOpacity={0.3}
                        stroke="#10b981"
                      />
                      <Line 
                        type="monotone" 
                        dataKey="debt" 
                        name="Restschuld"
                        stroke="#ef4444" 
                        strokeWidth={2}
                        dot={{ fill: '#ef4444', r: 4 }}
                      />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="import" className="space-y-4">
          {/* Account Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Landmark className="h-5 w-5" />
                {language === 'de' ? 'Bankkonto auswählen' : 'Select Bank Account'}
              </CardTitle>
              <CardDescription>
                {language === 'de' 
                  ? 'Wählen Sie das Konto, auf das die Transaktionen importiert werden sollen' 
                  : 'Select the account to import transactions to'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder={language === 'de' ? 'Bankkonto wählen...' : 'Select bank account...'} />
                </SelectTrigger>
                <SelectContent>
                  {store.bankAccounts.map(account => (
                    <SelectItem key={account.id} value={account.id}>
                      <div className="flex items-center gap-2">
                        <span>{account.name}</span>
                        <span className="text-muted-foreground text-sm">
                          ({account.bankName})
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {store.bankAccounts.length === 0 && (
                <p className="text-sm text-muted-foreground mt-2">
                  Keine Bankkonten vorhanden. Erstellen Sie zuerst ein Bankkonto.
                </p>
              )}
            </CardContent>
          </Card>

          {/* File Drop Zone */}
          {importStep === 'upload' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileDown className="h-5 w-5" />
                  {language === 'de' ? 'Bankauszug importieren' : 'Import Bank Statement'}
                </CardTitle>
                <CardDescription>
                  {language === 'de'
                    ? 'Laden Sie CSV-, MT940- oder CAMT-Dateien hoch'
                    : 'Upload CSV, MT940, or CAMT files'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  ref={dropRef}
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    isDragging 
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950' 
                      : 'border-muted-foreground/25 hover:border-muted-foreground/50'
                  }`}
                  onDragEnter={handleDragEnter}
                  onDragLeave={handleDragLeave}
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                >
                  {isProcessing ? (
                    <div className="flex flex-col items-center gap-4">
                      <Loader2 className="h-12 w-12 text-emerald-600 animate-spin" />
                      <p className="text-lg font-medium">
                        {language === 'de' ? 'Datei wird verarbeitet...' : 'Processing file...'}
                      </p>
                    </div>
                  ) : (
                    <>
                      <Inbox className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <p className="text-lg font-medium mb-2">
                        {language === 'de' 
                          ? 'Datei hierher ziehen' 
                          : 'Drag and drop file here'}
                      </p>
                      <p className="text-sm text-muted-foreground mb-4">
                        {language === 'de'
                          ? 'oder klicken Sie zum Durchsuchen'
                          : 'or click to browse'}
                      </p>
                      <input
                        ref={fileInputRef}
                        type="file"
                        className="hidden"
                        accept=".csv,.mt940,.sta,.xml"
                        onChange={handleFileSelect}
                      />
                      <Button 
                        onClick={() => fileInputRef.current?.click()}
                        disabled={!selectedAccountId}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        {language === 'de' ? 'Datei auswählen' : 'Select File'}
                      </Button>
                    </>
                  )}
                </div>
                
                <div className="mt-4 flex flex-wrap gap-2">
                  {GERMAN_BANK_FORMATS.slice(0, 4).map(format => (
                    <Badge key={format.bankIdentifier} variant="outline" className="text-xs">
                      {format.name}
                    </Badge>
                  ))}
                  <Badge variant="outline" className="text-xs">MT940</Badge>
                  <Badge variant="outline" className="text-xs">CAMT.052</Badge>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Preview */}
          {importStep === 'preview' && parseResult && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileSpreadsheet className="h-5 w-5" />
                  {language === 'de' ? 'Transaktionsvorschau' : 'Transaction Preview'}
                </CardTitle>
                <CardDescription>
                  {format(new Date(parseResult.dateRange.from), 'dd.MM.yyyy')} - {format(new Date(parseResult.dateRange.to), 'dd.MM.yyyy')} | {parseResult.format}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ScrollArea className="h-64 rounded-md border">
                  <div className="divide-y">
                    {parsedTransactions.map((transaction, index) => (
                      <div key={index} className="p-3 hover:bg-muted/50">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <input
                              type="checkbox"
                              checked={transaction.selected}
                              onChange={(e) => {
                                const updated = [...parsedTransactions];
                                updated[index].selected = e.target.checked;
                                setParsedTransactions(updated);
                              }}
                              className="rounded"
                            />
                            <div>
                              <p className="font-medium text-sm">{transaction.description}</p>
                              <p className="text-xs text-muted-foreground">
                                {transaction.counterpartyName} | {format(new Date(transaction.valueDate), 'dd.MM.yyyy')}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`font-bold ${transaction.amount >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                              {transaction.amount >= 0 ? '+' : ''}{formatCurrency(Math.abs(transaction.amount))}
                            </p>
                            {transaction.category && (
                              <Badge variant="outline" className="text-xs">
                                {transaction.confidence}% sicher
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                <div className="flex justify-between">
                  <Button variant="outline" onClick={resetImport}>
                    <X className="h-4 w-4 mr-2" />
                    Abbrechen
                  </Button>
                  <Button onClick={handleImport} className="bg-emerald-600 hover:bg-emerald-700">
                    <Check className="h-4 w-4 mr-2" />
                    {parsedTransactions.filter(t => t.selected).length} Transaktionen importieren
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Importing */}
          {importStep === 'importing' && (
            <Card>
              <CardContent className="py-12 text-center">
                <Loader2 className="h-12 w-12 mx-auto text-emerald-600 animate-spin mb-4" />
                <p className="text-lg font-medium">
                  {language === 'de' ? 'Transaktionen werden importiert...' : 'Importing transactions...'}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Complete */}
          {importStep === 'complete' && (
            <Card>
              <CardContent className="py-12 text-center">
                <CheckCircle className="h-12 w-12 mx-auto text-emerald-600 mb-4" />
                <p className="text-lg font-medium mb-4">
                  {language === 'de' ? 'Import erfolgreich!' : 'Import successful!'}
                </p>
                <Button onClick={resetImport}>
                  {language === 'de' ? 'Neuen Import starten' : 'Start new import'}
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Financing Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingFinancing ? 'Finanzierung bearbeiten' : 'Neue Finanzierung'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div>
              <Label>Immobilie *</Label>
              <Select 
                value={formData.propertyId} 
                onValueChange={(value) => setFormData({ ...formData, propertyId: value, unitId: '' })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  {store.properties.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Einheit (optional)</Label>
              <Select 
                value={formData.unitId || 'none'} 
                onValueChange={(value) => setFormData({ ...formData, unitId: value === 'none' ? '' : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Alle Einheiten</SelectItem>
                  {unitsForProperty.map(u => (
                    <SelectItem key={u.id} value={u.id}>{u.unitNumber}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Bank *</Label>
              <Input 
                value={formData.bankName} 
                onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                placeholder="z.B. Sparkasse"
              />
            </div>
            <div>
              <Label>Darlehensnummer</Label>
              <Input 
                value={formData.loanNumber} 
                onChange={(e) => setFormData({ ...formData, loanNumber: e.target.value })}
                placeholder="z.B. KD-12345"
              />
            </div>
            <div>
              <Label>Darlehensbetrag (€)</Label>
              <Input 
                type="number"
                value={formData.principalAmount} 
                onChange={(e) => setFormData({ ...formData, principalAmount: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Restschuld (€)</Label>
              <Input 
                type="number"
                value={formData.remainingDebt} 
                onChange={(e) => setFormData({ ...formData, remainingDebt: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Zinssatz (%)</Label>
              <Input 
                type="number"
                step="0.01"
                value={formData.interestRate} 
                onChange={(e) => setFormData({ ...formData, interestRate: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Tilgungssatz (%)</Label>
              <Input 
                type="number"
                step="0.01"
                value={formData.repaymentRate} 
                onChange={(e) => setFormData({ ...formData, repaymentRate: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Monatliche Rate (€)</Label>
              <Input 
                type="number"
                value={formData.monthlyRate} 
                onChange={(e) => setFormData({ ...formData, monthlyRate: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Zinsbindung bis</Label>
              <Input 
                type="date"
                value={formData.fixedInterestUntil} 
                onChange={(e) => setFormData({ ...formData, fixedInterestUntil: e.target.value })}
              />
            </div>
            <div>
              <Label>Startdatum</Label>
              <Input 
                type="date"
                value={formData.startDate} 
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
              />
            </div>
            <div>
              <Label>Enddatum</Label>
              <Input 
                type="date"
                value={formData.endDate} 
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
              />
            </div>
            <div className="col-span-2">
              <Label>Notizen</Label>
              <Input 
                value={formData.notes} 
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Finanzierung löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie diese Finanzierung wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default FinancingSection;
