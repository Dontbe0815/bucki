'use client';

import { createContext, useContext, useEffect, useState, ReactNode, useSyncExternalStore } from 'react';

type Theme = 'light' | 'dark' | 'banking' | 'banking-dark' | 'fancy' | 'fancy-dark';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  isDark: boolean;
  designTheme: 'standard' | 'banking' | 'fancy';
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = 'bucki-theme';

// Get initial theme from localStorage (for SSR compatibility)
function getInitialTheme(): Theme {
  if (typeof window === 'undefined') return 'light';
  const saved = localStorage.getItem(THEME_STORAGE_KEY);
  if (saved && isValidTheme(saved)) return saved;
  return 'light';
}

// Check if theme is valid
function isValidTheme(theme: string): theme is Theme {
  return ['light', 'dark', 'banking', 'banking-dark', 'fancy', 'fancy-dark'].includes(theme);
}

// Subscribe to theme changes (for multi-tab sync)
function subscribe(callback: () => void) {
  const handleStorage = (e: StorageEvent) => {
    if (e.key === THEME_STORAGE_KEY) callback();
  };
  window.addEventListener('storage', handleStorage);
  return () => window.removeEventListener('storage', handleStorage);
}

// Get snapshot of current theme
function getSnapshot(): Theme {
  return getInitialTheme();
}

function getServerSnapshot(): Theme {
  return 'light';
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  // Use sync external store for SSR compatibility
  const storedTheme = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const [theme, setThemeState] = useState<Theme>(storedTheme);

  // Apply theme to document - this runs synchronously
  const applyTheme = (newTheme: Theme) => {
    const root = document.documentElement;
    
    // Remove all theme classes
    root.classList.remove('light', 'dark', 'banking', 'banking-dark', 'fancy', 'fancy-dark');
    
    // Add the new theme class
    root.classList.add(newTheme);
    
    // Update color-scheme for scrollbar styling
    const isDark = newTheme === 'dark' || newTheme === 'banking-dark' || newTheme === 'fancy-dark';
    root.style.colorScheme = isDark ? 'dark' : 'light';
    
    // Set data-theme attribute for additional CSS targeting
    root.setAttribute('data-theme', newTheme);
    
    // Save to localStorage
    try {
      localStorage.setItem(THEME_STORAGE_KEY, newTheme);
    } catch (e) {
      // localStorage not available
    }
  };

  // Apply theme on mount and when storedTheme changes
  useEffect(() => {
    setThemeState(storedTheme);
    applyTheme(storedTheme);
  }, [storedTheme]);

  // Apply theme immediately on first render
  useEffect(() => {
    // Run on next tick to ensure DOM is ready
    const timer = requestAnimationFrame(() => {
      applyTheme(theme);
    });
    return () => cancelAnimationFrame(timer);
  }, []);

  // Update theme
  const setTheme = (newTheme: Theme) => {
    if (!isValidTheme(newTheme)) return;
    
    setThemeState(newTheme);
    applyTheme(newTheme);
    
    // Dispatch custom event for other components to listen to
    window.dispatchEvent(new CustomEvent('themechange', { detail: newTheme }));
  };

  // Derived values
  const isDark = theme === 'dark' || theme === 'banking-dark' || theme === 'fancy-dark';
  const designTheme = theme.includes('banking') ? 'banking' : theme.includes('fancy') ? 'fancy' : 'standard';

  return (
    <ThemeContext.Provider value={{ theme, setTheme, isDark, designTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
