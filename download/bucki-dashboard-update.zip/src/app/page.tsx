'use client';

import { useState, useMemo, useRef } from 'react';
import { useStore } from '@/lib/store';
import type { 
  Property, Unit, Tenant, Transaction, Financing, Document, Task,
  TransactionCategory, TransactionType, TaskPriority, TaskStatus, DocumentType,
  DepreciationItem, DepreciationCategory
} from '@/lib/types';
import { 
  Home, Building2, DoorOpen, Users, DollarSign, CreditCard, FileText, 
  ClipboardList, BarChart3, Settings, Menu, X, Plus, Edit2, Trash2, 
  TrendingUp, TrendingDown, Building, Calendar, Phone, Mail, MapPin,
  ChevronRight, AlertTriangle, CheckCircle, Clock, Upload, Download,
  Save, RotateCcw, Eye, ArrowUpRight, ArrowDownRight, Euro, FileSpreadsheet,
  BedDouble, Ruler, Hash, Briefcase, AlertCircle, Check, Calculator, Receipt,
  Sofa, Lamp, Refrigerator, Package, Filter
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Legend
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle 
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, 
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

// Navigation Items
const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'properties', label: 'Immobilien', icon: Building2 },
  { id: 'units', label: 'Einheiten', icon: DoorOpen },
  { id: 'tenants', label: 'Mieter', icon: Users },
  { id: 'finances', label: 'Finanzen', icon: DollarSign },
  { id: 'financing', label: 'Finanzierung', icon: CreditCard },
  { id: 'depreciation', label: 'Abschreibungen', icon: TrendingDown },
  { id: 'housemoney', label: 'Hausgelder', icon: FileSpreadsheet },
  { id: 'documents', label: 'Dokumente', icon: FileText },
  { id: 'tasks', label: 'Aufgaben', icon: ClipboardList },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
  { id: 'settings', label: 'Einstellungen', icon: Settings },
];

// Color palette for charts
const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

// Format currency
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(amount);
};

// Format date
const formatDate = (dateString: string) => {
  if (!dateString) return '-';
  return format(new Date(dateString), 'dd.MM.yyyy', { locale: de });
};

// Category labels
const categoryLabels: Record<TransactionCategory, string> = {
  rent: 'Miete',
  utilities: 'Nebenkosten',
  repairs: 'Reparaturen',
  insurance: 'Versicherung',
  mortgage: 'Kreditrate',
  reserves: 'Rücklagen',
  management: 'Verwaltung',
  taxes: 'Steuern',
  other: 'Sonstiges',
};

const documentTypeLabels: Record<DocumentType, string> = {
  rental_contract: 'Mietvertrag',
  purchase_contract: 'Kaufvertrag',
  invoice: 'Rechnung',
  energy_certificate: 'Energieausweis',
  insurance: 'Versicherung',
  mortgage: 'Kreditvertrag',
  other: 'Sonstiges',
};

const taskPriorityLabels: Record<TaskPriority, string> = {
  low: 'Niedrig',
  medium: 'Mittel',
  high: 'Hoch',
  urgent: 'Dringend',
};

const taskStatusLabels: Record<TaskStatus, string> = {
  pending: 'Offen',
  in_progress: 'In Bearbeitung',
  completed: 'Erledigt',
  cancelled: 'Abgebrochen',
};

const priorityColors: Record<TaskPriority, string> = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-blue-100 text-blue-800',
  high: 'bg-orange-100 text-orange-800',
  urgent: 'bg-red-100 text-red-800',
};

const statusColors: Record<TaskStatus, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  in_progress: 'bg-blue-100 text-blue-800',
  completed: 'bg-green-100 text-green-800',
  cancelled: 'bg-gray-100 text-gray-800',
};

const unitStatusLabels: Record<string, string> = {
  rented: 'Vermietet',
  vacant: 'Leer',
  renovation: 'Renovierung',
  reserved: 'Reserviert',
};

const unitStatusColors: Record<string, string> = {
  rented: 'bg-green-100 text-green-800',
  vacant: 'bg-red-100 text-red-800',
  renovation: 'bg-yellow-100 text-yellow-800',
  reserved: 'bg-blue-100 text-blue-800',
};

// Abschreibungskategorie Labels und Icons
const depreciationCategoryLabels: Record<DepreciationCategory, string> = {
  gebaeude: 'Gebäude',
  moebel: 'Möbel',
  kueche: 'Küche',
  elektro: 'Elektrogeräte',
  inventar: 'Inventar',
  ausstattung: 'Ausstattung',
  sonstiges: 'Sonstiges',
};

const depreciationCategoryColors: Record<DepreciationCategory, string> = {
  gebaeude: 'bg-blue-100 text-blue-800',
  moebel: 'bg-amber-100 text-amber-800',
  kueche: 'bg-orange-100 text-orange-800',
  elektro: 'bg-cyan-100 text-cyan-800',
  inventar: 'bg-purple-100 text-purple-800',
  ausstattung: 'bg-pink-100 text-pink-800',
  sonstiges: 'bg-gray-100 text-gray-800',
};

export default function BuckiApp() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  const store = useStore();

  // Calculate dashboard stats
  const stats = useMemo(() => {
    const totalProperties = store.properties.length;
    const totalUnits = store.units.length;
    const rentedUnits = store.units.filter(u => u.status === 'rented').length;
    const vacantUnits = store.units.filter(u => u.status === 'vacant').length;
    
    // Gesamtmieteinnahmen (Warmmiete)
    const totalRentIncome = store.transactions
      .filter(t => t.type === 'income' && t.category === 'rent')
      .reduce((sum, t) => sum + t.amount, 0);
    
    // Kaltmieteneinnahmen (aus units.baseRent)
    const coldRentIncome = store.units
      .filter(u => u.status === 'rented')
      .reduce((sum, u) => sum + u.baseRent, 0);
    
    // Ausgaben gesamt (monatlich)
    const totalExpenses = store.transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    
    // Cashflow = Warmmiete - Ausgaben (neue Definition)
    const cashflow = totalRentIncome - totalExpenses;
    
    const totalMarketValue = store.properties.reduce((sum, p) => sum + p.marketValue, 0);
    const totalEstimatedValue = store.properties.reduce((sum, p) => sum + (p.estimatedValue || p.marketValue), 0);
    
    // Aktuelle Restschulden (Summe aller remainingDebt)
    const totalRemainingDebt = store.financings.reduce((sum, f) => sum + f.remainingDebt, 0);
    const equity = totalEstimatedValue - totalRemainingDebt;
    
    // Vermögenszuwachs pro Monat = Kaltmiete + Tilgung - nicht umlegbare Kosten
    // Tilgung aus Finanzierungen
    const monthlyRepayment = store.financings.reduce((sum, f) => {
      const totalMonthlyRate = f.monthlyRate;
      const interestAmount = f.principalAmount * (f.interestRate / 100) / 12;
      const repayment = Math.max(0, totalMonthlyRate - interestAmount);
      return sum + repayment;
    }, 0);
    
    // Zinsen aus Transaktionen
    const monthlyInterest = store.transactions
      .filter(t => t.type === 'expense' && t.category === 'mortgage')
      .reduce((sum, t) => sum + t.amount, 0);
    
    // Vermögenszuwachs = Kaltmiete - Zinsen - nicht umlegbare Kosten
    // (Vereinfacht: Kaltmiete - alle Ausgaben + Tilgungsanteil)
    const assetGrowth = coldRentIncome - monthlyInterest + monthlyRepayment;
    
    // Abschreibungen (monatlich) - NEU: alle Abschreibungspositionen
    const monthlyDepreciation = store.depreciationItems
      .reduce((sum, d) => sum + d.monthlyDepreciation, 0);
    const annualDepreciation = store.depreciationItems
      .reduce((sum, d) => sum + d.annualDepreciation, 0);

    return {
      totalProperties,
      totalUnits,
      rentedUnits,
      vacantUnits,
      totalRentIncome,
      coldRentIncome,
      totalExpenses,
      cashflow,
      totalMarketValue,
      totalEstimatedValue,
      totalRemainingDebt, // Neu: Aktuelle Restschulden
      equity,
      monthlyRepayment,
      assetGrowth,
      monthlyDepreciation, // Neu: Monatliche Abschreibungen
      annualDepreciation, // Neu: Jährliche Abschreibungen
    };
  }, [store.properties, store.units, store.transactions, store.financings, store.depreciationItems]);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} bg-white border-r border-gray-200 transition-all duration-300 flex flex-col`}>
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          {sidebarOpen && (
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="Bucki" className="h-8 w-8 rounded-lg object-cover" />
              <span className="text-xl font-bold text-gray-900">Bucki</span>
            </div>
          )}
          {!sidebarOpen && (
            <img src="/logo.png" alt="Bucki" className="h-8 w-8 rounded-lg object-cover mx-auto" />
          )}
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
        <nav className="flex-1 p-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 transition-colors ${
                activeTab === item.id
                  ? 'bg-emerald-50 text-emerald-700 font-medium'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <item.icon className="h-5 w-5 flex-shrink-0" />
              {sidebarOpen && <span>{item.label}</span>}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-gray-200">
          {sidebarOpen && (
            <div className="text-xs text-gray-500">
              <p>Version 1.0.0</p>
              <p>© 2024 Bucki</p>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          {activeTab === 'dashboard' && <DashboardSection stats={stats} />}
          {activeTab === 'properties' && <PropertiesSection />}
          {activeTab === 'units' && <UnitsSection />}
          {activeTab === 'tenants' && <TenantsSection />}
          {activeTab === 'finances' && <FinancesSection />}
          {activeTab === 'financing' && <FinancingSection />}
          {activeTab === 'depreciation' && <DepreciationSection />}
          {activeTab === 'housemoney' && <HouseMoneySection />}
          {activeTab === 'documents' && <DocumentsSection />}
          {activeTab === 'tasks' && <TasksSection />}
          {activeTab === 'reports' && <ReportsSection />}
          {activeTab === 'settings' && <SettingsSection />}
        </div>
      </main>
    </div>
  );
}

// ============================================
// DASHBOARD SECTION
// ============================================
function DashboardSection({ stats }: { stats: any }) {
  const store = useStore();
  const [portfolioFilter, setPortfolioFilter] = useState<'all' | 'city' | 'size50' | 'size80' | 'size80plus'>('all');
  const [selectedCity, setSelectedCity] = useState<string>('all');
  
  // Eindeutige Städte ermitteln
  const cities = useMemo(() => {
    const uniqueCities = [...new Set(store.properties.map(p => p.city))];
    return uniqueCities.sort();
  }, [store.properties]);
  
  // Monthly cashflow chart data
  const monthlyData = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
    const currentYear = new Date().getFullYear();
    
    return months.map((month, index) => {
      const monthTransactions = store.transactions.filter(t => {
        const date = new Date(t.date);
        return date.getFullYear() === currentYear && date.getMonth() === index;
      });
      
      const income = monthTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
      const expenses = monthTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
      
      return { month, income, expenses, cashflow: income - expenses };
    });
  }, [store.transactions]);

  // Property distribution mit Filter
  const propertyDistribution = useMemo(() => {
    let filteredProperties = store.properties;
    
    // Stadt-Filter
    if (portfolioFilter === 'city' && selectedCity !== 'all') {
      filteredProperties = filteredProperties.filter(p => p.city === selectedCity);
    }
    
    // Wohnungsgrößen-Filter
    if (portfolioFilter === 'size50') {
      const unitIds = store.units.filter(u => u.area <= 50).map(u => u.propertyId);
      filteredProperties = filteredProperties.filter(p => unitIds.includes(p.id));
    } else if (portfolioFilter === 'size80') {
      const unitIds = store.units.filter(u => u.area > 50 && u.area <= 80).map(u => u.propertyId);
      filteredProperties = filteredProperties.filter(p => unitIds.includes(p.id));
    } else if (portfolioFilter === 'size80plus') {
      const unitIds = store.units.filter(u => u.area > 80).map(u => u.propertyId);
      filteredProperties = filteredProperties.filter(p => unitIds.includes(p.id));
    }
    
    return filteredProperties.map(p => ({
      name: p.name,
      value: p.marketValue,
      units: store.units.filter(u => u.propertyId === p.id).length,
      city: p.city,
    }));
  }, [store.properties, store.units, portfolioFilter, selectedCity]);

  // Abschreibungen nach Kategorien gruppieren
  const depreciationByCategory = useMemo(() => {
    const grouped: Record<string, number> = {};
    store.depreciationItems.forEach(item => {
      if (!grouped[item.category]) {
        grouped[item.category] = 0;
      }
      grouped[item.category] += item.monthlyDepreciation;
    });
    return Object.entries(grouped).map(([category, amount]) => ({
      category: depreciationCategoryLabels[category as DepreciationCategory],
      amount,
      color: depreciationCategoryColors[category as DepreciationCategory],
    }));
  }, [store.depreciationItems]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500">Willkommen bei Bucki</p>
      </div>

      {/* Stats Grid - Erste Reihe */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Immobilien</CardTitle>
            <Building2 className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalProperties}</div>
            <p className="text-xs text-gray-500 mt-1">{stats.totalUnits} Einheiten</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Kaltmieteneinnahmen</CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">{formatCurrency(stats.coldRentIncome)}</div>
            <p className="text-xs text-gray-500 mt-1">monatlich · {stats.rentedUnits}/{stats.totalUnits} vermietet</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Vermögenszuwachs</CardTitle>
            <ArrowUpRight className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${stats.assetGrowth >= 0 ? 'text-purple-600' : 'text-red-600'}`}>
              {formatCurrency(stats.assetGrowth)}
            </div>
            <p className="text-xs text-gray-500 mt-1">pro Monat</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Cashflow</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${stats.cashflow >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
              {formatCurrency(stats.cashflow)}
            </div>
            <p className="text-xs text-gray-500 mt-1">Warmmiete - Ausgaben</p>
          </CardContent>
        </Card>
      </div>

      {/* Second Row Stats - NEUE Kennzahlen */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Aktuelle Restschulden</CardTitle>
            <CreditCard className="h-4 w-4 text-red-500 absolute right-4 top-3" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(stats.totalRemainingDebt)}</div>
            <p className="text-xs text-gray-500 mt-1">ausstehende Kreditsumme</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Ausgaben gesamt</CardTitle>
            <TrendingDown className="h-4 w-4 text-orange-500 absolute right-4 top-3" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{formatCurrency(stats.totalExpenses)}</div>
            <p className="text-xs text-gray-500 mt-1">monatlich</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Abschreibungen</CardTitle>
            <TrendingDown className="h-4 w-4 text-indigo-500 absolute right-4 top-3" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{formatCurrency(stats.monthlyDepreciation)}</div>
            <p className="text-xs text-gray-500 mt-1">monatlich · {formatCurrency(stats.annualDepreciation)}/Jahr</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-600">Aktueller Schätzwert</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700">{formatCurrency(stats.totalEstimatedValue)}</div>
            <div className="mt-2">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-500">Eigenkapital</span>
                <span className="font-medium">{formatCurrency(stats.equity)}</span>
              </div>
              <Progress value={stats.totalEstimatedValue > 0 ? (stats.equity / stats.totalEstimatedValue) * 100 : 0} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Third Row Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Warmmiete (gesamt)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalRentIncome)}</div>
            <p className="text-xs text-gray-500 mt-1">Kaltmiete + Nebenkosten</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Vermietungsquote</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.totalUnits > 0 ? Math.round((stats.rentedUnits / stats.totalUnits) * 100) : 0}%
            </div>
            <div className="mt-2">
              <Progress 
                value={stats.totalUnits > 0 ? (stats.rentedUnits / stats.totalUnits) * 100 : 0} 
                className="h-2" 
              />
            </div>
            <div className="flex justify-between text-sm mt-2 text-gray-500">
              <span>{stats.rentedUnits} vermietet</span>
              <span>{stats.vacantUnits} leer</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Marktwertsteigerung</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-emerald-600">
              <TrendingUp className="h-5 w-5" />
              <span className="text-xl font-bold">
                +{formatCurrency(stats.totalEstimatedValue - stats.totalMarketValue)}
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              +{Math.round(((stats.totalEstimatedValue - stats.totalMarketValue) / stats.totalMarketValue) * 100)}% gegenüber Buchwert
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Cashflow Übersicht</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                <Legend />
                <Bar dataKey="income" name="Einnahmen" fill="#10b981" />
                <Bar dataKey="expenses" name="Ausgaben" fill="#ef4444" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Portfolio-Verteilung</CardTitle>
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-gray-400" />
                <Select 
                  value={portfolioFilter} 
                  onValueChange={(value: any) => setPortfolioFilter(value)}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle</SelectItem>
                    <SelectItem value="city">Nach Stadt</SelectItem>
                    <SelectItem value="size50">bis 50 m²</SelectItem>
                    <SelectItem value="size80">51–80 m²</SelectItem>
                    <SelectItem value="size80plus">über 80 m²</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {portfolioFilter === 'city' && (
              <Select 
                value={selectedCity} 
                onValueChange={setSelectedCity}
              >
                <SelectTrigger className="w-full mt-2">
                  <SelectValue placeholder="Stadt auswählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle Städte</SelectItem>
                  {cities.map(city => (
                    <SelectItem key={city} value={city}>{city}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={propertyDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {propertyDistribution.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Abschreibungen nach Kategorien */}
      <Card>
        <CardHeader>
          <CardTitle>Abschreibungen nach Kategorien</CardTitle>
          <CardDescription>Monatliche Abschreibungen aufgeschlüsselt nach Wirtschaftsgütern</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
            {depreciationByCategory.map((item) => (
              <div key={item.category} className="text-center p-3 rounded-lg bg-gray-50">
                <Badge className={item.color + ' mb-2'}>
                  {item.category}
                </Badge>
                <div className="text-lg font-bold">{formatCurrency(item.amount)}</div>
                <p className="text-xs text-gray-500">/ Monat</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================
// PROPERTIES SECTION
// ============================================
function PropertiesSection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    postalCode: '',
    purchasePrice: 0,
    purchaseDate: '',
    totalArea: 0,
    unitsCount: 0,
    marketValue: 0,
    propertyType: 'apartment' as Property['propertyType'],
    yearBuilt: new Date().getFullYear(),
    notes: '',
  });

  const openNewDialog = () => {
    setEditingProperty(null);
    setFormData({
      name: '',
      address: '',
      city: '',
      postalCode: '',
      purchasePrice: 0,
      purchaseDate: '',
      totalArea: 0,
      unitsCount: 0,
      marketValue: 0,
      propertyType: 'apartment',
      yearBuilt: new Date().getFullYear(),
      notes: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (property: Property) => {
    setEditingProperty(property);
    setFormData({
      name: property.name,
      address: property.address,
      city: property.city,
      postalCode: property.postalCode,
      purchasePrice: property.purchasePrice,
      purchaseDate: property.purchaseDate,
      totalArea: property.totalArea,
      unitsCount: property.unitsCount,
      marketValue: property.marketValue,
      propertyType: property.propertyType,
      yearBuilt: property.yearBuilt,
      notes: property.notes,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.address || !formData.city) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    if (editingProperty) {
      store.updateProperty(editingProperty.id, formData);
      toast.success('Immobilie aktualisiert');
    } else {
      store.addProperty(formData);
      toast.success('Immobilie hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      store.deleteProperty(deletingId);
      toast.success('Immobilie gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Immobilien</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neue Immobilie
        </Button>
      </div>

      {/* Properties Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {store.properties.map((property) => {
          const units = store.units.filter(u => u.propertyId === property.id);
          const rentedUnits = units.filter(u => u.status === 'rented').length;
          
          return (
            <Card key={property.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{property.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1 mt-1">
                      <MapPin className="h-3 w-3" />
                      {property.address}, {property.postalCode} {property.city}
                    </CardDescription>
                  </div>
                  <Badge variant="outline">
                    {property.propertyType === 'apartment' && 'Wohnung'}
                    {property.propertyType === 'house' && 'Haus'}
                    {property.propertyType === 'commercial' && 'Gewerbe'}
                    {property.propertyType === 'mixed' && 'Gemischt'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Einheiten</span>
                    <span className="font-medium">{rentedUnits}/{units.length} vermietet</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Wohnfläche</span>
                    <span className="font-medium">{property.totalArea} m²</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Kaufpreis</span>
                    <span className="font-medium">{formatCurrency(property.purchasePrice)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Marktwert</span>
                    <span className="font-medium text-emerald-600">{formatCurrency(property.marketValue)}</span>
                  </div>
                  <div className="flex justify-between text-sm bg-purple-50 -mx-4 px-4 py-2 rounded-lg">
                    <span className="text-purple-700 font-medium">Aktueller Schätzwert</span>
                    <span className="font-bold text-purple-700">{formatCurrency(property.estimatedValue || property.marketValue)}</span>
                  </div>
                  <div className="flex justify-between text-xs text-gray-400">
                    <span></span>
                    <span>~{(property.pricePerSqm || 0).toLocaleString('de-DE')} €/m²</span>
                  </div>
                  <Separator />
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => openEditDialog(property)}
                    >
                      <Edit2 className="h-4 w-4 mr-1" /> Bearbeiten
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-red-600 hover:text-red-700"
                      onClick={() => {
                        setDeletingId(property.id);
                        setDeleteDialogOpen(true);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {store.properties.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Keine Immobilien</h3>
            <p className="text-gray-500 mb-4">Fügen Sie Ihre erste Immobilie hinzu</p>
            <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="h-4 w-4 mr-2" /> Neue Immobilie
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Property Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingProperty ? 'Immobilie bearbeiten' : 'Neue Immobilie'}</DialogTitle>
            <DialogDescription>
              {editingProperty ? 'Aktualisieren Sie die Daten der Immobilie' : 'Erfassen Sie eine neue Immobilie'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="col-span-2">
              <Label htmlFor="name">Name *</Label>
              <Input 
                id="name" 
                value={formData.name} 
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="z.B. Mehrfamilienhaus Berlin"
              />
            </div>
            <div className="col-span-2">
              <Label htmlFor="address">Adresse *</Label>
              <Input 
                id="address" 
                value={formData.address} 
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="Straße und Hausnummer"
              />
            </div>
            <div>
              <Label htmlFor="postalCode">PLZ</Label>
              <Input 
                id="postalCode" 
                value={formData.postalCode} 
                onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="city">Stadt *</Label>
              <Input 
                id="city" 
                value={formData.city} 
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="propertyType">Typ</Label>
              <Select 
                value={formData.propertyType} 
                onValueChange={(value: Property['propertyType']) => setFormData({ ...formData, propertyType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="apartment">Wohnung</SelectItem>
                  <SelectItem value="house">Haus</SelectItem>
                  <SelectItem value="commercial">Gewerbe</SelectItem>
                  <SelectItem value="mixed">Gemischt</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="yearBuilt">Baujahr</Label>
              <Input 
                id="yearBuilt" 
                type="number" 
                value={formData.yearBuilt} 
                onChange={(e) => setFormData({ ...formData, yearBuilt: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label htmlFor="purchasePrice">Kaufpreis (€)</Label>
              <Input 
                id="purchasePrice" 
                type="number" 
                value={formData.purchasePrice} 
                onChange={(e) => setFormData({ ...formData, purchasePrice: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label htmlFor="purchaseDate">Kaufdatum</Label>
              <Input 
                id="purchaseDate" 
                type="date" 
                value={formData.purchaseDate} 
                onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="totalArea">Wohnfläche (m²)</Label>
              <Input 
                id="totalArea" 
                type="number" 
                value={formData.totalArea} 
                onChange={(e) => setFormData({ ...formData, totalArea: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label htmlFor="unitsCount">Anzahl Einheiten</Label>
              <Input 
                id="unitsCount" 
                type="number" 
                value={formData.unitsCount} 
                onChange={(e) => setFormData({ ...formData, unitsCount: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label htmlFor="marketValue">Marktwert (€)</Label>
              <Input 
                id="marketValue" 
                type="number" 
                value={formData.marketValue} 
                onChange={(e) => setFormData({ ...formData, marketValue: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div className="col-span-2">
              <Label htmlFor="notes">Notizen</Label>
              <Textarea 
                id="notes" 
                value={formData.notes} 
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Immobilie löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie diese Immobilie wirklich löschen? Alle zugehörigen Einheiten, Mieter und Transaktionen werden ebenfalls gelöscht.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================
// UNITS SECTION
// ============================================
function UnitsSection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingUnit, setEditingUnit] = useState<Unit | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [filterProperty, setFilterProperty] = useState<string>('all');
  const [formData, setFormData] = useState({
    propertyId: '',
    unitNumber: '',
    floor: 0,
    area: 0,
    rooms: 0,
    baseRent: 0,
    additionalCosts: 0,
    status: 'vacant' as Unit['status'],
    description: '',
  });

  const filteredUnits = filterProperty === 'all' 
    ? store.units 
    : store.units.filter(u => u.propertyId === filterProperty);

  const openNewDialog = () => {
    setEditingUnit(null);
    setFormData({
      propertyId: store.properties[0]?.id || '',
      unitNumber: '',
      floor: 0,
      area: 0,
      rooms: 0,
      baseRent: 0,
      additionalCosts: 0,
      status: 'vacant',
      description: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (unit: Unit) => {
    setEditingUnit(unit);
    setFormData({
      propertyId: unit.propertyId,
      unitNumber: unit.unitNumber,
      floor: unit.floor,
      area: unit.area,
      rooms: unit.rooms,
      baseRent: unit.baseRent,
      additionalCosts: unit.additionalCosts,
      status: unit.status,
      description: unit.description,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.propertyId || !formData.unitNumber) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    const totalRent = formData.baseRent + formData.additionalCosts;

    if (editingUnit) {
      store.updateUnit(editingUnit.id, { ...formData, totalRent });
      toast.success('Einheit aktualisiert');
    } else {
      store.addUnit({ ...formData, totalRent });
      toast.success('Einheit hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      store.deleteUnit(deletingId);
      toast.success('Einheit gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const getPropertyName = (propertyId: string) => {
    const property = store.properties.find(p => p.id === propertyId);
    return property?.name || 'Unbekannt';
  };

  const getTenant = (unitId: string) => {
    return store.tenants.find(t => t.unitId === unitId);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Einheiten</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neue Einheit
        </Button>
      </div>

      {/* Filter */}
      <div className="flex gap-4">
        <Select value={filterProperty} onValueChange={setFilterProperty}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Immobilie filtern" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle Immobilien</SelectItem>
            {store.properties.map(p => (
              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Units Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left p-4 font-medium text-gray-600">Einheit</th>
                  <th className="text-left p-4 font-medium text-gray-600">Immobilie</th>
                  <th className="text-left p-4 font-medium text-gray-600">Fläche</th>
                  <th className="text-left p-4 font-medium text-gray-600">Zimmer</th>
                  <th className="text-left p-4 font-medium text-gray-600">Miete</th>
                  <th className="text-left p-4 font-medium text-gray-600">Status</th>
                  <th className="text-left p-4 font-medium text-gray-600">Mieter</th>
                  <th className="text-right p-4 font-medium text-gray-600">Aktionen</th>
                </tr>
              </thead>
              <tbody>
                {filteredUnits.map((unit) => {
                  const tenant = getTenant(unit.id);
                  return (
                    <tr key={unit.id} className="border-b hover:bg-gray-50">
                      <td className="p-4 font-medium">{unit.unitNumber}</td>
                      <td className="p-4">{getPropertyName(unit.propertyId)}</td>
                      <td className="p-4">{unit.area} m²</td>
                      <td className="p-4">{unit.rooms}</td>
                      <td className="p-4">{formatCurrency(unit.totalRent)}</td>
                      <td className="p-4">
                        <Badge className={unitStatusColors[unit.status]}>
                          {unitStatusLabels[unit.status]}
                        </Badge>
                      </td>
                      <td className="p-4">{tenant ? `${tenant.firstName} ${tenant.lastName}` : '-'}</td>
                      <td className="p-4">
                        <div className="flex gap-2 justify-end">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => openEditDialog(unit)}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="text-red-600"
                            onClick={() => {
                              setDeletingId(unit.id);
                              setDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filteredUnits.length === 0 && (
            <div className="py-12 text-center text-gray-500">
              Keine Einheiten gefunden
            </div>
          )}
        </CardContent>
      </Card>

      {/* Unit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingUnit ? 'Einheit bearbeiten' : 'Neue Einheit'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div>
              <Label>Immobilie *</Label>
              <Select 
                value={formData.propertyId} 
                onValueChange={(value) => setFormData({ ...formData, propertyId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  {store.properties.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Wohnungsnummer *</Label>
              <Input 
                value={formData.unitNumber} 
                onChange={(e) => setFormData({ ...formData, unitNumber: e.target.value })}
                placeholder="z.B. EG links"
              />
            </div>
            <div>
              <Label>Etage</Label>
              <Input 
                type="number" 
                value={formData.floor} 
                onChange={(e) => setFormData({ ...formData, floor: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Fläche (m²)</Label>
              <Input 
                type="number" 
                value={formData.area} 
                onChange={(e) => setFormData({ ...formData, area: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Zimmer</Label>
              <Input 
                type="number" 
                step="0.5"
                value={formData.rooms} 
                onChange={(e) => setFormData({ ...formData, rooms: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Kaltmiete (€)</Label>
              <Input 
                type="number" 
                value={formData.baseRent} 
                onChange={(e) => setFormData({ ...formData, baseRent: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Nebenkosten (€)</Label>
              <Input 
                type="number" 
                value={formData.additionalCosts} 
                onChange={(e) => setFormData({ ...formData, additionalCosts: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Status</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value: Unit['status']) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rented">Vermietet</SelectItem>
                  <SelectItem value="vacant">Leer</SelectItem>
                  <SelectItem value="renovation">Renovierung</SelectItem>
                  <SelectItem value="reserved">Reserviert</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label>Beschreibung</Label>
              <Textarea 
                value={formData.description} 
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Einheit löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie diese Einheit wirklich löschen? Alle zugehörigen Mieter werden ebenfalls gelöscht.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================
// TENANTS SECTION
// ============================================
function TenantsSection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    unitId: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    street: '',
    city: '',
    postalCode: '',
    moveInDate: '',
    moveOutDate: '',
    deposit: 0,
    contractType: 'indefinite' as Tenant['contractType'],
    contractStartDate: '',
    contractEndDate: '',
    notes: '',
  });

  const openNewDialog = () => {
    setEditingTenant(null);
    setFormData({
      unitId: store.units.filter(u => u.status === 'vacant')[0]?.id || '',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      street: '',
      city: '',
      postalCode: '',
      moveInDate: '',
      moveOutDate: '',
      deposit: 0,
      contractType: 'indefinite',
      contractStartDate: '',
      contractEndDate: '',
      notes: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (tenant: Tenant) => {
    setEditingTenant(tenant);
    setFormData({
      unitId: tenant.unitId,
      firstName: tenant.firstName,
      lastName: tenant.lastName,
      email: tenant.email,
      phone: tenant.phone,
      street: tenant.street,
      city: tenant.city,
      postalCode: tenant.postalCode,
      moveInDate: tenant.moveInDate,
      moveOutDate: tenant.moveOutDate || '',
      deposit: tenant.deposit,
      contractType: tenant.contractType,
      contractStartDate: tenant.contractStartDate,
      contractEndDate: tenant.contractEndDate || '',
      notes: tenant.notes,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.firstName || !formData.lastName || !formData.unitId) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    if (editingTenant) {
      store.updateTenant(editingTenant.id, formData);
      toast.success('Mieter aktualisiert');
    } else {
      store.addTenant(formData);
      // Update unit status to rented
      store.updateUnit(formData.unitId, { status: 'rented' });
      toast.success('Mieter hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      const tenant = store.tenants.find(t => t.id === deletingId);
      if (tenant) {
        store.updateUnit(tenant.unitId, { status: 'vacant' });
      }
      store.deleteTenant(deletingId);
      toast.success('Mieter gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const getUnitInfo = (unitId: string) => {
    const unit = store.units.find(u => u.id === unitId);
    const property = unit ? store.properties.find(p => p.id === unit.propertyId) : null;
    return { unit, property };
  };

  const vacantUnits = store.units.filter(u => u.status === 'vacant');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Mieter</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neuer Mieter
        </Button>
      </div>

      {/* Tenants Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {store.tenants.map((tenant) => {
          const { unit, property } = getUnitInfo(tenant.unitId);
          return (
            <Card key={tenant.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{tenant.firstName} {tenant.lastName}</CardTitle>
                    <CardDescription className="mt-1">
                      {property?.name} - {unit?.unitNumber}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Mail className="h-4 w-4" />
                    <span>{tenant.email || '-'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="h-4 w-4" />
                    <span>{tenant.phone || '-'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="h-4 w-4" />
                    <span>Einzug: {formatDate(tenant.moveInDate)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Euro className="h-4 w-4" />
                    <span>Kaution: {formatCurrency(tenant.deposit)}</span>
                  </div>
                  <Separator className="my-3" />
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => openEditDialog(tenant)}
                    >
                      <Edit2 className="h-4 w-4 mr-1" /> Bearbeiten
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-red-600"
                      onClick={() => {
                        setDeletingId(tenant.id);
                        setDeleteDialogOpen(true);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {store.tenants.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Keine Mieter</h3>
            <p className="text-gray-500 mb-4">Fügen Sie Ihren ersten Mieter hinzu</p>
            <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="h-4 w-4 mr-2" /> Neuer Mieter
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Tenant Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingTenant ? 'Mieter bearbeiten' : 'Neuer Mieter'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div>
              <Label>Einheit *</Label>
              <Select 
                value={formData.unitId} 
                onValueChange={(value) => setFormData({ ...formData, unitId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  {(editingTenant ? store.units : vacantUnits).map(u => {
                    const property = store.properties.find(p => p.id === u.propertyId);
                    return (
                      <SelectItem key={u.id} value={u.id}>
                        {property?.name} - {u.unitNumber}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
            <div></div>
            <div>
              <Label>Vorname *</Label>
              <Input 
                value={formData.firstName} 
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
              />
            </div>
            <div>
              <Label>Nachname *</Label>
              <Input 
                value={formData.lastName} 
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
              />
            </div>
            <div>
              <Label>E-Mail</Label>
              <Input 
                type="email"
                value={formData.email} 
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div>
              <Label>Telefon</Label>
              <Input 
                value={formData.phone} 
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>
            <div className="col-span-2">
              <Label>Straße</Label>
              <Input 
                value={formData.street} 
                onChange={(e) => setFormData({ ...formData, street: e.target.value })}
              />
            </div>
            <div>
              <Label>PLZ</Label>
              <Input 
                value={formData.postalCode} 
                onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
              />
            </div>
            <div>
              <Label>Stadt</Label>
              <Input 
                value={formData.city} 
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              />
            </div>
            <div>
              <Label>Einzugsdatum</Label>
              <Input 
                type="date"
                value={formData.moveInDate} 
                onChange={(e) => setFormData({ ...formData, moveInDate: e.target.value })}
              />
            </div>
            <div>
              <Label>Auszugsdatum</Label>
              <Input 
                type="date"
                value={formData.moveOutDate} 
                onChange={(e) => setFormData({ ...formData, moveOutDate: e.target.value })}
              />
            </div>
            <div>
              <Label>Kaution (€)</Label>
              <Input 
                type="number"
                value={formData.deposit} 
                onChange={(e) => setFormData({ ...formData, deposit: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Vertragstyp</Label>
              <Select 
                value={formData.contractType} 
                onValueChange={(value: Tenant['contractType']) => setFormData({ ...formData, contractType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="indefinite">Unbefristet</SelectItem>
                  <SelectItem value="fixed">Befristet</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Vertragsbeginn</Label>
              <Input 
                type="date"
                value={formData.contractStartDate} 
                onChange={(e) => setFormData({ ...formData, contractStartDate: e.target.value })}
              />
            </div>
            <div>
              <Label>Vertragsende</Label>
              <Input 
                type="date"
                value={formData.contractEndDate} 
                onChange={(e) => setFormData({ ...formData, contractEndDate: e.target.value })}
              />
            </div>
            <div className="col-span-2">
              <Label>Notizen</Label>
              <Textarea 
                value={formData.notes} 
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Mieter löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie diesen Mieter wirklich löschen?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================
// FINANCES SECTION
// ============================================
function FinancesSection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterProperty, setFilterProperty] = useState<string>('all');
  const [formData, setFormData] = useState({
    propertyId: '',
    unitId: '',
    type: 'income' as TransactionType,
    category: 'rent' as TransactionCategory,
    amount: 0,
    date: '',
    description: '',
    isRecurring: false,
    recurringInterval: 'monthly' as 'monthly' | 'quarterly' | 'yearly',
  });

  const filteredTransactions = store.transactions.filter(t => {
    if (filterType !== 'all' && t.type !== filterType) return false;
    if (filterProperty !== 'all' && t.propertyId !== filterProperty) return false;
    return true;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const totalIncome = filteredTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = filteredTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const openNewDialog = () => {
    setEditingTransaction(null);
    setFormData({
      propertyId: store.properties[0]?.id || '',
      unitId: '',
      type: 'income',
      category: 'rent',
      amount: 0,
      date: new Date().toISOString().split('T')[0],
      description: '',
      isRecurring: false,
      recurringInterval: 'monthly',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setFormData({
      propertyId: transaction.propertyId || '',
      unitId: transaction.unitId || '',
      type: transaction.type,
      category: transaction.category,
      amount: transaction.amount,
      date: transaction.date,
      description: transaction.description,
      isRecurring: transaction.isRecurring,
      recurringInterval: transaction.recurringInterval || 'monthly',
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.amount || !formData.date) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    if (editingTransaction) {
      store.updateTransaction(editingTransaction.id, formData);
      toast.success('Transaktion aktualisiert');
    } else {
      store.addTransaction(formData);
      toast.success('Transaktion hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      store.deleteTransaction(deletingId);
      toast.success('Transaktion gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const getPropertyName = (propertyId?: string) => {
    if (!propertyId) return '-';
    const property = store.properties.find(p => p.id === propertyId);
    return property?.name || 'Unbekannt';
  };

  const unitsForProperty = formData.propertyId 
    ? store.units.filter(u => u.propertyId === formData.propertyId)
    : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Einnahmen & Ausgaben</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neue Transaktion
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Einnahmen</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">{formatCurrency(totalIncome)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Ausgaben</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(totalExpenses)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Saldo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${totalIncome - totalExpenses >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {formatCurrency(totalIncome - totalExpenses)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <Select value={filterType} onValueChange={(value: 'all' | 'income' | 'expense') => setFilterType(value)}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle</SelectItem>
            <SelectItem value="income">Einnahmen</SelectItem>
            <SelectItem value="expense">Ausgaben</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterProperty} onValueChange={setFilterProperty}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Immobilie filtern" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle Immobilien</SelectItem>
            {store.properties.map(p => (
              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Transactions Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left p-4 font-medium text-gray-600">Datum</th>
                  <th className="text-left p-4 font-medium text-gray-600">Typ</th>
                  <th className="text-left p-4 font-medium text-gray-600">Kategorie</th>
                  <th className="text-left p-4 font-medium text-gray-600">Beschreibung</th>
                  <th className="text-left p-4 font-medium text-gray-600">Immobilie</th>
                  <th className="text-right p-4 font-medium text-gray-600">Betrag</th>
                  <th className="text-right p-4 font-medium text-gray-600">Aktionen</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((transaction) => (
                  <tr key={transaction.id} className="border-b hover:bg-gray-50">
                    <td className="p-4">{formatDate(transaction.date)}</td>
                    <td className="p-4">
                      <Badge variant={transaction.type === 'income' ? 'default' : 'destructive'}>
                        {transaction.type === 'income' ? 'Einnahme' : 'Ausgabe'}
                      </Badge>
                    </td>
                    <td className="p-4">{categoryLabels[transaction.category]}</td>
                    <td className="p-4">
                      {transaction.description}
                      {transaction.isRecurring && (
                        <Badge variant="outline" className="ml-2">Wiederkehrend</Badge>
                      )}
                    </td>
                    <td className="p-4">{getPropertyName(transaction.propertyId)}</td>
                    <td className={`p-4 text-right font-medium ${transaction.type === 'income' ? 'text-emerald-600' : 'text-red-600'}`}>
                      {transaction.type === 'income' ? '+' : '-'}{formatCurrency(transaction.amount)}
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2 justify-end">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => openEditDialog(transaction)}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-red-600"
                          onClick={() => {
                            setDeletingId(transaction.id);
                            setDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredTransactions.length === 0 && (
            <div className="py-12 text-center text-gray-500">
              Keine Transaktionen gefunden
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingTransaction ? 'Transaktion bearbeiten' : 'Neue Transaktion'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div>
              <Label>Typ</Label>
              <Select 
                value={formData.type} 
                onValueChange={(value: TransactionType) => setFormData({ ...formData, type: value, category: value === 'income' ? 'rent' : 'repairs' })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="income">Einnahme</SelectItem>
                  <SelectItem value="expense">Ausgabe</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Kategorie</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value: TransactionCategory) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(categoryLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Betrag (€)</Label>
              <Input 
                type="number"
                value={formData.amount} 
                onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Datum</Label>
              <Input 
                type="date"
                value={formData.date} 
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>
            <div>
              <Label>Immobilie</Label>
              <Select 
                value={formData.propertyId} 
                onValueChange={(value) => setFormData({ ...formData, propertyId: value, unitId: '' })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  {store.properties.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Einheit</Label>
              <Select 
                value={formData.unitId} 
                onValueChange={(value) => setFormData({ ...formData, unitId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Keine</SelectItem>
                  {unitsForProperty.map(u => (
                    <SelectItem key={u.id} value={u.id}>{u.unitNumber}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label>Beschreibung</Label>
              <Input 
                value={formData.description} 
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div className="col-span-2 flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch 
                  checked={formData.isRecurring} 
                  onCheckedChange={(checked) => setFormData({ ...formData, isRecurring: checked })}
                />
                <Label>Wiederkehrend</Label>
              </div>
              {formData.isRecurring && (
                <Select 
                  value={formData.recurringInterval} 
                  onValueChange={(value: 'monthly' | 'quarterly' | 'yearly') => setFormData({ ...formData, recurringInterval: value })}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Monatlich</SelectItem>
                    <SelectItem value="quarterly">Quartalsweise</SelectItem>
                    <SelectItem value="yearly">Jährlich</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Transaktion löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie diese Transaktion wirklich löschen?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================
// FINANCING SECTION
// ============================================
function FinancingSection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingFinancing, setEditingFinancing] = useState<Financing | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    propertyId: '',
    bankName: '',
    loanNumber: '',
    principalAmount: 0,
    interestRate: 0,
    repaymentRate: 0,
    monthlyRate: 0,
    remainingDebt: 0,
    startDate: '',
    endDate: '',
    fixedInterestUntil: '',
    notes: '',
  });

  const openNewDialog = () => {
    setEditingFinancing(null);
    setFormData({
      propertyId: store.properties[0]?.id || '',
      bankName: '',
      loanNumber: '',
      principalAmount: 0,
      interestRate: 0,
      repaymentRate: 0,
      monthlyRate: 0,
      remainingDebt: 0,
      startDate: '',
      endDate: '',
      fixedInterestUntil: '',
      notes: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (financing: Financing) => {
    setEditingFinancing(financing);
    setFormData({
      propertyId: financing.propertyId,
      bankName: financing.bankName,
      loanNumber: financing.loanNumber,
      principalAmount: financing.principalAmount,
      interestRate: financing.interestRate,
      repaymentRate: financing.repaymentRate,
      monthlyRate: financing.monthlyRate,
      remainingDebt: financing.remainingDebt,
      startDate: financing.startDate,
      endDate: financing.endDate,
      fixedInterestUntil: financing.fixedInterestUntil || '',
      notes: financing.notes,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.propertyId || !formData.bankName) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    if (editingFinancing) {
      store.updateFinancing(editingFinancing.id, formData);
      toast.success('Finanzierung aktualisiert');
    } else {
      store.addFinancing(formData);
      toast.success('Finanzierung hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      store.deleteFinancing(deletingId);
      toast.success('Finanzierung gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const getPropertyName = (propertyId: string) => {
    const property = store.properties.find(p => p.id === propertyId);
    return property?.name || 'Unbekannt';
  };

  const totalRemainingDebt = store.financings.reduce((sum, f) => sum + f.remainingDebt, 0);
  const totalMonthlyRate = store.financings.reduce((sum, f) => sum + f.monthlyRate, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Finanzierung</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neue Finanzierung
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Restschuld gesamt</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalRemainingDebt)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Monatliche Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalMonthlyRate)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Anzahl Darlehen</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{store.financings.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Financings List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {store.financings.map((financing) => {
          const paydownProgress = ((financing.principalAmount - financing.remainingDebt) / financing.principalAmount) * 100;
          
          return (
            <Card key={financing.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{financing.bankName}</CardTitle>
                    <CardDescription>{getPropertyName(financing.propertyId)}</CardDescription>
                  </div>
                  <Badge variant="outline">{financing.loanNumber}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-500">Tilgungsfortschritt</span>
                      <span className="font-medium">{paydownProgress.toFixed(1)}%</span>
                    </div>
                    <Progress value={paydownProgress} className="h-2" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Darlehensbetrag</span>
                      <p className="font-medium">{formatCurrency(financing.principalAmount)}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Restschuld</span>
                      <p className="font-medium">{formatCurrency(financing.remainingDebt)}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Zins</span>
                      <p className="font-medium">{financing.interestRate}%</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Tilgung</span>
                      <p className="font-medium">{financing.repaymentRate}%</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Monatsrate</span>
                      <p className="font-medium text-emerald-600">{formatCurrency(financing.monthlyRate)}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Zinsbindung bis</span>
                      <p className="font-medium">{formatDate(financing.fixedInterestUntil || '')}</p>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => openEditDialog(financing)}
                    >
                      <Edit2 className="h-4 w-4 mr-1" /> Bearbeiten
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-red-600"
                      onClick={() => {
                        setDeletingId(financing.id);
                        setDeleteDialogOpen(true);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {store.financings.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Keine Finanzierungen</h3>
            <p className="text-gray-500 mb-4">Fügen Sie Ihre erste Finanzierung hinzu</p>
            <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="h-4 w-4 mr-2" /> Neue Finanzierung
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Financing Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingFinancing ? 'Finanzierung bearbeiten' : 'Neue Finanzierung'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div>
              <Label>Immobilie *</Label>
              <Select 
                value={formData.propertyId} 
                onValueChange={(value) => setFormData({ ...formData, propertyId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  {store.properties.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Bank *</Label>
              <Input 
                value={formData.bankName} 
                onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
              />
            </div>
            <div>
              <Label>Darlehensnummer</Label>
              <Input 
                value={formData.loanNumber} 
                onChange={(e) => setFormData({ ...formData, loanNumber: e.target.value })}
              />
            </div>
            <div>
              <Label>Darlehensbetrag (€)</Label>
              <Input 
                type="number"
                value={formData.principalAmount} 
                onChange={(e) => setFormData({ ...formData, principalAmount: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Zins (%)</Label>
              <Input 
                type="number"
                step="0.01"
                value={formData.interestRate} 
                onChange={(e) => setFormData({ ...formData, interestRate: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Tilgung (%)</Label>
              <Input 
                type="number"
                step="0.01"
                value={formData.repaymentRate} 
                onChange={(e) => setFormData({ ...formData, repaymentRate: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Monatsrate (€)</Label>
              <Input 
                type="number"
                value={formData.monthlyRate} 
                onChange={(e) => setFormData({ ...formData, monthlyRate: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Restschuld (€)</Label>
              <Input 
                type="number"
                value={formData.remainingDebt} 
                onChange={(e) => setFormData({ ...formData, remainingDebt: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Laufzeit von</Label>
              <Input 
                type="date"
                value={formData.startDate} 
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
              />
            </div>
            <div>
              <Label>Laufzeit bis</Label>
              <Input 
                type="date"
                value={formData.endDate} 
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
              />
            </div>
            <div>
              <Label>Zinsbindung bis</Label>
              <Input 
                type="date"
                value={formData.fixedInterestUntil} 
                onChange={(e) => setFormData({ ...formData, fixedInterestUntil: e.target.value })}
              />
            </div>
            <div className="col-span-2">
              <Label>Notizen</Label>
              <Textarea 
                value={formData.notes} 
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Finanzierung löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie diese Finanzierung wirklich löschen?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================
// DOCUMENTS SECTION
// ============================================
function DocumentsSection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState<Document | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<string>('all');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    propertyId: '',
    unitId: '',
    tenantId: '',
    name: '',
    type: 'other' as DocumentType,
    date: '',
    description: '',
    fileData: '',
    fileName: '',
    fileType: '',
    fileSize: 0,
  });

  const filteredDocuments = filterType === 'all' 
    ? store.documents 
    : store.documents.filter(d => d.type === filterType);

  const openNewDialog = () => {
    setEditingDocument(null);
    setFormData({
      propertyId: '',
      unitId: '',
      tenantId: '',
      name: '',
      type: 'other',
      date: new Date().toISOString().split('T')[0],
      description: '',
      fileData: '',
      fileName: '',
      fileType: '',
      fileSize: 0,
    });
    setDialogOpen(true);
  };

  const openEditDialog = (document: Document) => {
    setEditingDocument(document);
    setFormData({
      propertyId: document.propertyId || '',
      unitId: document.unitId || '',
      tenantId: document.tenantId || '',
      name: document.name,
      type: document.type,
      date: document.date,
      description: document.description,
      fileData: document.fileData,
      fileName: document.fileName,
      fileType: document.fileType,
      fileSize: document.fileSize,
    });
    setDialogOpen(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setFormData({
          ...formData,
          fileData: reader.result as string,
          fileName: file.name,
          fileType: file.type,
          fileSize: file.size,
          name: formData.name || file.name,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!formData.name) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    if (editingDocument) {
      store.updateDocument(editingDocument.id, formData);
      toast.success('Dokument aktualisiert');
    } else {
      store.addDocument(formData);
      toast.success('Dokument hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      store.deleteDocument(deletingId);
      toast.success('Dokument gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const handleDownload = (document: Document) => {
    if (document.fileData) {
      const link = document.createElement('a');
      link.href = document.fileData;
      link.download = document.fileName;
      link.click();
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dokumente</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neues Dokument
        </Button>
      </div>

      {/* Filter */}
      <Select value={filterType} onValueChange={setFilterType}>
        <SelectTrigger className="w-64">
          <SelectValue placeholder="Typ filtern" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Alle Typen</SelectItem>
          {Object.entries(documentTypeLabels).map(([value, label]) => (
            <SelectItem key={value} value={value}>{label}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDocuments.map((document) => (
          <Card key={document.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{document.name}</CardTitle>
                  <CardDescription>{documentTypeLabels[document.type]}</CardDescription>
                </div>
                <FileText className="h-8 w-8 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm text-gray-600">
                <p>Datum: {formatDate(document.date)}</p>
                {document.fileName && <p>Datei: {document.fileName}</p>}
                {document.fileSize > 0 && <p>Größe: {formatFileSize(document.fileSize)}</p>}
                {document.description && <p className="text-gray-500">{document.description}</p>}
              </div>
              <Separator className="my-3" />
              <div className="flex gap-2">
                {document.fileData && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => handleDownload(document)}
                  >
                    <Download className="h-4 w-4 mr-1" /> Download
                  </Button>
                )}
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => openEditDialog(document)}
                >
                  <Edit2 className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-red-600"
                  onClick={() => {
                    setDeletingId(document.id);
                    setDeleteDialogOpen(true);
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredDocuments.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Keine Dokumente</h3>
            <p className="text-gray-500 mb-4">Fügen Sie Ihr erstes Dokument hinzu</p>
            <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="h-4 w-4 mr-2" /> Neues Dokument
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Document Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingDocument ? 'Dokument bearbeiten' : 'Neues Dokument'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label>Name *</Label>
              <Input 
                value={formData.name} 
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div>
              <Label>Typ</Label>
              <Select 
                value={formData.type} 
                onValueChange={(value: DocumentType) => setFormData({ ...formData, type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(documentTypeLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Datum</Label>
              <Input 
                type="date"
                value={formData.date} 
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>
            <div>
              <Label>Immobilie</Label>
              <Select 
                value={formData.propertyId} 
                onValueChange={(value) => setFormData({ ...formData, propertyId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Keine</SelectItem>
                  {store.properties.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Beschreibung</Label>
              <Textarea 
                value={formData.description} 
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={2}
              />
            </div>
            <div>
              <Label>Datei</Label>
              <Input 
                ref={fileInputRef}
                type="file"
                onChange={handleFileChange}
              />
              {formData.fileName && (
                <p className="text-sm text-gray-500 mt-1">
                  Aktuelle Datei: {formData.fileName}
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Dokument löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie dieses Dokument wirklich löschen?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================
// TASKS SECTION
// ============================================
function TasksSection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [formData, setFormData] = useState({
    propertyId: '',
    unitId: '',
    title: '',
    description: '',
    dueDate: '',
    priority: 'medium' as TaskPriority,
    status: 'pending' as TaskStatus,
    category: 'other' as Task['category'],
  });

  const filteredTasks = filterStatus === 'all' 
    ? store.tasks 
    : store.tasks.filter(t => t.status === filterStatus);

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
    if (a.status === 'completed' && b.status !== 'completed') return 1;
    if (a.status !== 'completed' && b.status === 'completed') return -1;
    if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    }
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });

  const openNewDialog = () => {
    setEditingTask(null);
    setFormData({
      propertyId: '',
      unitId: '',
      title: '',
      description: '',
      dueDate: new Date().toISOString().split('T')[0],
      priority: 'medium',
      status: 'pending',
      category: 'other',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (task: Task) => {
    setEditingTask(task);
    setFormData({
      propertyId: task.propertyId || '',
      unitId: task.unitId || '',
      title: task.title,
      description: task.description,
      dueDate: task.dueDate,
      priority: task.priority,
      status: task.status,
      category: task.category,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.title || !formData.dueDate) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    if (editingTask) {
      store.updateTask(editingTask.id, {
        ...formData,
        completedAt: formData.status === 'completed' ? new Date().toISOString() : undefined,
      });
      toast.success('Aufgabe aktualisiert');
    } else {
      store.addTask(formData);
      toast.success('Aufgabe hinzugefügt');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (deletingId) {
      store.deleteTask(deletingId);
      toast.success('Aufgabe gelöscht');
      setDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const handleToggleComplete = (task: Task) => {
    store.updateTask(task.id, {
      status: task.status === 'completed' ? 'pending' : 'completed',
      completedAt: task.status === 'completed' ? undefined : new Date().toISOString(),
    });
  };

  const isOverdue = (task: Task) => {
    return task.status !== 'completed' && new Date(task.dueDate) < new Date();
  };

  const categoryLabelsTask: Record<string, string> = {
    rent_check: 'Mietprüfung',
    rent_increase: 'Mieterhöhung',
    maintenance: 'Wartung',
    deadline: 'Frist',
    inspection: 'Inspektion',
    other: 'Sonstiges',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Aufgaben</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neue Aufgabe
        </Button>
      </div>

      {/* Filter */}
      <Select value={filterStatus} onValueChange={setFilterStatus}>
        <SelectTrigger className="w-48">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Alle Status</SelectItem>
          {Object.entries(taskStatusLabels).map(([value, label]) => (
            <SelectItem key={value} value={value}>{label}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Tasks List */}
      <div className="space-y-3">
        {sortedTasks.map((task) => {
          const property = task.propertyId ? store.properties.find(p => p.id === task.propertyId) : null;
          
          return (
            <Card 
              key={task.id} 
              className={`${task.status === 'completed' ? 'opacity-60' : ''} ${isOverdue(task) ? 'border-red-300 bg-red-50' : ''}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`mt-1 ${task.status === 'completed' ? 'text-emerald-600' : ''}`}
                    onClick={() => handleToggleComplete(task)}
                  >
                    {task.status === 'completed' ? (
                      <CheckCircle className="h-5 w-5" />
                    ) : (
                      <div className="h-5 w-5 rounded-full border-2 border-gray-300" />
                    )}
                  </Button>
                  
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className={`font-medium ${task.status === 'completed' ? 'line-through' : ''}`}>
                          {task.title}
                        </h3>
                        <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {formatDate(task.dueDate)}
                            {isOverdue(task) && (
                              <Badge variant="destructive" className="ml-1">Überfällig</Badge>
                            )}
                          </span>
                          {property && (
                            <span className="flex items-center gap-1">
                              <Building2 className="h-4 w-4" />
                              {property.name}
                            </span>
                          )}
                        </div>
                        {task.description && (
                          <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={priorityColors[task.priority]}>
                          {taskPriorityLabels[task.priority]}
                        </Badge>
                        <Badge className={statusColors[task.status]}>
                          {taskStatusLabels[task.status]}
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => openEditDialog(task)}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-red-600"
                          onClick={() => {
                            setDeletingId(task.id);
                            setDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {sortedTasks.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <ClipboardList className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Keine Aufgaben</h3>
            <p className="text-gray-500 mb-4">Fügen Sie Ihre erste Aufgabe hinzu</p>
            <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="h-4 w-4 mr-2" /> Neue Aufgabe
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Task Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingTask ? 'Aufgabe bearbeiten' : 'Neue Aufgabe'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label>Titel *</Label>
              <Input 
                value={formData.title} 
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Priorität</Label>
                <Select 
                  value={formData.priority} 
                  onValueChange={(value: TaskPriority) => setFormData({ ...formData, priority: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(taskPriorityLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select 
                  value={formData.status} 
                  onValueChange={(value: TaskStatus) => setFormData({ ...formData, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(taskStatusLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Kategorie</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(value: Task['category']) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(categoryLabelsTask).map(([value, label]) => (
                      <SelectItem key={value} value={value}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Fälligkeitsdatum *</Label>
                <Input 
                  type="date"
                  value={formData.dueDate} 
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                />
              </div>
            </div>
            <div>
              <Label>Immobilie</Label>
              <Select 
                value={formData.propertyId} 
                onValueChange={(value) => setFormData({ ...formData, propertyId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Keine</SelectItem>
                  {store.properties.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Beschreibung</Label>
              <Textarea 
                value={formData.description} 
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Aufgabe löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Möchten Sie diese Aufgabe wirklich löschen?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================
// REPORTS SECTION
// ============================================
function ReportsSection() {
  const store = useStore();
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  
  // Monthly cashflow data
  const monthlyData = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
    
    return months.map((month, index) => {
      const monthTransactions = store.transactions.filter(t => {
        const date = new Date(t.date);
        return date.getFullYear() === selectedYear && date.getMonth() === index;
      });
      
      const income = monthTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
      const expenses = monthTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
      
      return { month, income, expenses, cashflow: income - expenses };
    });
  }, [store.transactions, selectedYear]);

  // Category breakdown
  const categoryData = useMemo(() => {
    const expenses = store.transactions.filter(t => t.type === 'expense');
    const totalExpenses = expenses.reduce((sum, t) => sum + t.amount, 0);
    
    const byCategory = expenses.reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {} as Record<string, number>);
    
    return Object.entries(byCategory).map(([category, amount]) => ({
      name: categoryLabels[category as TransactionCategory],
      amount,
      percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0,
    })).sort((a, b) => b.amount - a.amount);
  }, [store.transactions]);

  // Property performance
  const propertyPerformance = useMemo(() => {
    return store.properties.map(p => {
      const units = store.units.filter(u => u.propertyId === p.id);
      const transactions = store.transactions.filter(t => t.propertyId === p.id);
      
      const income = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
      const expenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
      const financing = store.financings.find(f => f.propertyId === p.id);
      
      return {
        name: p.name,
        units: units.length,
        rented: units.filter(u => u.status === 'rented').length,
        marketValue: p.marketValue,
        purchasePrice: p.purchasePrice,
        income,
        expenses,
        cashflow: income - expenses,
        mortgage: financing?.remainingDebt || 0,
        yield: p.purchasePrice > 0 ? ((income - expenses) / p.purchasePrice) * 100 : 0,
      };
    });
  }, [store.properties, store.units, store.transactions, store.financings]);

  // Summary stats
  const summary = useMemo(() => {
    const totalMarketValue = store.properties.reduce((sum, p) => sum + p.marketValue, 0);
    const totalPurchasePrice = store.properties.reduce((sum, p) => sum + p.purchasePrice, 0);
    const totalMortgage = store.financings.reduce((sum, f) => sum + f.remainingDebt, 0);
    const totalIncome = store.transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
    const totalExpenses = store.transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
    
    return {
      totalMarketValue,
      totalPurchasePrice,
      totalMortgage,
      equity: totalMarketValue - totalMortgage,
      totalIncome,
      totalExpenses,
      cashflow: totalIncome - totalExpenses,
      avgYield: totalPurchasePrice > 0 ? ((totalIncome - totalExpenses) / totalPurchasePrice) * 100 : 0,
    };
  }, [store.properties, store.financings, store.transactions]);

  const years = useMemo(() => {
    const allYears = store.transactions.map(t => new Date(t.date).getFullYear());
    const uniqueYears = [...new Set(allYears)].sort((a, b) => b - a);
    return uniqueYears.length > 0 ? uniqueYears : [new Date().getFullYear()];
  }, [store.transactions]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Reports & Auswertungen</h1>
        <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {years.map(year => (
              <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Portfolio-Wert</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(summary.totalMarketValue)}</div>
            <p className="text-sm text-gray-500">Eigenkapital: {formatCurrency(summary.equity)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Jahres-Cashflow</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${summary.cashflow >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {formatCurrency(summary.cashflow)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Durchschnittsrendite</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary.avgYield.toFixed(2)}%</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Vermietungsquote</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {store.units.length > 0 
                ? Math.round((store.units.filter(u => u.status === 'rented').length / store.units.length) * 100)
                : 0}%
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Monatlicher Cashflow</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                <Legend />
                <Line type="monotone" dataKey="income" name="Einnahmen" stroke="#10b981" strokeWidth={2} />
                <Line type="monotone" dataKey="expenses" name="Ausgaben" stroke="#ef4444" strokeWidth={2} />
                <Line type="monotone" dataKey="cashflow" name="Cashflow" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ausgaben nach Kategorie</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="amount"
                >
                  {categoryData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Property Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle>Immobilien-Performance</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left p-4 font-medium text-gray-600">Immobilie</th>
                  <th className="text-right p-4 font-medium text-gray-600">Einheiten</th>
                  <th className="text-right p-4 font-medium text-gray-600">Marktwert</th>
                  <th className="text-right p-4 font-medium text-gray-600">Einnahmen</th>
                  <th className="text-right p-4 font-medium text-gray-600">Ausgaben</th>
                  <th className="text-right p-4 font-medium text-gray-600">Cashflow</th>
                  <th className="text-right p-4 font-medium text-gray-600">Rendite</th>
                </tr>
              </thead>
              <tbody>
                {propertyPerformance.map((p, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="p-4 font-medium">{p.name}</td>
                    <td className="p-4 text-right">{p.rented}/{p.units}</td>
                    <td className="p-4 text-right">{formatCurrency(p.marketValue)}</td>
                    <td className="p-4 text-right text-emerald-600">{formatCurrency(p.income)}</td>
                    <td className="p-4 text-right text-red-600">{formatCurrency(p.expenses)}</td>
                    <td className={`p-4 text-right font-medium ${p.cashflow >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                      {formatCurrency(p.cashflow)}
                    </td>
                    <td className="p-4 text-right font-medium">{p.yield.toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================
// DEPRECIATION SECTION (Abschreibungen)
// ============================================
function DepreciationSection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [filterProperty, setFilterProperty] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<DepreciationCategory | 'all'>('all');
  
  // Legacy formData für Gebäude-AfA
  const [formData, setFormData] = useState({
    propertyId: '',
    unitId: '',
    name: '',
    purchasePrice: 0,
    buildingShare: 0,
    landShare: 0,
    depreciationRate: 2.5,
    startDate: '',
    endDate: '',
    annualDepreciation: 0,
    monthlyDepreciation: 0,
    accumulatedDepreciation: 0,
    remainingValue: 0,
    type: 'linear' as 'linear' | 'degressive',
    notes: '',
  });
  
  // Neues formData für detaillierte Abschreibungspositionen
  const [itemFormData, setItemFormData] = useState({
    propertyId: '',
    unitId: '',
    name: '',
    category: 'gebaeude' as DepreciationCategory,
    purchaseValue: 0,
    depreciationRate: 2.5,
    depreciationYears: 40,
    startDate: new Date().toISOString().split('T')[0],
    annualDepreciation: 0,
    monthlyDepreciation: 0,
    accumulatedDepreciation: 0,
    remainingValue: 0,
    notes: '',
  });

  // Calculate depreciation automatically
  const calculateDepreciation = (value: number, rate: number) => {
    const annual = value * (rate / 100);
    const monthly = annual / 12;
    return { annual, monthly };
  };

  // Gefilterte Abschreibungspositionen
  const filteredItems = useMemo(() => {
    return store.depreciationItems.filter(item => {
      if (filterProperty !== 'all' && item.propertyId !== filterProperty) return false;
      if (filterCategory !== 'all' && item.category !== filterCategory) return false;
      return true;
    });
  }, [store.depreciationItems, filterProperty, filterCategory]);

  // Summary stats für beide Systeme
  const totalAnnualDepreciation = store.depreciations.reduce((sum, d) => sum + d.annualDepreciation, 0);
  const totalMonthlyDepreciation = store.depreciationItems.reduce((sum, d) => sum + d.monthlyDepreciation, 0);
  const totalAnnualItems = store.depreciationItems.reduce((sum, d) => sum + d.annualDepreciation, 0);
  const totalAccumulated = store.depreciationItems.reduce((sum, d) => sum + d.accumulatedDepreciation, 0);
  const totalRemaining = store.depreciationItems.reduce((sum, d) => sum + d.remainingValue, 0);

  // Nach Kategorien gruppiert
  const depreciationByCategory = useMemo(() => {
    const grouped: Record<DepreciationCategory, { count: number; monthly: number; annual: number }> = {
      gebaeude: { count: 0, monthly: 0, annual: 0 },
      moebel: { count: 0, monthly: 0, annual: 0 },
      kueche: { count: 0, monthly: 0, annual: 0 },
      elektro: { count: 0, monthly: 0, annual: 0 },
      inventar: { count: 0, monthly: 0, annual: 0 },
      ausstattung: { count: 0, monthly: 0, annual: 0 },
      sonstiges: { count: 0, monthly: 0, annual: 0 },
    };
    store.depreciationItems.forEach(item => {
      grouped[item.category].count++;
      grouped[item.category].monthly += item.monthlyDepreciation;
      grouped[item.category].annual += item.annualDepreciation;
    });
    return grouped;
  }, [store.depreciationItems]);

  const openNewItemDialog = () => {
    setEditingItemId(null);
    setItemFormData({
      propertyId: store.properties[0]?.id || '',
      unitId: '',
      name: '',
      category: 'gebaeude',
      purchaseValue: 0,
      depreciationRate: 2.5,
      depreciationYears: 40,
      startDate: new Date().toISOString().split('T')[0],
      annualDepreciation: 0,
      monthlyDepreciation: 0,
      accumulatedDepreciation: 0,
      remainingValue: 0,
      notes: '',
    });
    setItemDialogOpen(true);
  };

  const openEditItemDialog = (item: DepreciationItem) => {
    setEditingItemId(item.id);
    setItemFormData({
      propertyId: item.propertyId,
      unitId: item.unitId || '',
      name: item.name,
      category: item.category,
      purchaseValue: item.purchaseValue,
      depreciationRate: item.depreciationRate,
      depreciationYears: item.depreciationYears,
      startDate: item.startDate,
      annualDepreciation: item.annualDepreciation,
      monthlyDepreciation: item.monthlyDepreciation,
      accumulatedDepreciation: item.accumulatedDepreciation,
      remainingValue: item.remainingValue,
      notes: item.notes,
    });
    setItemDialogOpen(true);
  };

  const handleSaveItem = () => {
    if (!itemFormData.name || !itemFormData.propertyId) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    const { annual, monthly } = calculateDepreciation(itemFormData.purchaseValue, itemFormData.depreciationRate);
    const remaining = itemFormData.purchaseValue - itemFormData.accumulatedDepreciation;

    if (editingItemId) {
      store.updateDepreciationItem(editingItemId, {
        ...itemFormData,
        annualDepreciation: annual,
        monthlyDepreciation: monthly,
        remainingValue: remaining,
      });
      toast.success('Abschreibungsposition aktualisiert');
    } else {
      store.addDepreciationItem({
        ...itemFormData,
        annualDepreciation: annual,
        monthlyDepreciation: monthly,
        remainingValue: itemFormData.purchaseValue,
      });
      toast.success('Abschreibungsposition hinzugefügt');
    }
    setItemDialogOpen(false);
  };

  const getPropertyName = (propertyId: string) => {
    const property = store.properties.find(p => p.id === propertyId);
    return property?.name || '-';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Abschreibungen</h1>
        <Button onClick={openNewItemDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neue Position
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Jährliche AfA (alle)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalAnnualItems)}</div>
            <p className="text-xs text-gray-500 mt-1">pro Jahr</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Monatliche AfA</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalMonthlyDepreciation)}</div>
            <p className="text-xs text-gray-500 mt-1">pro Monat</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Bisher abgeschrieben</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">{formatCurrency(totalAccumulated)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Restbuchwert</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(totalRemaining)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Kategorien-Übersicht */}
      <Card>
        <CardHeader>
          <CardTitle>Abschreibungen nach Kategorien</CardTitle>
          <CardDescription>Aufteilung nach Art des Wirtschaftsguts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
            {(Object.entries(depreciationByCategory) as [DepreciationCategory, { count: number; monthly: number; annual: number }][]).map(([category, data]) => (
              <div 
                key={category} 
                className={`text-center p-3 rounded-lg cursor-pointer transition-colors ${
                  filterCategory === category ? 'ring-2 ring-emerald-500 bg-emerald-50' : 'bg-gray-50 hover:bg-gray-100'
                }`}
                onClick={() => setFilterCategory(filterCategory === category ? 'all' : category)}
              >
                <Badge className={depreciationCategoryColors[category] + ' mb-2'}>
                  {depreciationCategoryLabels[category]}
                </Badge>
                <div className="text-lg font-bold">{formatCurrency(data.monthly)}</div>
                <p className="text-xs text-gray-500">{data.count} Positionen</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Filter */}
      <div className="flex gap-4">
        <Select value={filterProperty} onValueChange={setFilterProperty}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Immobilie filtern" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle Immobilien</SelectItem>
            {store.properties.map(p => (
              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {filterCategory !== 'all' && (
          <Button variant="outline" onClick={() => setFilterCategory('all')}>
            Filter entfernen
          </Button>
        )}
      </div>

      {/* Abschreibungspositionen Tabelle */}
      <Card>
        <CardHeader>
          <CardTitle>Detaillierte Abschreibungspositionen</CardTitle>
          <CardDescription>Individuelle Abschreibungen pro Wirtschaftsgut</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left p-4 font-medium text-gray-600">Bezeichnung</th>
                  <th className="text-left p-4 font-medium text-gray-600">Kategorie</th>
                  <th className="text-left p-4 font-medium text-gray-600">Immobilie</th>
                  <th className="text-right p-4 font-medium text-gray-600">Anschaffung</th>
                  <th className="text-right p-4 font-medium text-gray-600">AfA-Satz</th>
                  <th className="text-right p-4 font-medium text-gray-600">Jahre</th>
                  <th className="text-right p-4 font-medium text-gray-600">Monatl. AfA</th>
                  <th className="text-right p-4 font-medium text-gray-600">Bisher</th>
                  <th className="text-right p-4 font-medium text-gray-600">Restwert</th>
                  <th className="text-right p-4 font-medium text-gray-600">Aktionen</th>
                </tr>
              </thead>
              <tbody>
                {filteredItems.map((item) => {
                  return (
                    <tr key={item.id} className="border-b hover:bg-gray-50">
                      <td className="p-4 font-medium">{item.name}</td>
                      <td className="p-4">
                        <Badge className={depreciationCategoryColors[item.category]}>
                          {depreciationCategoryLabels[item.category]}
                        </Badge>
                      </td>
                      <td className="p-4">{getPropertyName(item.propertyId)}</td>
                      <td className="p-4 text-right">{formatCurrency(item.purchaseValue)}</td>
                      <td className="p-4 text-right">{item.depreciationRate}%</td>
                      <td className="p-4 text-right">{item.depreciationYears}</td>
                      <td className="p-4 text-right">{formatCurrency(item.monthlyDepreciation)}</td>
                      <td className="p-4 text-right text-emerald-600">{formatCurrency(item.accumulatedDepreciation)}</td>
                      <td className="p-4 text-right text-blue-600">{formatCurrency(item.remainingValue)}</td>
                      <td className="p-4">
                        <div className="flex gap-2 justify-end">
                          <Button variant="ghost" size="sm" onClick={() => openEditItemDialog(item)}>
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-600"
                            onClick={() => store.deleteDepreciationItem(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filteredItems.length === 0 && (
            <div className="py-12 text-center text-gray-500">
              Keine Abschreibungspositionen gefunden
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog für neue Abschreibungspositionen */}
      <Dialog open={itemDialogOpen} onOpenChange={setItemDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingItemId ? 'Position bearbeiten' : 'Neue Abschreibungsposition'}</DialogTitle>
            <DialogDescription>
              Erfassen Sie alle abschreibbaren Wirtschaftsgüter (Gebäude, Möbel, Inventar, etc.)
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div>
              <Label>Bezeichnung *</Label>
              <Input 
                value={itemFormData.name} 
                onChange={(e) => setItemFormData({ ...itemFormData, name: e.target.value })}
                placeholder="z.B. Einbauküche, Möbel, Markise"
              />
            </div>
            <div>
              <Label>Kategorie *</Label>
              <Select 
                value={itemFormData.category} 
                onValueChange={(value: DepreciationCategory) => setItemFormData({ ...itemFormData, category: value })}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(depreciationCategoryLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Immobilie *</Label>
              <Select 
                value={itemFormData.propertyId} 
                onValueChange={(v) => setItemFormData({ ...itemFormData, propertyId: v })}
              >
                <SelectTrigger><SelectValue placeholder="Auswählen" /></SelectTrigger>
                <SelectContent>
                  {store.properties.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Einheit (optional)</Label>
              <Select 
                value={itemFormData.unitId} 
                onValueChange={(v) => setItemFormData({ ...itemFormData, unitId: v })}
              >
                <SelectTrigger><SelectValue placeholder="Auswählen" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Keine</SelectItem>
                  {store.units
                    .filter(u => u.propertyId === itemFormData.propertyId)
                    .map(u => (
                      <SelectItem key={u.id} value={u.id}>{u.unitNumber}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Anschaffungswert (€) *</Label>
              <Input 
                type="number" 
                value={itemFormData.purchaseValue} 
                onChange={(e) => {
                  const value = parseFloat(e.target.value) || 0;
                  const { annual, monthly } = calculateDepreciation(value, itemFormData.depreciationRate);
                  setItemFormData({ 
                    ...itemFormData, 
                    purchaseValue: value,
                    annualDepreciation: annual,
                    monthlyDepreciation: monthly,
                    remainingValue: value - itemFormData.accumulatedDepreciation,
                  });
                }}
              />
            </div>
            <div>
              <Label>Abschreibungssatz (%) *</Label>
              <Input 
                type="number" 
                step="0.1"
                value={itemFormData.depreciationRate} 
                onChange={(e) => {
                  const rate = parseFloat(e.target.value) || 0;
                  const { annual, monthly } = calculateDepreciation(itemFormData.purchaseValue, rate);
                  setItemFormData({ 
                    ...itemFormData, 
                    depreciationRate: rate,
                    annualDepreciation: annual,
                    monthlyDepreciation: monthly,
                  });
                }}
              />
            </div>
            <div>
              <Label>Abschreibungsdauer (Jahre)</Label>
              <Input 
                type="number" 
                value={itemFormData.depreciationYears} 
                onChange={(e) => setItemFormData({ ...itemFormData, depreciationYears: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>Startdatum</Label>
              <Input 
                type="date" 
                value={itemFormData.startDate} 
                onChange={(e) => setItemFormData({ ...itemFormData, startDate: e.target.value })}
              />
            </div>
            <div>
              <Label>Bereits abgeschrieben (€)</Label>
              <Input 
                type="number" 
                value={itemFormData.accumulatedDepreciation} 
                onChange={(e) => {
                  const acc = parseFloat(e.target.value) || 0;
                  setItemFormData({ 
                    ...itemFormData, 
                    accumulatedDepreciation: acc,
                    remainingValue: itemFormData.purchaseValue - acc,
                  });
                }}
              />
            </div>
            <div>
              <Label>Berechnete Monats-AfA</Label>
              <div className="text-lg font-bold text-indigo-600 py-2">
                {formatCurrency(itemFormData.monthlyDepreciation)}
              </div>
            </div>
            <div className="col-span-2">
              <Label>Notizen</Label>
              <Textarea 
                value={itemFormData.notes} 
                onChange={(e) => setItemFormData({ ...itemFormData, notes: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setItemDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSaveItem} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================
// HOUSE MONEY SECTION (Hausgelder)
// ============================================
function HouseMoneySection() {
  const store = useStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterMonth, setFilterMonth] = useState(new Date().toISOString().slice(0, 7));
  const [formData, setFormData] = useState({
    propertyId: '',
    unitId: '',
    month: new Date().toISOString().slice(0, 7),
    totalAmount: 0,
    maintenanceReserve: 0,
    administrativeFee: 0,
    utilities: 0,
    water: 0,
    heating: 0,
    garbage: 0,
    insurance: 0,
    other: 0,
    paymentStatus: 'pending' as 'paid' | 'pending' | 'overdue',
    paymentDate: '',
    notes: '',
  });

  const openNewDialog = () => {
    setEditingId(null);
    setFormData({
      propertyId: store.properties[0]?.id || '',
      unitId: '',
      month: new Date().toISOString().slice(0, 7),
      totalAmount: 0,
      maintenanceReserve: 0,
      administrativeFee: 0,
      utilities: 0,
      water: 0,
      heating: 0,
      garbage: 0,
      insurance: 0,
      other: 0,
      paymentStatus: 'pending',
      paymentDate: '',
      notes: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (hm: typeof store.houseMoney[0]) => {
    setEditingId(hm.id);
    setFormData({
      propertyId: hm.propertyId,
      unitId: hm.unitId || '',
      month: hm.month,
      totalAmount: hm.totalAmount,
      maintenanceReserve: hm.maintenanceReserve,
      administrativeFee: hm.administrativeFee,
      utilities: hm.utilities,
      water: hm.water,
      heating: hm.heating,
      garbage: hm.garbage,
      insurance: hm.insurance,
      other: hm.other,
      paymentStatus: hm.paymentStatus,
      paymentDate: hm.paymentDate || '',
      notes: hm.notes,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.propertyId || !formData.month) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return;
    }

    const total = formData.maintenanceReserve + formData.administrativeFee + formData.utilities + 
                  formData.water + formData.heating + formData.garbage + formData.insurance + formData.other;

    if (editingId) {
      store.updateHouseMoney(editingId, { ...formData, totalAmount: total });
      toast.success('Hausgeld aktualisiert');
    } else {
      store.addHouseMoney({ ...formData, totalAmount: total });
      toast.success('Hausgeld hinzugefügt');
    }
    setDialogOpen(false);
  };

  // Summary
  const filteredHouseMoney = store.houseMoney.filter(hm => hm.month.startsWith(filterMonth.split('-')[0]));
  const totalHouseMoney = filteredHouseMoney.reduce((sum, hm) => sum + hm.totalAmount, 0);
  const paidHouseMoney = filteredHouseMoney.filter(hm => hm.paymentStatus === 'paid').reduce((sum, hm) => sum + hm.totalAmount, 0);
  const pendingHouseMoney = filteredHouseMoney.filter(hm => hm.paymentStatus === 'pending').reduce((sum, hm) => sum + hm.totalAmount, 0);

  const statusColors = {
    paid: 'bg-green-100 text-green-800',
    pending: 'bg-yellow-100 text-yellow-800',
    overdue: 'bg-red-100 text-red-800',
  };

  const statusLabels = {
    paid: 'Bezahlt',
    pending: 'Offen',
    overdue: 'Überfällig',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Hausgelder</h1>
        <Button onClick={openNewDialog} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" /> Neues Hausgeld
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Gesamt Hausgeld</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalHouseMoney)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Bezahlt</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">{formatCurrency(paidHouseMoney)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Offen</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{formatCurrency(pendingHouseMoney)}</div>
          </CardContent>
        </Card>
      </div>

      {/* House Money Table */}
      <Card>
        <CardHeader>
          <CardTitle>Hausgeld-Übersicht</CardTitle>
          <CardDescription>Nebenkostenabrechnungen und Vorauszahlungen</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left p-4 font-medium text-gray-600">Monat</th>
                  <th className="text-left p-4 font-medium text-gray-600">Einheit</th>
                  <th className="text-right p-4 font-medium text-gray-600">Gesamt</th>
                  <th className="text-right p-4 font-medium text-gray-600">Rücklage</th>
                  <th className="text-right p-4 font-medium text-gray-600">Verwaltung</th>
                  <th className="text-right p-4 font-medium text-gray-600">Betriebskosten</th>
                  <th className="text-left p-4 font-medium text-gray-600">Status</th>
                  <th className="text-right p-4 font-medium text-gray-600">Aktionen</th>
                </tr>
              </thead>
              <tbody>
                {store.houseMoney.map((hm) => {
                  const property = store.properties.find(p => p.id === hm.propertyId);
                  const unit = store.units.find(u => u.id === hm.unitId);
                  return (
                    <tr key={hm.id} className="border-b hover:bg-gray-50">
                      <td className="p-4 font-medium">{hm.month}</td>
                      <td className="p-4">{property?.name} {unit ? `- ${unit.unitNumber}` : ''}</td>
                      <td className="p-4 text-right">{formatCurrency(hm.totalAmount)}</td>
                      <td className="p-4 text-right">{formatCurrency(hm.maintenanceReserve)}</td>
                      <td className="p-4 text-right">{formatCurrency(hm.administrativeFee)}</td>
                      <td className="p-4 text-right">{formatCurrency(hm.utilities + hm.water + hm.heating + hm.garbage)}</td>
                      <td className="p-4">
                        <Badge className={statusColors[hm.paymentStatus]}>{statusLabels[hm.paymentStatus]}</Badge>
                      </td>
                      <td className="p-4">
                        <div className="flex gap-2 justify-end">
                          <Button variant="ghost" size="sm" onClick={() => openEditDialog(hm)}>
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-600"
                            onClick={() => store.deleteHouseMoney(hm.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {store.houseMoney.length === 0 && (
            <div className="py-12 text-center text-gray-500">
              Keine Hausgelder erfasst
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Hausgeld bearbeiten' : 'Neues Hausgeld'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div>
              <Label>Immobilie *</Label>
              <Select value={formData.propertyId} onValueChange={(v) => setFormData({ ...formData, propertyId: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {store.properties.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Monat *</Label>
              <Input type="month" value={formData.month} onChange={(e) => setFormData({ ...formData, month: e.target.value })} />
            </div>
            <div>
              <Label>Instandhaltungsrücklage (€)</Label>
              <Input type="number" value={formData.maintenanceReserve} onChange={(e) => setFormData({ ...formData, maintenanceReserve: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <Label>Verwaltungskostenbeitrag (€)</Label>
              <Input type="number" value={formData.administrativeFee} onChange={(e) => setFormData({ ...formData, administrativeFee: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <Label>Betriebskosten (€)</Label>
              <Input type="number" value={formData.utilities} onChange={(e) => setFormData({ ...formData, utilities: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <Label>Wasser (€)</Label>
              <Input type="number" value={formData.water} onChange={(e) => setFormData({ ...formData, water: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <Label>Heizung (€)</Label>
              <Input type="number" value={formData.heating} onChange={(e) => setFormData({ ...formData, heating: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <Label>Müll (€)</Label>
              <Input type="number" value={formData.garbage} onChange={(e) => setFormData({ ...formData, garbage: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <Label>Versicherung (€)</Label>
              <Input type="number" value={formData.insurance} onChange={(e) => setFormData({ ...formData, insurance: parseFloat(e.target.value) || 0 })} />
            </div>
            <div>
              <Label>Status</Label>
              <Select value={formData.paymentStatus} onValueChange={(v: 'paid' | 'pending' | 'overdue') => setFormData({ ...formData, paymentStatus: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Offen</SelectItem>
                  <SelectItem value="paid">Bezahlt</SelectItem>
                  <SelectItem value="overdue">Überfällig</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label>Notizen</Label>
              <Textarea value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================
// SETTINGS SECTION
// ============================================
function SettingsSection() {
  const store = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [importData, setImportData] = useState<string>('');

  const handleExport = () => {
    const data = store.exportData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bucki-export-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Daten exportiert');
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImportData(reader.result as string);
        setImportDialogOpen(true);
      };
      reader.readAsText(file);
    }
  };

  const handleImportConfirm = () => {
    try {
      const data = JSON.parse(importData);
      if (data.data) {
        store.importData(data);
        toast.success('Daten importiert');
      } else {
        toast.error('Ungültiges Datenformat');
      }
    } catch {
      toast.error('Fehler beim Importieren');
    }
    setImportDialogOpen(false);
    setImportData('');
  };

  const handleReset = () => {
    if (confirm('Möchten Sie wirklich alle Daten zurücksetzen? Diese Aktion kann nicht rückgängig gemacht werden.')) {
      store.resetData();
      toast.success('Daten zurückgesetzt');
    }
  };

  const stats = useMemo(() => ({
    properties: store.properties.length,
    units: store.units.length,
    tenants: store.tenants.length,
    transactions: store.transactions.length,
    financings: store.financings.length,
    documents: store.documents.length,
    tasks: store.tasks.length,
  }), [store.properties, store.units, store.tenants, store.transactions, store.financings, store.documents, store.tasks]);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Einstellungen</h1>

      {/* Data Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Datenübersicht</CardTitle>
          <CardDescription>Aktuelle Anzahl der gespeicherten Datensätze</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Immobilien</p>
              <p className="text-2xl font-bold">{stats.properties}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Einheiten</p>
              <p className="text-2xl font-bold">{stats.units}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Mieter</p>
              <p className="text-2xl font-bold">{stats.tenants}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Transaktionen</p>
              <p className="text-2xl font-bold">{stats.transactions}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Finanzierungen</p>
              <p className="text-2xl font-bold">{stats.financings}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Dokumente</p>
              <p className="text-2xl font-bold">{stats.documents}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Aufgaben</p>
              <p className="text-2xl font-bold">{stats.tasks}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Export/Import */}
      <Card>
        <CardHeader>
          <CardTitle>Daten-Management</CardTitle>
          <CardDescription>Exportieren oder importieren Sie Ihre Daten</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button onClick={handleExport} className="bg-emerald-600 hover:bg-emerald-700">
              <Download className="h-4 w-4 mr-2" /> Export (JSON)
            </Button>
            <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
              <Upload className="h-4 w-4 mr-2" /> Import
            </Button>
            <Input 
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleImportFile}
            />
            <Button variant="outline" className="text-red-600" onClick={handleReset}>
              <RotateCcw className="h-4 w-4 mr-2" /> Zurücksetzen
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* App Info */}
      <Card>
        <CardHeader>
          <CardTitle>App-Informationen</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <p><strong>Name:</strong> Bucki - Immobilien-Verwaltung</p>
            <p><strong>Version:</strong> 1.0.0</p>
            <p><strong>Datenspeicherung:</strong> Lokal (localStorage)</p>
            <p><strong>Framework:</strong> Next.js 16 mit TypeScript</p>
            <p><strong>UI:</strong> Tailwind CSS & shadcn/ui</p>
          </div>
        </CardContent>
      </Card>

      {/* Import Dialog */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Daten importieren</DialogTitle>
            <DialogDescription>
              Möchten Sie die Daten aus dieser Datei importieren? Alle vorhandenen Daten werden überschrieben.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-gray-500">
              Die Datei enthält die neue Datenbank. Dieser Vorgang kann nicht rückgängig gemacht werden.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setImportDialogOpen(false)}>Abbrechen</Button>
            <Button onClick={handleImportConfirm} className="bg-emerald-600 hover:bg-emerald-700">
              Importieren
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
