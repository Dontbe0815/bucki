// Immobilien-Verwaltungs-App "Bucki" - TypeScript Types

// Basis-Interface für alle Entitäten
export interface BaseEntity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

// Immobilie
export interface Property extends BaseEntity {
  name: string;
  address: string;
  city: string;
  postalCode: string;
  purchasePrice: number;
  purchaseDate: string;
  totalArea: number; // Wohnfläche in m²
  unitsCount: number;
  marketValue: number;
  estimatedValue: number; // ImmoScout24-ähnlicher Schätzwert
  estimatedValueDate: string; // Datum der Schätzung
  pricePerSqm: number; // Preis pro m² (für Berechnung)
  condition: 'excellent' | 'good' | 'fair' | 'needs_renovation'; // Zustand
  energyClass: 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'unknown'; // Energieklasse
  propertyType: 'apartment' | 'house' | 'commercial' | 'mixed';
  yearBuilt: number;
  locationQuality: 'top' | 'good' | 'average' | 'below_average'; // Lagequalität
  notes: string;
  images: string[]; // Base64 encoded images
}

// Einheit (Wohnung/Einheit)
export interface Unit extends BaseEntity {
  propertyId: string;
  unitNumber: string;
  floor: number;
  area: number; // m²
  rooms: number;
  baseRent: number; // Kaltmiete
  additionalCosts: number; // Nebenkosten
  totalRent: number; // Warmmiete
  status: 'rented' | 'vacant' | 'renovation' | 'reserved';
  description: string;
}

// Mieter
export interface Tenant extends BaseEntity {
  unitId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  street: string;
  city: string;
  postalCode: string;
  moveInDate: string;
  moveOutDate?: string;
  deposit: number;
  contractType: 'fixed' | 'indefinite';
  contractStartDate: string;
  contractEndDate?: string;
  notes: string;
}

// Einnahmen/Ausgaben
export type TransactionType = 'income' | 'expense';
export type TransactionCategory = 
  | 'rent' 
  | 'utilities' 
  | 'repairs' 
  | 'insurance' 
  | 'mortgage' 
  | 'reserves' 
  | 'management' 
  | 'taxes' 
  | 'other';

export interface Transaction extends BaseEntity {
  propertyId?: string;
  unitId?: string;
  type: TransactionType;
  category: TransactionCategory;
  amount: number;
  date: string;
  description: string;
  receipt?: string; // Base64 encoded receipt
  isRecurring: boolean;
  recurringInterval?: 'monthly' | 'quarterly' | 'yearly';
}

// Finanzierung
export interface Financing extends BaseEntity {
  propertyId: string;
  bankName: string;
  loanNumber: string;
  principalAmount: number;
  interestRate: number; // Prozent
  repaymentRate: number; // Tilgung in Prozent
  monthlyRate: number;
  remainingDebt: number;
  startDate: string;
  endDate: string;
  fixedInterestUntil?: string;
  notes: string;
}

// Dokument
export type DocumentType = 
  | 'rental_contract' 
  | 'purchase_contract' 
  | 'invoice' 
  | 'energy_certificate' 
  | 'insurance' 
  | 'mortgage' 
  | 'other';

export interface Document extends BaseEntity {
  propertyId?: string;
  unitId?: string;
  tenantId?: string;
  name: string;
  type: DocumentType;
  date: string;
  description: string;
  fileData: string; // Base64 encoded file
  fileName: string;
  fileType: string; // MIME type
  fileSize: number; // in bytes
}

// Aufgabe
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';

export interface Task extends BaseEntity {
  propertyId?: string;
  unitId?: string;
  title: string;
  description: string;
  dueDate: string;
  priority: TaskPriority;
  status: TaskStatus;
  category: 'rent_check' | 'rent_increase' | 'maintenance' | 'deadline' | 'inspection' | 'other';
  assignedTo?: string;
  completedAt?: string;
}

// Abschreibung
export interface Depreciation extends BaseEntity {
  propertyId: string;
  unitId?: string;
  name: string;
  purchasePrice: number; // Anschaffungskosten
  buildingShare: number; // Gebäudeanteil in Euro
  landShare: number; // Grund und Boden in Euro
  depreciationRate: number; // Abschreibungssatz (z.B. 2.5% für 40 Jahre)
  startDate: string; // Beginn der Abschreibung
  endDate: string; // Ende der Abschreibung
  annualDepreciation: number; // Jährliche Abschreibung
  monthlyDepreciation: number; // Monatliche Abschreibung
  accumulatedDepreciation: number; // Bisher abgeschrieben
  remainingValue: number; // Restbuchwert
  type: 'linear' | 'degressive';
  notes: string;
}

// Hausgeld
export interface HouseMoney extends BaseEntity {
  propertyId: string;
  unitId?: string;
  month: string; // z.B. "2026-01"
  totalAmount: number; // Gesamtes Hausgeld
  maintenanceReserve: number; // Instandhaltungsrücklage
  administrativeFee: number; // Verwaltungskostenbeitrag
  utilities: number; // Betriebskosten
  water: number; // Wasser
  heating: number; // Heizung
  garbage: number; // Müll
  insurance: number; // Versicherung
  other: number; // Sonstiges
  paymentStatus: 'paid' | 'pending' | 'overdue';
  paymentDate?: string;
  notes: string;
}

// App State
export interface AppState {
  properties: Property[];
  units: Unit[];
  tenants: Tenant[];
  transactions: Transaction[];
  financings: Financing[];
  documents: Document[];
  tasks: Task[];
  depreciations: Depreciation[];
  houseMoney: HouseMoney[];
  
  // Actions
  addProperty: (property: Omit<Property, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateProperty: (id: string, property: Partial<Property>) => void;
  deleteProperty: (id: string) => void;
  
  addUnit: (unit: Omit<Unit, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateUnit: (id: string, unit: Partial<Unit>) => void;
  deleteUnit: (id: string) => void;
  
  addTenant: (tenant: Omit<Tenant, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateTenant: (id: string, tenant: Partial<Tenant>) => void;
  deleteTenant: (id: string) => void;
  
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  
  addFinancing: (financing: Omit<Financing, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateFinancing: (id: string, financing: Partial<Financing>) => void;
  deleteFinancing: (id: string) => void;
  
  addDocument: (document: Omit<Document, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateDocument: (id: string, document: Partial<Document>) => void;
  deleteDocument: (id: string) => void;
  
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateTask: (id: string, task: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  
  addDepreciation: (depreciation: Omit<Depreciation, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateDepreciation: (id: string, depreciation: Partial<Depreciation>) => void;
  deleteDepreciation: (id: string) => void;
  
  addHouseMoney: (houseMoney: Omit<HouseMoney, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateHouseMoney: (id: string, houseMoney: Partial<HouseMoney>) => void;
  deleteHouseMoney: (id: string) => void;
  
  // Import/Export
  importData: (data: ExportData) => void;
  exportData: () => ExportData;
  resetData: () => void;
}

// Export Data Format
export interface ExportData {
  version: string;
  exportDate: string;
  data: {
    properties: Property[];
    units: Unit[];
    tenants: Tenant[];
    transactions: Transaction[];
    financings: Financing[];
    documents: Document[];
    tasks: Task[];
    depreciations: Depreciation[];
    houseMoney: HouseMoney[];
  };
}

// Dashboard Stats
export interface DashboardStats {
  totalProperties: number;
  totalUnits: number;
  rentedUnits: number;
  vacantUnits: number;
  totalRentIncome: number;
  totalExpenses: number;
  cashflow: number;
  totalMarketValue: number;
  totalMortgageDebt: number;
  equity: number;
  openTasks: number;
  overdueTasks: number;
}

// Chart Data Types
export interface MonthlyCashflow {
  month: string;
  income: number;
  expenses: number;
  cashflow: number;
}

export interface CategoryBreakdown {
  category: string;
  amount: number;
  percentage: number;
}
