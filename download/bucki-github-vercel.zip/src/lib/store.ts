import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { 
  AppState, 
  Property, 
  Unit, 
  Tenant, 
  Transaction, 
  Financing, 
  Document, 
  Task,
  Depreciation,
  HouseMoney,
  ExportData 
} from './types';

// Helper function to generate unique IDs
const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

// Helper function to get current timestamp
const getTimestamp = () => new Date().toISOString();

// ============================================
// REAL DATA FROM EXCEL: 2026 Haushaltsrechnung.xlsx
// ============================================

// Immobilien basierend auf den Adressen aus der Excel-Datei
const demoProperties: Property[] = [
  {
    id: 'prop-1',
    name: 'Arndtstraße 115',
    address: 'Arndtstraße 115',
    city: 'Dortmund',
    postalCode: '44145',
    purchasePrice: 60000, // WE 7 + WE 05
    purchaseDate: '2018-01-15',
    totalArea: 84, // 41 + 43 m²
    unitsCount: 2,
    marketValue: 60000,
    estimatedValue: 184800, // Basierend auf 2200 €/m²
    estimatedValueDate: '2026-03-01',
    pricePerSqm: 2200,
    condition: 'good',
    energyClass: 'D',
    propertyType: 'apartment',
    yearBuilt: 1960,
    locationQuality: 'average',
    notes: 'WE 7 (41m², 20.000€) und WE 05 (43m², 40.000€)',
    images: [],
    createdAt: '2018-01-15T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'prop-2',
    name: 'Friedrichstraße 8',
    address: 'Friedrichstraße 8',
    city: 'Dortmund',
    postalCode: '44137',
    purchasePrice: 124000, // WE 11 + WE 14
    purchaseDate: '2019-03-01',
    totalArea: 92, // 46 + 46 m²
    unitsCount: 2,
    marketValue: 124000,
    estimatedValue: 242200,
    estimatedValueDate: '2026-03-01',
    pricePerSqm: 2632,
    condition: 'good',
    energyClass: 'D',
    propertyType: 'apartment',
    yearBuilt: 1955,
    locationQuality: 'good',
    notes: 'WE 11 (46m², 59.000€) und WE 14 (46m², 65.000€)',
    images: [],
    createdAt: '2019-03-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'prop-3',
    name: 'Dülmener Straße 19',
    address: 'Dülmener Straße 19',
    city: 'Datteln',
    postalCode: '45711',
    purchasePrice: 65000,
    purchaseDate: '2020-06-01',
    totalArea: 78,
    unitsCount: 1,
    marketValue: 65000,
    estimatedValue: 148200,
    estimatedValueDate: '2026-03-01',
    pricePerSqm: 1900,
    condition: 'good',
    energyClass: 'C',
    propertyType: 'apartment',
    yearBuilt: 1970,
    locationQuality: 'average',
    notes: 'WE 78m², 65.000€ Kaufpreis',
    images: [],
    createdAt: '2020-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'prop-4',
    name: 'Friedrichstraße 6',
    address: 'Friedrichstraße 6',
    city: 'Dortmund',
    postalCode: '44137',
    purchasePrice: 55000,
    purchaseDate: '2021-02-01',
    totalArea: 47,
    unitsCount: 1,
    marketValue: 55000,
    estimatedValue: 112800,
    estimatedValueDate: '2026-03-01',
    pricePerSqm: 2400,
    condition: 'good',
    energyClass: 'D',
    propertyType: 'apartment',
    yearBuilt: 1955,
    locationQuality: 'good',
    notes: 'WE 01 (47m², 55.000€)',
    images: [],
    createdAt: '2021-02-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'prop-5',
    name: 'Körnerstraße 43',
    address: 'Körnerstraße 43',
    city: 'Dortmund',
    postalCode: '44143',
    purchasePrice: 53000,
    purchaseDate: '2022-08-01',
    totalArea: 44,
    unitsCount: 1,
    marketValue: 53000,
    estimatedValue: 101200,
    estimatedValueDate: '2026-03-01',
    pricePerSqm: 2300,
    condition: 'fair',
    energyClass: 'E',
    propertyType: 'apartment',
    yearBuilt: 1965,
    locationQuality: 'average',
    notes: '44m², 53.000€ + Carport',
    images: [],
    createdAt: '2022-08-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'prop-6',
    name: 'Phönixseeallee 152',
    address: 'Hörder Phönixseeallee 152',
    city: 'Dortmund',
    postalCode: '44145',
    purchasePrice: 182500, // WE 3 + WE 4
    purchaseDate: '2023-04-01',
    totalArea: 76, // 39 + 37 m²
    unitsCount: 2,
    marketValue: 182500,
    estimatedValue: 319200,
    estimatedValueDate: '2026-03-01',
    pricePerSqm: 4200,
    condition: 'excellent',
    energyClass: 'A',
    propertyType: 'apartment',
    yearBuilt: 2020,
    locationQuality: 'top',
    notes: 'WE 3 (39m², 91.250€) und WE 4 (37m², 91.250€)',
    images: [],
    createdAt: '2023-04-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'prop-7',
    name: 'Hohenstein 62',
    address: 'Hohenstein 62',
    city: 'Wuppertal',
    postalCode: '42283',
    purchasePrice: 45000,
    purchaseDate: '2024-01-01',
    totalArea: 50,
    unitsCount: 1,
    marketValue: 50000,
    estimatedValue: 90000,
    estimatedValueDate: '2026-03-01',
    pricePerSqm: 1800,
    condition: 'good',
    energyClass: 'D',
    propertyType: 'apartment',
    yearBuilt: 1975,
    locationQuality: 'average',
    notes: 'WE 9 (50m²)',
    images: [],
    createdAt: '2024-01-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'prop-8',
    name: 'Goldhammerstraße 46',
    address: 'Goldhammerstraße 46',
    city: 'Bochum',
    postalCode: '44793',
    purchasePrice: 35000,
    purchaseDate: '2024-06-01',
    totalArea: 38,
    unitsCount: 1,
    marketValue: 40000,
    estimatedValue: 76000,
    estimatedValueDate: '2026-03-01',
    pricePerSqm: 2000,
    condition: 'good',
    energyClass: 'D',
    propertyType: 'apartment',
    yearBuilt: 1960,
    locationQuality: 'average',
    notes: 'WE 7 (38m²)',
    images: [],
    createdAt: '2024-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
];

// Einheiten aus der Excel-Datei
const demoUnits: Unit[] = [
  // Arndtstraße 115
  {
    id: 'unit-1',
    propertyId: 'prop-1',
    unitNumber: 'WE 7',
    floor: 0,
    area: 41,
    rooms: 2,
    baseRent: 370, // Kaltmiete
    additionalCosts: 160, // Nebenkosten
    totalRent: 530, // Gesamtmiete
    status: 'rented',
    description: '41m², Kaufpreis 20.000€',
    createdAt: '2018-01-15T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'unit-2',
    propertyId: 'prop-1',
    unitNumber: 'WE 05',
    floor: 0,
    area: 43,
    rooms: 2,
    baseRent: 377, // Kaltmiete
    additionalCosts: 133, // Nebenkosten
    totalRent: 510, // Gesamtmiete
    status: 'rented',
    description: '43m², Kaufpreis 40.000€',
    createdAt: '2018-01-15T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  // Friedrichstraße 8
  {
    id: 'unit-3',
    propertyId: 'prop-2',
    unitNumber: 'WE 11',
    floor: 1,
    area: 46,
    rooms: 2,
    baseRent: 390, // Kaltmiete
    additionalCosts: 220, // Nebenkosten
    totalRent: 610, // Gesamtmiete
    status: 'rented',
    description: '46m², Kaufpreis 59.000€',
    createdAt: '2019-03-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'unit-4',
    propertyId: 'prop-2',
    unitNumber: 'WE 14',
    floor: 1,
    area: 46,
    rooms: 2,
    baseRent: 449.35, // Kaltmiete
    additionalCosts: 200.65, // Nebenkosten
    totalRent: 650, // Gesamtmiete
    status: 'rented',
    description: '46m², Kaufpreis 65.000€',
    createdAt: '2019-03-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  // Dülmener Straße 19
  {
    id: 'unit-5',
    propertyId: 'prop-3',
    unitNumber: 'WE 1',
    floor: 0,
    area: 78,
    rooms: 3,
    baseRent: 500, // Kaltmiete
    additionalCosts: 200, // Nebenkosten
    totalRent: 700, // Gesamtmiete
    status: 'rented',
    description: '78m², Kaufpreis 65.000€',
    createdAt: '2020-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  // Friedrichstraße 6
  {
    id: 'unit-6',
    propertyId: 'prop-4',
    unitNumber: 'WE 01',
    floor: 0,
    area: 47,
    rooms: 2,
    baseRent: 320, // Kaltmiete
    additionalCosts: 190, // Nebenkosten
    totalRent: 510, // Gesamtmiete
    status: 'rented',
    description: '47m², Kaufpreis 55.000€',
    createdAt: '2021-02-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  // Körnerstraße 43
  {
    id: 'unit-7',
    propertyId: 'prop-5',
    unitNumber: 'WE 1',
    floor: 0,
    area: 44,
    rooms: 2,
    baseRent: 0, // Leerstand
    additionalCosts: 0,
    totalRent: 0,
    status: 'vacant', // Leerstand/Keine Miete
    description: '44m², Kaufpreis 53.000€ + Carport',
    createdAt: '2022-08-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  // Phönixseeallee 152
  {
    id: 'unit-8',
    propertyId: 'prop-6',
    unitNumber: 'WE 3',
    floor: 0,
    area: 39,
    rooms: 1,
    baseRent: 313, // Kaltmiete
    additionalCosts: 87, // Nebenkosten
    totalRent: 400, // Gesamtmiete
    status: 'rented',
    description: '39m², Kaufpreis 91.250€',
    createdAt: '2023-04-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'unit-9',
    propertyId: 'prop-6',
    unitNumber: 'WE 4',
    floor: 0,
    area: 37,
    rooms: 1,
    baseRent: 520, // Kaltmiete
    additionalCosts: 80, // Nebenkosten
    totalRent: 600, // Gesamtmiete
    status: 'rented',
    description: '37m², Kaufpreis 91.250€',
    createdAt: '2023-04-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  // Hohenstein 62
  {
    id: 'unit-10',
    propertyId: 'prop-7',
    unitNumber: 'WE 9',
    floor: 0,
    area: 50,
    rooms: 2,
    baseRent: 360, // Kaltmiete
    additionalCosts: 140, // Nebenkosten
    totalRent: 500, // Gesamtmiete
    status: 'rented',
    description: '50m², Wuppertal',
    createdAt: '2024-01-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  // Goldhammerstraße 46
  {
    id: 'unit-11',
    propertyId: 'prop-8',
    unitNumber: 'WE 7',
    floor: 0,
    area: 38,
    rooms: 2,
    baseRent: 400, // Kaltmiete
    additionalCosts: 150, // Nebenkosten
    totalRent: 550, // Gesamtmiete
    status: 'rented',
    description: '38m², Bochum',
    createdAt: '2024-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
];

// Mieter (fiktive Daten basierend auf Einheiten)
const demoTenants: Tenant[] = [
  {
    id: 'tenant-1',
    unitId: 'unit-1',
    firstName: 'Thomas',
    lastName: 'Müller',
    email: 't.mueller@email.de',
    phone: '0231-12345',
    street: 'Arndtstraße 115',
    city: 'Dortmund',
    postalCode: '44145',
    moveInDate: '2018-02-01',
    deposit: 1060,
    contractType: 'indefinite',
    contractStartDate: '2018-02-01',
    notes: 'WE 7, pünktlicher Zahler',
    createdAt: '2018-02-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-2',
    unitId: 'unit-2',
    firstName: 'Sandra',
    lastName: 'Weber',
    email: 's.weber@email.de',
    phone: '0231-23456',
    street: 'Arndtstraße 115',
    city: 'Dortmund',
    postalCode: '44145',
    moveInDate: '2019-06-01',
    deposit: 1020,
    contractType: 'indefinite',
    contractStartDate: '2019-06-01',
    notes: 'WE 05',
    createdAt: '2019-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-3',
    unitId: 'unit-3',
    firstName: 'Familie',
    lastName: 'Schmidt',
    email: 'schmidt.familie@email.de',
    phone: '0231-34567',
    street: 'Friedrichstraße 8',
    city: 'Dortmund',
    postalCode: '44137',
    moveInDate: '2019-04-01',
    deposit: 1220,
    contractType: 'indefinite',
    contractStartDate: '2019-04-01',
    notes: 'WE 11',
    createdAt: '2019-04-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-4',
    unitId: 'unit-4',
    firstName: 'Peter',
    lastName: 'Hoffmann',
    email: 'p.hoffmann@email.de',
    phone: '0231-45678',
    street: 'Friedrichstraße 8',
    city: 'Dortmund',
    postalCode: '44137',
    moveInDate: '2019-05-01',
    deposit: 1300,
    contractType: 'indefinite',
    contractStartDate: '2019-05-01',
    notes: 'WE 14',
    createdAt: '2019-05-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-5',
    unitId: 'unit-5',
    firstName: 'Familie',
    lastName: 'Bauer',
    email: 'familie.bauer@email.de',
    phone: '02363-12345',
    street: 'Dülmener Straße 19',
    city: 'Datteln',
    postalCode: '45711',
    moveInDate: '2020-07-01',
    deposit: 1400,
    contractType: 'indefinite',
    contractStartDate: '2020-07-01',
    notes: '78m² Wohnung',
    createdAt: '2020-07-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-6',
    unitId: 'unit-6',
    firstName: 'Anna',
    lastName: 'Fischer',
    email: 'a.fischer@email.de',
    phone: '0231-56789',
    street: 'Friedrichstraße 6',
    city: 'Dortmund',
    postalCode: '44137',
    moveInDate: '2021-03-01',
    deposit: 1020,
    contractType: 'indefinite',
    contractStartDate: '2021-03-01',
    notes: 'WE 01',
    createdAt: '2021-03-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-7',
    unitId: 'unit-8',
    firstName: 'Lisa',
    lastName: 'Klein',
    email: 'l.klein@email.de',
    phone: '0231-67890',
    street: 'Phönixseeallee 152',
    city: 'Dortmund',
    postalCode: '44145',
    moveInDate: '2023-05-01',
    deposit: 800,
    contractType: 'indefinite',
    contractStartDate: '2023-05-01',
    notes: 'WE 3',
    createdAt: '2023-05-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-8',
    unitId: 'unit-9',
    firstName: 'Mark',
    lastName: 'Wagner',
    email: 'm.wagner@email.de',
    phone: '0231-78901',
    street: 'Phönixseeallee 152',
    city: 'Dortmund',
    postalCode: '44145',
    moveInDate: '2023-05-01',
    deposit: 1200,
    contractType: 'indefinite',
    contractStartDate: '2023-05-01',
    notes: 'WE 4',
    createdAt: '2023-05-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-9',
    unitId: 'unit-10',
    firstName: 'Monika',
    lastName: 'Schulz',
    email: 'm.schulz@email.de',
    phone: '0202-12345',
    street: 'Hohenstein 62',
    city: 'Wuppertal',
    postalCode: '42283',
    moveInDate: '2024-02-01',
    deposit: 1000,
    contractType: 'indefinite',
    contractStartDate: '2024-02-01',
    notes: 'WE 9',
    createdAt: '2024-02-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'tenant-10',
    unitId: 'unit-11',
    firstName: 'Jan',
    lastName: 'Berger',
    email: 'j.berger@email.de',
    phone: '0234-12345',
    street: 'Goldhammerstraße 46',
    city: 'Bochum',
    postalCode: '44793',
    moveInDate: '2024-07-01',
    deposit: 1100,
    contractType: 'indefinite',
    contractStartDate: '2024-07-01',
    notes: 'WE 7',
    createdAt: '2024-07-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
];

// Transaktionen basierend auf der Excel-Datei (Einnahmen & Ausgaben)
const demoTransactions: Transaction[] = [
  // Mieteinnahmen Januar 2026 (basierend auf Excel-Daten)
  { id: 'trans-1', unitId: 'unit-1', propertyId: 'prop-1', type: 'income', category: 'rent', amount: 530, date: '2026-01-01', description: 'Miete Januar - Arndtstr. WE 7', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-2', unitId: 'unit-2', propertyId: 'prop-1', type: 'income', category: 'rent', amount: 510, date: '2026-01-01', description: 'Miete Januar - Arndtstr. WE 05', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-3', unitId: 'unit-3', propertyId: 'prop-2', type: 'income', category: 'rent', amount: 610, date: '2026-01-01', description: 'Miete Januar - Friedrichstr. 8 WE 11', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-4', unitId: 'unit-4', propertyId: 'prop-2', type: 'income', category: 'rent', amount: 650, date: '2026-01-01', description: 'Miete Januar - Friedrichstr. 8 WE 14', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-5', unitId: 'unit-5', propertyId: 'prop-3', type: 'income', category: 'rent', amount: 700, date: '2026-01-01', description: 'Miete Januar - Dülmener Str. 19', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-6', unitId: 'unit-6', propertyId: 'prop-4', type: 'income', category: 'rent', amount: 510, date: '2026-01-01', description: 'Miete Januar - Friedrichstr. 6 WE 01', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-7', unitId: 'unit-8', propertyId: 'prop-6', type: 'income', category: 'rent', amount: 400, date: '2026-01-01', description: 'Miete Januar - Phönixseeallee WE 3', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-8', unitId: 'unit-9', propertyId: 'prop-6', type: 'income', category: 'rent', amount: 600, date: '2026-01-01', description: 'Miete Januar - Phönixseeallee WE 4', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-9', unitId: 'unit-10', propertyId: 'prop-7', type: 'income', category: 'rent', amount: 500, date: '2026-01-01', description: 'Miete Januar - Hohenstein WE 9', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-10', unitId: 'unit-11', propertyId: 'prop-8', type: 'income', category: 'rent', amount: 550, date: '2026-01-01', description: 'Miete Januar - Goldhammerstr. WE 7', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  // Ausgaben aus Excel-Datei
  { id: 'trans-11', unitId: 'unit-1', propertyId: 'prop-1', type: 'expense', category: 'management', amount: 244, date: '2026-01-01', description: 'Hausverwaltung - Arndtstr. WE 7', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-12', unitId: 'unit-1', propertyId: 'prop-1', type: 'expense', category: 'taxes', amount: 8.74, date: '2026-01-01', description: 'Grundsteuer - Arndtstr. WE 7', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-13', unitId: 'unit-3', propertyId: 'prop-2', type: 'expense', category: 'mortgage', amount: 220.42, date: '2026-01-01', description: 'Kreditrate - Friedrichstr. 8 WE 11 (Tilgung: 185.42, Zinsen: 35)', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-14', unitId: 'unit-3', propertyId: 'prop-2', type: 'expense', category: 'management', amount: 302, date: '2026-01-01', description: 'Hausverwaltung - Friedrichstr. 8 WE 11', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-15', unitId: 'unit-3', propertyId: 'prop-2', type: 'expense', category: 'taxes', amount: 11.72, date: '2026-01-01', description: 'Grundsteuer - Friedrichstr. 8 WE 11', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-16', unitId: 'unit-5', propertyId: 'prop-3', type: 'expense', category: 'mortgage', amount: 437.33, date: '2026-01-01', description: 'Kreditrate - Dülmener Str. (Tilgung: 353.95, Zinsen: 83.38)', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-17', unitId: 'unit-5', propertyId: 'prop-3', type: 'expense', category: 'management', amount: 222, date: '2026-01-01', description: 'Hausverwaltung - Dülmener Str. 19', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-18', unitId: 'unit-5', propertyId: 'prop-3', type: 'expense', category: 'taxes', amount: 16.73, date: '2026-01-01', description: 'Grundsteuer - Dülmener Str. 19', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-19', unitId: 'unit-4', propertyId: 'prop-2', type: 'expense', category: 'mortgage', amount: 228.58, date: '2026-01-01', description: 'Kreditrate - Friedrichstr. 8 WE 14 (Tilgung: 165, Zinsen: 63.58)', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-20', unitId: 'unit-4', propertyId: 'prop-2', type: 'expense', category: 'management', amount: 281, date: '2026-01-01', description: 'Hausverwaltung - Friedrichstr. 8 WE 14', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-21', unitId: 'unit-4', propertyId: 'prop-2', type: 'expense', category: 'taxes', amount: 55.48, date: '2026-01-01', description: 'Grundsteuer - Friedrichstr. 8 WE 14', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-22', unitId: 'unit-6', propertyId: 'prop-4', type: 'expense', category: 'mortgage', amount: 195.50, date: '2026-01-01', description: 'Kreditrate - Friedrichstr. 6 (Tilgung: 141, Zinsen: 54.50)', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-23', unitId: 'unit-6', propertyId: 'prop-4', type: 'expense', category: 'management', amount: 298, date: '2026-01-01', description: 'Hausverwaltung - Friedrichstr. 6 WE 01', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-24', unitId: 'unit-6', propertyId: 'prop-4', type: 'expense', category: 'taxes', amount: 12.23, date: '2026-01-01', description: 'Grundsteuer - Friedrichstr. 6 WE 01', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-25', unitId: 'unit-7', propertyId: 'prop-5', type: 'expense', category: 'mortgage', amount: 315, date: '2026-01-01', description: 'Kreditrate - Körnerstr. 43 (Tilgung: 100, Zinsen: 215)', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-26', unitId: 'unit-8', propertyId: 'prop-6', type: 'expense', category: 'mortgage', amount: 495.22, date: '2026-01-01', description: 'Kreditrate - Phönixseeallee WE 3 (Tilgung: 183.52, Zinsen: 311.70)', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-27', unitId: 'unit-8', propertyId: 'prop-6', type: 'expense', category: 'management', amount: 86.25, date: '2026-01-01', description: 'Hausverwaltung - Phönixseeallee WE 3', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-28', unitId: 'unit-8', propertyId: 'prop-6', type: 'expense', category: 'taxes', amount: 17.81, date: '2026-01-01', description: 'Grundsteuer - Phönixseeallee WE 3', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-29', unitId: 'unit-9', propertyId: 'prop-6', type: 'expense', category: 'mortgage', amount: 495.22, date: '2026-01-01', description: 'Kreditrate - Phönixseeallee WE 4 (Tilgung: 183.52, Zinsen: 311.70)', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-30', unitId: 'unit-9', propertyId: 'prop-6', type: 'expense', category: 'management', amount: 85.51, date: '2026-01-01', description: 'Hausverwaltung - Phönixseeallee WE 4', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-31', unitId: 'unit-9', propertyId: 'prop-6', type: 'expense', category: 'taxes', amount: 16.94, date: '2026-01-01', description: 'Grundsteuer - Phönixseeallee WE 4', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-32', unitId: 'unit-2', propertyId: 'prop-1', type: 'expense', category: 'mortgage', amount: 448.90, date: '2026-01-01', description: 'Kreditrate - Arndtstr. WE 05 (Tilgung: 293.91, Zinsen: 154.99)', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-33', unitId: 'unit-2', propertyId: 'prop-1', type: 'expense', category: 'management', amount: 250, date: '2026-01-01', description: 'Hausverwaltung - Arndtstr. WE 05', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-34', unitId: 'unit-2', propertyId: 'prop-1', type: 'expense', category: 'taxes', amount: 9.58, date: '2026-01-01', description: 'Grundsteuer - Arndtstr. WE 05', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-35', unitId: 'unit-10', propertyId: 'prop-7', type: 'expense', category: 'management', amount: 229, date: '2026-01-01', description: 'Hausverwaltung - Hohenstein WE 9', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-36', unitId: 'unit-10', propertyId: 'prop-7', type: 'expense', category: 'taxes', amount: 16.76, date: '2026-01-01', description: 'Grundsteuer - Hohenstein WE 9', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  
  { id: 'trans-37', unitId: 'unit-11', propertyId: 'prop-8', type: 'expense', category: 'management', amount: 289, date: '2026-01-01', description: 'Hausverwaltung - Goldhammerstr. WE 7', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
  { id: 'trans-38', unitId: 'unit-11', propertyId: 'prop-8', type: 'expense', category: 'taxes', amount: 16.76, date: '2026-01-01', description: 'Grundsteuer - Goldhammerstr. WE 7', isRecurring: true, recurringInterval: 'monthly', createdAt: '2026-01-01T10:00:00.000Z', updatedAt: '2026-01-01T10:00:00.000Z' },
];

// Finanzierungen aus der Excel-Datei
const demoFinancings: Financing[] = [
  {
    id: 'fin-1',
    propertyId: 'prop-2',
    bankName: 'Sparkasse Dortmund',
    loanNumber: 'F8-WE11-001',
    principalAmount: 59000,
    interestRate: 1.5,
    repaymentRate: 3.8,
    monthlyRate: 220.42,
    remainingDebt: 45000,
    startDate: '2019-03-01',
    endDate: '2039-02-28',
    fixedInterestUntil: '2029-02-28',
    notes: 'Friedrichstr. 8 WE 11 - Tilgung 185.42, Zinsen 35',
    createdAt: '2019-03-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'fin-2',
    propertyId: 'prop-3',
    bankName: 'Volksbank Datteln',
    loanNumber: 'DS19-001',
    principalAmount: 65000,
    interestRate: 2.5,
    repaymentRate: 5.0,
    monthlyRate: 437.33,
    remainingDebt: 48000,
    startDate: '2020-06-01',
    endDate: '2035-05-31',
    fixedInterestUntil: '2028-05-31',
    notes: 'Dülmener Str. 19 - 2 Kredite: Tilgung 170+183.95, Zinsen 57.75+25.63',
    createdAt: '2020-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'fin-3',
    propertyId: 'prop-2',
    bankName: 'Sparkasse Dortmund',
    loanNumber: 'F8-WE14-002',
    principalAmount: 65000,
    interestRate: 2.0,
    repaymentRate: 3.0,
    monthlyRate: 228.58,
    remainingDebt: 52000,
    startDate: '2019-05-01',
    endDate: '2044-04-30',
    fixedInterestUntil: '2029-04-30',
    notes: 'Friedrichstr. 8 WE 14 - Tilgung 165, Zinsen 63.58',
    createdAt: '2019-05-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'fin-4',
    propertyId: 'prop-4',
    bankName: 'ING',
    loanNumber: 'F6-001',
    principalAmount: 55000,
    interestRate: 2.2,
    repaymentRate: 3.1,
    monthlyRate: 195.50,
    remainingDebt: 42000,
    startDate: '2021-02-01',
    endDate: '2041-01-31',
    fixedInterestUntil: '2031-01-31',
    notes: 'Friedrichstr. 6 WE 01 - Tilgung 141, Zinsen 54.50',
    createdAt: '2021-02-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'fin-5',
    propertyId: 'prop-5',
    bankName: 'Comdirect',
    loanNumber: 'K43-001',
    principalAmount: 53000,
    interestRate: 3.5,
    repaymentRate: 2.0,
    monthlyRate: 315,
    remainingDebt: 48000,
    startDate: '2022-08-01',
    endDate: '2052-07-31',
    fixedInterestUntil: '2027-07-31',
    notes: 'Körnerstr. 43 + Carport - Tilgung 100, Zinsen 215',
    createdAt: '2022-08-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'fin-6',
    propertyId: 'prop-6',
    bankName: 'Deutsche Bank',
    loanNumber: 'PHX-001',
    principalAmount: 182500,
    interestRate: 3.0,
    repaymentRate: 2.0,
    monthlyRate: 990.44,
    remainingDebt: 165000,
    startDate: '2023-04-01',
    endDate: '2053-03-31',
    fixedInterestUntil: '2033-03-31',
    notes: 'Phönixseeallee 152 - WE 3 + WE 4, je 91.250€',
    createdAt: '2023-04-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'fin-7',
    propertyId: 'prop-1',
    bankName: 'Sparkasse Dortmund',
    loanNumber: 'A115-WE05-001',
    principalAmount: 40000,
    interestRate: 2.8,
    repaymentRate: 5.0,
    monthlyRate: 448.90,
    remainingDebt: 28000,
    startDate: '2019-06-01',
    endDate: '2034-05-31',
    fixedInterestUntil: '2029-05-31',
    notes: 'Arndtstr. 115 WE 05 - Tilgung 293.91, Zinsen 154.99',
    createdAt: '2019-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
];

// Dokumente
const demoDocuments: Document[] = [
  {
    id: 'doc-1',
    propertyId: 'prop-1',
    name: 'Kaufvertrag Arndtstraße 115',
    type: 'purchase_contract',
    date: '2018-01-15',
    description: 'Kaufvertrag WE 7 und WE 05',
    fileData: '',
    fileName: 'kaufvertrag_arndtstr.pdf',
    fileType: 'application/pdf',
    fileSize: 2500000,
    createdAt: '2018-01-15T10:00:00.000Z',
    updatedAt: '2018-01-15T10:00:00.000Z',
  },
  {
    id: 'doc-2',
    propertyId: 'prop-6',
    name: 'Kaufvertrag Phönixseeallee 152',
    type: 'purchase_contract',
    date: '2023-04-01',
    description: 'Kaufvertrag WE 3 und WE 4',
    fileData: '',
    fileName: 'kaufvertrag_phoenixseeallee.pdf',
    fileType: 'application/pdf',
    fileSize: 3200000,
    createdAt: '2023-04-01T10:00:00.000Z',
    updatedAt: '2023-04-01T10:00:00.000Z',
  },
];

// Aufgaben
const demoTasks: Task[] = [
  {
    id: 'task-1',
    propertyId: 'prop-5',
    unitId: 'unit-7',
    title: 'Körnerstraße 43 vermieten',
    description: 'Wohnung steht leer - neuen Mieter suchen',
    dueDate: '2026-02-28',
    priority: 'high',
    status: 'in_progress',
    category: 'maintenance',
    createdAt: '2026-01-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'task-2',
    title: 'Mietzahlungen Januar prüfen',
    description: 'Alle Mieteingänge für Januar kontrollieren',
    dueDate: '2026-01-10',
    priority: 'medium',
    status: 'completed',
    category: 'rent_check',
    completedAt: '2026-01-08T10:00:00.000Z',
    createdAt: '2026-01-01T10:00:00.000Z',
    updatedAt: '2026-01-08T10:00:00.000Z',
  },
  {
    id: 'task-3',
    propertyId: 'prop-6',
    title: 'Zinsbindung überprüfen',
    description: 'Phönixseeallee - Zinsbindung läuft bis 2033',
    dueDate: '2026-06-01',
    priority: 'low',
    status: 'pending',
    category: 'deadline',
    createdAt: '2026-01-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'task-4',
    propertyId: 'prop-2',
    title: 'Heizungsabrechnung erstellen',
    description: 'Jahresabrechnung Heizung für Friedrichstr. 8',
    dueDate: '2026-03-31',
    priority: 'medium',
    status: 'pending',
    category: 'deadline',
    createdAt: '2026-01-15T10:00:00.000Z',
    updatedAt: '2026-01-15T10:00:00.000Z',
  },
];

// Abschreibungen basierend auf Excel-Daten
const demoDepreciations: Depreciation[] = [
  {
    id: 'dep-1',
    propertyId: 'prop-1',
    unitId: 'unit-1',
    name: 'Arndtstr. 115 - WE 7',
    purchasePrice: 20000,
    buildingShare: 17400, // 87% Gebäudeanteil
    landShare: 2600,
    depreciationRate: 2.5, // 40 Jahre
    startDate: '2018-01-15',
    endDate: '2058-01-15',
    annualDepreciation: 435, // 17400 * 2.5%
    monthlyDepreciation: 36.25,
    accumulatedDepreciation: 3480, // 8 Jahre
    remainingValue: 13920,
    type: 'linear',
    notes: 'Gebäudeanteil 87% bei 2.5% AfA',
    createdAt: '2018-01-15T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'dep-2',
    propertyId: 'prop-2',
    unitId: 'unit-3',
    name: 'Friedrichstr. 8 - WE 11',
    purchasePrice: 59000,
    buildingShare: 49000, // ca. 83% Gebäudeanteil
    landShare: 10000,
    depreciationRate: 2.0, // 50 Jahre (neueres Gebäude)
    startDate: '2019-03-01',
    endDate: '2069-03-01',
    annualDepreciation: 980, // 49000 * 2%
    monthlyDepreciation: 81.67,
    accumulatedDepreciation: 6860, // 7 Jahre
    remainingValue: 42140,
    type: 'linear',
    notes: 'Gebäude errichtet 1955',
    createdAt: '2019-03-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'dep-3',
    propertyId: 'prop-3',
    unitId: 'unit-5',
    name: 'Dülmener Str. 19',
    purchasePrice: 65000,
    buildingShare: 56150, // 86.4% Gebäudeanteil
    landShare: 8850,
    depreciationRate: 2.0,
    startDate: '2020-06-01',
    endDate: '2070-06-01',
    annualDepreciation: 1123, // 56150 * 2%
    monthlyDepreciation: 93.58,
    accumulatedDepreciation: 6738, // 6 Jahre
    remainingValue: 49412,
    type: 'linear',
    notes: 'Baujahr 1970',
    createdAt: '2020-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'dep-4',
    propertyId: 'prop-2',
    unitId: 'unit-4',
    name: 'Friedrichstr. 8 - WE 14',
    purchasePrice: 65000,
    buildingShare: 55000,
    landShare: 10000,
    depreciationRate: 2.0,
    startDate: '2019-05-01',
    endDate: '2069-05-01',
    annualDepreciation: 1100,
    monthlyDepreciation: 91.67,
    accumulatedDepreciation: 7700, // 7 Jahre
    remainingValue: 47300,
    type: 'linear',
    notes: '',
    createdAt: '2019-05-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'dep-5',
    propertyId: 'prop-4',
    unitId: 'unit-6',
    name: 'Friedrichstr. 6 - WE 01',
    purchasePrice: 55000,
    buildingShare: 47000,
    landShare: 8000,
    depreciationRate: 2.0,
    startDate: '2021-02-01',
    endDate: '2071-02-01',
    annualDepreciation: 940,
    monthlyDepreciation: 78.33,
    accumulatedDepreciation: 4700, // 5 Jahre
    remainingValue: 42300,
    type: 'linear',
    notes: '',
    createdAt: '2021-02-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'dep-6',
    propertyId: 'prop-5',
    unitId: 'unit-7',
    name: 'Körnerstr. 43',
    purchasePrice: 53000,
    buildingShare: 45000,
    landShare: 8000,
    depreciationRate: 2.5,
    startDate: '2022-08-01',
    endDate: '2062-08-01',
    annualDepreciation: 1125,
    monthlyDepreciation: 93.75,
    accumulatedDepreciation: 3750, // 3.3 Jahre
    remainingValue: 41250,
    type: 'linear',
    notes: '+ Carport',
    createdAt: '2022-08-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'dep-7',
    propertyId: 'prop-6',
    unitId: 'unit-8',
    name: 'Phönixseeallee 152 - WE 3',
    purchasePrice: 91250,
    buildingShare: 80000,
    landShare: 11250,
    depreciationRate: 2.5,
    startDate: '2023-04-01',
    endDate: '2063-04-01',
    annualDepreciation: 2000,
    monthlyDepreciation: 166.67,
    accumulatedDepreciation: 5500, // 2.75 Jahre
    remainingValue: 74500,
    type: 'linear',
    notes: 'Neubau 2020',
    createdAt: '2023-04-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'dep-8',
    propertyId: 'prop-6',
    unitId: 'unit-9',
    name: 'Phönixseeallee 152 - WE 4',
    purchasePrice: 91250,
    buildingShare: 80000,
    landShare: 11250,
    depreciationRate: 2.5,
    startDate: '2023-04-01',
    endDate: '2063-04-01',
    annualDepreciation: 2000,
    monthlyDepreciation: 166.67,
    accumulatedDepreciation: 5500,
    remainingValue: 74500,
    type: 'linear',
    notes: 'Neubau 2020',
    createdAt: '2023-04-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
  {
    id: 'dep-9',
    propertyId: 'prop-1',
    unitId: 'unit-2',
    name: 'Arndtstr. 115 - WE 05',
    purchasePrice: 40000,
    buildingShare: 35000,
    landShare: 5000,
    depreciationRate: 2.5,
    startDate: '2019-06-01',
    endDate: '2059-06-01',
    annualDepreciation: 875,
    monthlyDepreciation: 72.92,
    accumulatedDepreciation: 5687.5, // 6.5 Jahre
    remainingValue: 29312.5,
    type: 'linear',
    notes: '',
    createdAt: '2019-06-01T10:00:00.000Z',
    updatedAt: '2026-01-01T10:00:00.000Z',
  },
];

// Hausgelder (Beispieldaten)
const demoHouseMoney: HouseMoney[] = [
  {
    id: 'hm-1',
    propertyId: 'prop-1',
    unitId: 'unit-1',
    month: '2026-01',
    totalAmount: 160,
    maintenanceReserve: 45,
    administrativeFee: 50,
    utilities: 30,
    water: 15,
    heating: 0,
    garbage: 10,
    insurance: 10,
    other: 0,
    paymentStatus: 'paid',
    paymentDate: '2026-01-05',
    notes: 'Nebenkosten Vorauszahlung',
    createdAt: '2026-01-01T10:00:00.000Z',
    updatedAt: '2026-01-05T10:00:00.000Z',
  },
  {
    id: 'hm-2',
    propertyId: 'prop-2',
    unitId: 'unit-3',
    month: '2026-01',
    totalAmount: 220,
    maintenanceReserve: 60,
    administrativeFee: 70,
    utilities: 40,
    water: 20,
    heating: 0,
    garbage: 15,
    insurance: 15,
    other: 0,
    paymentStatus: 'paid',
    paymentDate: '2026-01-03',
    notes: '',
    createdAt: '2026-01-01T10:00:00.000Z',
    updatedAt: '2026-01-03T10:00:00.000Z',
  },
  {
    id: 'hm-3',
    propertyId: 'prop-6',
    unitId: 'unit-8',
    month: '2026-01',
    totalAmount: 87,
    maintenanceReserve: 25,
    administrativeFee: 30,
    utilities: 15,
    water: 8,
    heating: 0,
    garbage: 5,
    insurance: 4,
    other: 0,
    paymentStatus: 'paid',
    paymentDate: '2026-01-04',
    notes: 'Phönixsee - WE 3',
    createdAt: '2026-01-01T10:00:00.000Z',
    updatedAt: '2026-01-04T10:00:00.000Z',
  },
  {
    id: 'hm-4',
    propertyId: 'prop-6',
    unitId: 'unit-9',
    month: '2026-01',
    totalAmount: 80,
    maintenanceReserve: 22,
    administrativeFee: 28,
    utilities: 12,
    water: 8,
    heating: 0,
    garbage: 5,
    insurance: 5,
    other: 0,
    paymentStatus: 'paid',
    paymentDate: '2026-01-04',
    notes: 'Phönixsee - WE 4',
    createdAt: '2026-01-01T10:00:00.000Z',
    updatedAt: '2026-01-04T10:00:00.000Z',
  },
];

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      properties: demoProperties,
      units: demoUnits,
      tenants: demoTenants,
      transactions: demoTransactions,
      financings: demoFinancings,
      documents: demoDocuments,
      tasks: demoTasks,
      depreciations: demoDepreciations,
      houseMoney: demoHouseMoney,

      // Property actions
      addProperty: (property) => set((state) => ({
        properties: [...state.properties, {
          ...property,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateProperty: (id, property) => set((state) => ({
        properties: state.properties.map((p) =>
          p.id === id ? { ...p, ...property, updatedAt: getTimestamp() } : p
        ),
      })),

      deleteProperty: (id) => set((state) => ({
        properties: state.properties.filter((p) => p.id !== id),
        units: state.units.filter((u) => u.propertyId !== id),
        transactions: state.transactions.filter((t) => t.propertyId !== id),
        financings: state.financings.filter((f) => f.propertyId !== id),
        documents: state.documents.filter((d) => d.propertyId !== id),
        tasks: state.tasks.filter((t) => t.propertyId !== id),
      })),

      // Unit actions
      addUnit: (unit) => set((state) => ({
        units: [...state.units, {
          ...unit,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateUnit: (id, unit) => set((state) => ({
        units: state.units.map((u) =>
          u.id === id ? { ...u, ...unit, updatedAt: getTimestamp() } : u
        ),
      })),

      deleteUnit: (id) => set((state) => ({
        units: state.units.filter((u) => u.id !== id),
        tenants: state.tenants.filter((t) => t.unitId !== id),
        transactions: state.transactions.filter((t) => t.unitId !== id),
        documents: state.documents.filter((d) => d.unitId !== id),
        tasks: state.tasks.filter((t) => t.unitId !== id),
      })),

      // Tenant actions
      addTenant: (tenant) => set((state) => ({
        tenants: [...state.tenants, {
          ...tenant,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateTenant: (id, tenant) => set((state) => ({
        tenants: state.tenants.map((t) =>
          t.id === id ? { ...t, ...tenant, updatedAt: getTimestamp() } : t
        ),
      })),

      deleteTenant: (id) => set((state) => ({
        tenants: state.tenants.filter((t) => t.id !== id),
        documents: state.documents.filter((d) => d.tenantId !== id),
      })),

      // Transaction actions
      addTransaction: (transaction) => set((state) => ({
        transactions: [...state.transactions, {
          ...transaction,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateTransaction: (id, transaction) => set((state) => ({
        transactions: state.transactions.map((t) =>
          t.id === id ? { ...t, ...transaction, updatedAt: getTimestamp() } : t
        ),
      })),

      deleteTransaction: (id) => set((state) => ({
        transactions: state.transactions.filter((t) => t.id !== id),
      })),

      // Financing actions
      addFinancing: (financing) => set((state) => ({
        financings: [...state.financings, {
          ...financing,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateFinancing: (id, financing) => set((state) => ({
        financings: state.financings.map((f) =>
          f.id === id ? { ...f, ...financing, updatedAt: getTimestamp() } : f
        ),
      })),

      deleteFinancing: (id) => set((state) => ({
        financings: state.financings.filter((f) => f.id !== id),
      })),

      // Document actions
      addDocument: (document) => set((state) => ({
        documents: [...state.documents, {
          ...document,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateDocument: (id, document) => set((state) => ({
        documents: state.documents.map((d) =>
          d.id === id ? { ...d, ...document, updatedAt: getTimestamp() } : d
        ),
      })),

      deleteDocument: (id) => set((state) => ({
        documents: state.documents.filter((d) => d.id !== id),
      })),

      // Task actions
      addTask: (task) => set((state) => ({
        tasks: [...state.tasks, {
          ...task,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateTask: (id, task) => set((state) => ({
        tasks: state.tasks.map((t) =>
          t.id === id ? { ...t, ...task, updatedAt: getTimestamp() } : t
        ),
      })),

      deleteTask: (id) => set((state) => ({
        tasks: state.tasks.filter((t) => t.id !== id),
      })),

      // Depreciation actions
      addDepreciation: (depreciation) => set((state) => ({
        depreciations: [...state.depreciations, {
          ...depreciation,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateDepreciation: (id, depreciation) => set((state) => ({
        depreciations: state.depreciations.map((d) =>
          d.id === id ? { ...d, ...depreciation, updatedAt: getTimestamp() } : d
        ),
      })),

      deleteDepreciation: (id) => set((state) => ({
        depreciations: state.depreciations.filter((d) => d.id !== id),
      })),

      // HouseMoney actions
      addHouseMoney: (houseMoney) => set((state) => ({
        houseMoney: [...state.houseMoney, {
          ...houseMoney,
          id: generateId(),
          createdAt: getTimestamp(),
          updatedAt: getTimestamp(),
        }],
      })),

      updateHouseMoney: (id, houseMoney) => set((state) => ({
        houseMoney: state.houseMoney.map((h) =>
          h.id === id ? { ...h, ...houseMoney, updatedAt: getTimestamp() } : h
        ),
      })),

      deleteHouseMoney: (id) => set((state) => ({
        houseMoney: state.houseMoney.filter((h) => h.id !== id),
      })),

      // Import/Export
      importData: (data) => set({
        properties: data.data.properties || [],
        units: data.data.units || [],
        tenants: data.data.tenants || [],
        transactions: data.data.transactions || [],
        financings: data.data.financings || [],
        documents: data.data.documents || [],
        tasks: data.data.tasks || [],
        depreciations: data.data.depreciations || [],
        houseMoney: data.data.houseMoney || [],
      }),

      exportData: () => {
        const state = get();
        return {
          version: '1.0.0',
          exportDate: getTimestamp(),
          data: {
            properties: state.properties,
            units: state.units,
            tenants: state.tenants,
            transactions: state.transactions,
            financings: state.financings,
            documents: state.documents,
            tasks: state.tasks,
            depreciations: state.depreciations,
            houseMoney: state.houseMoney,
          },
        };
      },

      resetData: () => set({
        properties: demoProperties,
        units: demoUnits,
        tenants: demoTenants,
        transactions: demoTransactions,
        financings: demoFinancings,
        documents: demoDocuments,
        tasks: demoTasks,
        depreciations: demoDepreciations,
        houseMoney: demoHouseMoney,
      }),
    }),
    {
      name: 'bucki-storage',
    }
  )
);
