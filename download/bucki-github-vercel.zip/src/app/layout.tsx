import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Bucki - Immobilien-Verwaltung",
  description: "Professionelle Immobilien-Verwaltung für Ihr Portfolio. Verwalten Sie Immobilien, Einheiten, Mieter, Finanzen und mehr.",
  keywords: ["Immobilien", "Verwaltung", "Portfolio", "Mietverwaltung", "Finanzen", "Immobilienbewertung", "Schätzwert"],
  authors: [{ name: "Bucki Team" }],
  icons: {
    icon: [
      { url: "/logo.png", sizes: "32x32", type: "image/png" },
      { url: "/logo.png", sizes: "16x16", type: "image/png" },
    ],
    apple: [{ url: "/logo.png", sizes: "180x180", type: "image/png" }],
  },
  openGraph: {
    title: "Bucki - Immobilien-Verwaltung",
    description: "Professionelle Immobilien-Verwaltung mit ImmoScout24-ähnlicher Immobilienbewertung",
    type: "website",
    images: [{ url: "/logo.png", width: 512, height: 512, alt: "Bucki Logo" }],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/logo.png" type="image/png" />
        <link rel="apple-touch-icon" href="/logo.png" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster position="top-right" />
      </body>
    </html>
  );
}
